#!/usr/bin/env bash

set -x

root_dir=$(dirname $(readlink -f "$0"))/../../
cd ${root_dir}

odps='odpscmd --config=./conf/lzd_rec/product_dump_jy.ini'
ossutil="ossutilmac64 --config-file=./conf/lzd_rec/ossutilconfig"
script='target/jiying_rank_lzd_rec.tar.gz'
entry='pai/pai_run.py'
train_role_arn="acs:ram::1291070263519702:role/mt&host=cn-zhangjiakou.oss-internal.aliyun-inc.com"

function package()
{
    if [[ -f ${script} ]]
    then
        rm -f ${script}
    fi
    tar czf ${script} --exclude=./target  --exclude=./data  --exclude=./.git ./
    echo "tar package updated"
}

mode=$1

if [[ x"${mode}" == x"train" ]]
then
    package
    checkpoint_dir="oss://chuiyi/offline_train/ctr_huaipeng_zhp/general_rank_model"
    ${ossutil} rm -rf ${checkpoint_dir}/
    ${ossutil} mkdir  ${checkpoint_dir}/

    table_list="odps://product_dump_dev/tables/tda_test_sample_1d_0214_th_old"
    float_feature_stat_table="odps://product_dump/tables/lzd_mt_jfy_float_normal_30d_v2_union/ds=20191126/nation=TH"

    data_size=`${odps} -e "set odps.sql.mapper.split.size=1024;select count(*) FROM product_dump_dev.tda_test_sample_1d_0214_th_old" | sed "s/-//g" | sed "s/ //g" | sed "s/+//g" | sed "s/_c0//g" | sed "s/|//g" | sed 's/[[:space:]]//g' | sed '/^$/d'`

    ${ossutil}  stat ${checkpoint_dir}/checkpoint
    if [[ $? -ne 0 ]];then
       begin_step="0"
    else
       begin_step=`${ossutil} cat ${checkpoint_dir}/checkpoint | head -n 1 | cut -d "\"" -f 2 |  cut -d "-" -f 2`
    fi

    # generate user_params for training
    user_params="--float_feature_stat_table=${float_feature_stat_table}"
    user_params="${user_params} --table_list=${table_list}"
    user_params="${user_params} --checkpointDir=${checkpoint_dir}"
    user_params="${user_params} --summary_dir=${checkpoint_dir}"
    user_params="${user_params} --data_size=${data_size}"
    user_params="${user_params} --begin_step=${begin_step}"
    user_params="${user_params} --batch_size=4"
    user_params="${user_params} --global_conf=conf/lzd_rec/param.json"

    ${odps} -e "
            set odps.instance.priority=0;
            use product_dump_dev;
            pai -name tensorflow140
            -Dscript=\"file:${script}\"
            -DentryFile=\"${entry}\"
            -Dtables='${float_feature_stat_table},${table_list}'
            -Dbuckets='oss://chuiyi/?role_arn=${train_role_arn}'
            -DuserDefinedParameters='--mode=train ${user_params}'
            -Dcluster='{\"ps\":{\"count\":1,\"memory\":18000},\"worker\":{\"count\":1,\"gpu\":50,\"cpu\":500,\"memory\":18000}}'
            -DuseSparseClusterSchema=True
    "
fi

