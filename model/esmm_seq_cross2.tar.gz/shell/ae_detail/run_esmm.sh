#!/usr/bin/env sh

root_dir=$(dirname $(readlink -f "$0"))/../../
cd ${root_dir}
project_dir=$(pwd)
git pull

odps='/home/ningci.wkl/software/odps/bin/odpscmd'
config='/home/ningci.wkl/software/odps/conf/odps_config.ini'

biz_name="$1"
train_date='20201016'
test_date="20201017"

version="${biz_name}_${train_date}"
echo biz_name=${biz_name}
shift
conf="conf/ae_detail/v5/${biz_name}_param.json"
script="target/${biz_name}.tar.gz"
entry='pai/pai_run.py'

oss_dir="oss://41655/${version}"
#role="acs:ram::1973179712227261:role/searchweb-nc" #生产环境
#role="acs:ram::1973179712227261:role/searchweb-dev-nc"                  #开发环境
role="acs:ram::1973179712227261:role/searchai-dev-nc"
checkpointDir="${oss_dir}/?host=oss-cn-zhangjiakou.aliyuncs.com&role_arn=${role}"
echo "checkPoint=$checkpointDir"


package() {
  if [ -f ${script} ]; then
    rm -f ${script}
  fi

  tar czf ${script} --exclude=./*.tar.gz  --exclude=./logs --exclude=./target --exclude=./data --exclude=./.git ./
  echo "${script} tar package updated"
}


function local_test()
{
    userDefinedParameters="--global_conf= ${conf} \
                           --batch_size=10 \
                           --mode=local \
                           --tables=data/test_data_tengmu.csv.ae_detail \
                           --checkpointDir=data/ckpt
                            "

    export LD_LIBRARY_PATH=/home/yanshi.wys/env1/lib/
    export PYTHONPATH=/home/yanshi.wys/env1/lib64/python2.7/site-packages/
    python ${entry} $userDefinedParameters &
}

# shellcheck disable=SC2112
train_on_pai() {

  package
  #train_date=$(date -d "-1 day ${test_date}" +%Y%m%d)

 ##ctr数据
  ctr_train_data="odps://searchweb_dev/tables/ae_rec_detail_train_ctr_v4/ds=${train_date}" # ctr的train -- 有采样
  ctr_test_data="odps://searchweb/tables/ae_rec_detail_test_ctr/ds=${test_date}"    #  ctr的test--无采样

  ## cvr 数据
  cvr_train_data="odps://searchweb/tables/ae_rec_detail_train_cvr/ds=${train_date}" #  cvr 的train
  cvr_test_data="odps://searchweb/tables/ae_rec_detail_test_cvr/ds=${test_date}"   # cvr 的test

  log_file=${project_dir}/logs/train_${version}.txt


    userDefinedParameters="--global_conf=${conf} \
                           --mode=train \
                           --batch_size=2048 \
                            "

    ${odps} --config=${config} -e " \
        pai -name tensorflow140 \
            -Dscript=\"file:${script}\" \
            -DentryFile=\"${entry}\" \
	      	-Dcluster=\"{\\\"ps\\\":{\\\"count\\\":5,\\\"memory\\\":40000},\\\"worker\\\":{\\\"count\\\":50,\\\"gpu\\\":20,\\\"cpu\\\":600,\\\"memory\\\":60000}}\"   \
            -Dtables=\"${ctr_train_data},${ctr_test_data}\" \
            -DcheckpointDir=\"${checkpointDir}\" \
            -DuserDefinedParameters=\"${userDefinedParameters}\" \
            -DuseSparseClusterSchema=true \
            " >$log_file 2>&1 &
  echo "tail -n 50 $log_file"
  sleep 15
  tail -n 10 $log_file
}

 test_on_pai() {
  package

  test_table='odps://searchweb/tables/ae_rec_detail_test_ctr_4gauc'
  out_table='odps://searchweb_dev/tables/nc_ae_rank_predict'

  day=$test_date
  out_pt=${day}_${version}

  test_data="${test_table}/ds=${day}"
  out_data="${out_table}/ds=${out_pt}"
  log_file=${project_dir}/logs/${out_pt}.log
  userDefinedParameters="--global_conf=${conf} \
                           --mode=predict \
                           --num_epochs=1 \
                           --batch_size=1024 \
                           --outputs=${out_data} \
                          "
  ${odps} --config=${config} -e " \
        pai -name tensorflow140
            -Dscript=\"file:${script}\" \
            -DentryFile=\"${entry}\" \
            -Dcluster=\"{\\\"ps\\\":{\\\"count\\\":5,\\\"memory\\\":40000},\\\"worker\\\":{\\\"count\\\":50,\\\"gpu\\\":25,\\\"cpu\\\":600,\\\"memory\\\":20000}}\" \
            -Dtables=\"${test_data}\" \
            -Doutputs=\"${out_data}\" \
            -DcheckpointDir=\"${checkpointDir}\" \
            -DuserDefinedParameters=\"${userDefinedParameters}\" \
            -DuseSparseClusterSchema=true \
        ; \
        use searchweb_dev;  \
CREATE TABLE IF NOT EXISTS nc_ae_offline_gauc  \
( \
    ctr_auc DOUBLE \
    ,lp_auc DOUBLE \
    ,ctr_gauc DOUBLE \
    ,lp_gauc DOUBLE \
) \
PARTITIONED BY  \
( \
    ds STRING \
) \
LIFECYCLE 30 \
; \
 \
CREATE TABLE IF NOT EXISTS nc_ae_rank_predict_parsed  \
( \
    pv_id STRING \
    ,item_id STRING \
    ,click DOUBLE \
    ,pay DOUBLE \
    ,cvr DOUBLE \
    ,ctr DOUBLE \
) \
PARTITIONED BY  \
( \
    ds STRING \
) \
LIFECYCLE 30 \
; \
 \
INSERT OVERWRITE TABLE nc_ae_rank_predict_parsed PARTITION(ds='${out_pt}') \
SELECT  SPLIT_PART(t[0], CHR(1), 1) AS pvid \
        ,SPLIT_PART(t[0], CHR(1), 2) AS item_id \
        ,CAST(t[2] AS DOUBLE) AS click \
        ,CAST(t[1] AS DOUBLE) AS pay \
        ,CAST(t[3] AS DOUBLE) AS cvr \
        ,CAST(t[4] AS DOUBLE) AS ctr \
FROM    ( \
            SELECT  SPLIT(content, ';') AS t \
            FROM    searchweb_dev.nc_ae_rank_predict \
            WHERE   ds = '${out_pt}' \
            AND     content IS NOT NULL \
        ) a \
; \
 \
SET odps.sql.udf.python.memory=3072; \
 \
SET odps.sql.reshuffle.dynamicpt=false; \
  \
 INSERT OVERWRITE TABLE nc_ae_offline_gauc PARTITION(ds='${out_pt}') \
SELECT  ctr_auc,lp_auc,ctr_gauc,lp_gauc \
FROM    ( \
            SELECT  1 AS k \
                    ,tengmu_auc(1.0 - click, click, ctr) AS ctr_auc \
                    ,tengmu_auc(1.0 - pay, pay, ctr*cvr) AS lp_auc \
            FROM    nc_ae_rank_predict_parsed \
            WHERE   ds = '${out_pt}' \
        ) x \
JOIN    ( \
            SELECT  1 AS k \
                    ,AVG(IF(click > 0, ctr_auc, NULL)) AS ctr_gauc \
                    ,AVG(IF(pay > 0, lp_auc, NULL)) AS lp_gauc \
            FROM    ( \
                        SELECT  pv_id \
                                ,sum(click) AS click \
                                ,sum(pay) AS pay \
                                ,tengmu_auc(1.0 - click, click, ctr) AS ctr_auc \
                                ,tengmu_auc(1.0 - pay, pay, cvr * ctr) AS lp_auc \
                        FROM    nc_ae_rank_predict_parsed \
                        WHERE   ds = '${out_pt}' \
                        GROUP BY pv_id \
                    ) b \
        ) y \
ON      x.k = y.k \
; \
 \
SELECT  * \
FROM    nc_ae_offline_gauc ; \
    " >$log_file 2>&1 &
  echo "tail -n 50 $log_file"

}

 tensor_board() {
  log_file=${project_dir}/logs/tb_${version}.txt

  ${odps} --config=${config} -e " \
        pai -name tensorboard
            -DsummaryDir=\"${checkpointDir}\";
    " >$log_file 2>&1 &
  echo "tail -n 50 $log_file"
  sleep 10
  tail -n 50 $log_file
}

copy2hdfs(){
  bizdate="20200609"
     ${odps}  --config=${config} -e " \
    pai -name tensorflow140
    -Dscript=\"odps://searchweb_dev/resources/oss2hdfs_overwrite.py\" \
    -Dbuckets=\"oss://41655/?host=oss-cn-zhangjiakou.aliyuncs.com&role_arn=${role}\" \
    -DuserDefinedParameters=\"--source_ckpt_dir=${version}/ --target_ckpt_dir=hdfs://na61storage2/pai/train/ae_rmd/41655_ningci/f6/${bizdate}/data \" \
    -DgpuRequired=''; \
    "
}

while getopts 'rltpcg' OPT; do
  case $OPT in
  r)
    train_on_pai
    wait
    ;;
  l)
    local_test
    ;;
  t)
    tensor_board
    ;;
  p)
    test_on_pai
    ;;
  c)
    copy2hdfs
    ;;
  g)
    package
    ;;
  ?)
    echo "Usage: $(basename $0) [options]"
    ;;
  esac
done
