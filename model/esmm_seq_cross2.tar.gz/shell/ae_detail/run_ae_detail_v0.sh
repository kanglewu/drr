#!/usr/bin/env sh

root_dir=$(dirname $(readlink -f "$0"))/../../
cd ${root_dir}

odps='/home/yanshi.wys/data/tools/odps_console/bin/odpscmd'
config='/home/yanshi.wys/data/tools/odps_console/conf/search_ai_config.ini'

script='target/tengmu_rank_ae_detail.tar.gz'
entry='pai/pai_run.py'


function package()
{
    if [ -f ${script} ]
    then
        rm -f ${script}
    fi

    tar czf ${script} --exclude=./target  --exclude=./data  --exclude=./.git ./
    echo "tar package updated"
}


function local_test()
{
    entry='pai/pai_run.py'
    userDefinedParameters="--global_conf=conf/ae_detail/v0/param.json \
                           --batch_size=10 \
                           --mode=local \
                           --tables=data/test_data_tengmu.csv.ae_detail \
                           --checkpointDir=data/ckpt
                            "

    export LD_LIBRARY_PATH=/home/yanshi.wys/env1/lib/
    export PYTHONPATH=/home/yanshi.wys/env1/lib64/python2.7/site-packages/
    python ${entry} $userDefinedParameters &
}


function train_on_pai()
{
    package

    cvr_train_table='odps://searchweb_dev/tables/tengmu_ae_rec_cvr_feature_fg'
    cvr_test_table='odps://searchweb_dev/tables/tengmu_ae_rec_cvr_feature_fg'

    ctr_train_table='odps://searchweb_dev/tables/tengmu_ae_rec_ctr_feature_fg'
    ctr_test_table='odps://searchweb_dev/tables/tengmu_ae_rec_ctr_feature_fg'

    day_cvr="20200316"
    day_ctr="20200316"

    cvr_test_data="${cvr_test_table}/ds=${day_cvr}"
    ctr_test_data="${ctr_test_table}/ds=${day_ctr}"

    day_cvr=`date -d "-1 day ${day_cvr}" +%Y%m%d`
    day_ctr=`date -d "-1 day ${day_ctr}" +%Y%m%d`

    cvr_train_data="${cvr_train_table}/ds=${day_cvr}"
    ctr_train_data="${ctr_train_table}/ds=${day_ctr}"

    userDefinedParameters="--global_conf=conf/ae_detail/v0/param.json
                           --mode=train \
                           --batch_size=1024 \
                            "

    ${odps} --config=${config} -e " \
        pai -name tensorflow140
            -Dscript=\"file:${script}\" \
            -DentryFile=\"${entry}\" \
            -Dcluster=\"{\\\"ps\\\":{\\\"count\\\":5,\\\"memory\\\":40000},\\\"worker\\\":{\\\"count\\\":50,\\\"gpu\\\":20,\\\"cpu\\\":600,\\\"memory\\\":20000}}\" \
            -Dtables=\"${ctr_train_data},${ctr_test_data},${cvr_train_data},${cvr_test_data}\" \
            -DcheckpointDir=\"oss://67247/aliexpress/ae_detail/?role_arn=acs:ram::1792713237211375:role/muye5&host=cn-zhangjiakou.oss-internal.aliyun-inc.com\" \
            -DuserDefinedParameters=\"${userDefinedParameters}\" \
            -DuseSparseClusterSchema=true \
        ;
    "

}


function test_on_pai()
{
    package

    test_table='odps://searchweb/tables/tengmu_ae_rec_detail_test_v3'
    out_table='odps://searchweb_dev/tables/tengmu_ae_rank_predict'

    day="20200321"
    test_data="${test_table}/ds=${day}"
    out_data="${out_table}/ds=${day}"

    userDefinedParameters="--global_conf=conf/ae_detail/v0/param.json
                           --mode=predict \
                           --num_epochs=1 \
                           --batch_size=1024 \
                           --outputs=${out_data} \
                            "

    ${odps} --config=${config} -e " \
        pai -name tensorflow140
            -Dscript=\"file:${script}\" \
            -DentryFile=\"${entry}\" \
            -Dcluster=\"{\\\"ps\\\":{\\\"count\\\":5,\\\"memory\\\":40000},\\\"worker\\\":{\\\"count\\\":80,\\\"gpu\\\":25,\\\"cpu\\\":600,\\\"memory\\\":20000}}\" \
            -Dtables=\"${test_data}\" \
            -Doutputs=\"${out_data}\" \
            -DcheckpointDir=\"oss://67247/aliexpress/ae_detail/?role_arn=acs:ram::1792713237211375:role/muye5&host=cn-zhangjiakou.oss-internal.aliyun-inc.com\" \
            -DuserDefinedParameters=\"${userDefinedParameters}\" \
            -DuseSparseClusterSchema=true \
        ;
    "

}


function tensor_board()
{
    ${odps} --config=${config} -e " \
        pai -name tensorboard
            -DsummaryDir='oss://67247/aliexpress/ae_detail/?role_arn=acs:ram::1792713237211375:role/muye5&host=cn-zhangjiakou.oss-internal.aliyun-inc.com';
    "
}

while getopts 'rltp' OPT; do
    case $OPT in
        r)
            train_on_pai
            ;;
        l)
            local_test
            ;;
        t)
            tensor_board
            ;;
        p)
            test_on_pai
            ;;
        ?)
            echo "Usage: `basename $0` [options]"
    esac
done

wait
