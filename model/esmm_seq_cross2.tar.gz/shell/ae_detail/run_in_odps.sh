#!/usr/bin/env sh
project_dir=$(pwd)
odps=/opt/taobao/tbdpapp/odpswrapper/odpswrapper.py
odps_project="searchweb"

bizname="esmm_f6"
conf="conf/ae_detail/v6/${bizname}_param.json"

train_date="$1"
test_date="$2"

version="${bizname}_${train_date}"
echo bizname=${bizname}

ctr_train_data="odps://searchweb/tables/ae_rec_detail_train_ctr_v4/ds=${train_date}" # ctr的train -- 有采样
ctr_test_data="odps://searchweb/tables/ae_rec_detail_test_ctr_v4/ds=${test_date}"    #  ctr的test--无采样
test_data="odps://searchweb/tables/ae_rec_detail_test_ctr_4gauc_v4/ds=${test_date}"

script="${bizname}.tar.gz"
entry='pai/pai_run.py'

oss_dir="oss://41655/${model_name}/${train_date}"
role="acs:ram::1973179712227261:role/searchweb-nc" #生产环境
#role="acs:ram::1973179712227261:role/searchweb-dev-nc"                  #开发环境
checkpointDir="${oss_dir}/?host=oss-cn-zhangjiakou.aliyuncs.com&role_arn=${role}"
echo "checkPoint=$checkpointDir"

train_on_pai() {
    userDefinedParameters="--global_conf=${conf} \
                           --mode=train \
                           --batch_size=2048 \
                            "

    ${odps}  -e " \
        pai -name tensorflow140 \
            -Dscript=\"file:${script}\" \
            -DentryFile=\"${entry}\" \
	      	-Dcluster=\"{\\\"ps\\\":{\\\"count\\\":5,\\\"memory\\\":80000},\\\"worker\\\":{\\\"count\\\":30,\\\"gpu\\\":10,\\\"cpu\\\":600,\\\"memory\\\":60000}}\"   \
            -Dtables=\"${ctr_train_data},${ctr_test_data}\" \
            -DcheckpointDir=\"${checkpointDir}\" \
            -DuserDefinedParameters=\"${userDefinedParameters}\" \
            -DuseSparseClusterSchema=true \
            "
}

 test_on_pai() {

  out_table=odps://${odps_project}/tables/nc_ae_rank_predict
  out_pt=${test_date}_${version}
  out_data="${out_table}/ds=${out_pt}"

   userDefinedParameters="--global_conf=${conf} \
                           --mode=predict \
                           --num_epochs=1 \
                           --batch_size=1024 \
                           --outputs=${out_data} \
                          "
  ${odps}  -e " \
        pai -name tensorflow140
            -Dscript=\"file:${script}\" \
            -DentryFile=\"${entry}\" \
            -Dcluster=\"{\\\"ps\\\":{\\\"count\\\":2,\\\"memory\\\":40000},\\\"worker\\\":{\\\"count\\\":10,\\\"gpu\\\":0,\\\"cpu\\\":600,\\\"memory\\\":20000}}\" \
            -Dtables=\"${test_data}\" \
            -Doutputs=\"${out_data}\" \
            -DcheckpointDir=\"${checkpointDir}\" \
            -DuserDefinedParameters=\"${userDefinedParameters}\" \
            -DuseSparseClusterSchema=true \
        ; \
        use ${odps_project};  \
CREATE TABLE IF NOT EXISTS nc_ae_offline_gauc  \
( \
    ctr_auc DOUBLE \
    ,lp_auc DOUBLE \
    ,ctr_gauc DOUBLE \
    ,lp_gauc DOUBLE \
) \
PARTITIONED BY  \
( \
    ds STRING \
) \
LIFECYCLE 30 \
; \
 \
CREATE TABLE IF NOT EXISTS nc_ae_rank_predict_parsed  \
( \
    pv_id STRING \
    ,item_id STRING \
    ,click DOUBLE \
    ,pay DOUBLE \
    ,cvr DOUBLE \
    ,ctr DOUBLE \
) \
PARTITIONED BY  \
( \
    ds STRING \
) \
LIFECYCLE 30 \
; \
 \
INSERT OVERWRITE TABLE nc_ae_rank_predict_parsed PARTITION(ds='${out_pt}') \
SELECT  SPLIT_PART(t[0], CHR(1), 1) AS pvid \
        ,SPLIT_PART(t[0], CHR(1), 2) AS item_id \
        ,CAST(t[2] AS DOUBLE) AS click \
        ,CAST(t[1] AS DOUBLE) AS pay \
        ,CAST(t[3] AS DOUBLE) AS cvr \
        ,CAST(t[4] AS DOUBLE) AS ctr \
FROM    ( \
            SELECT  SPLIT(content, ';') AS t \
            FROM    nc_ae_rank_predict \
            WHERE   ds = '${out_pt}' \
            AND     content IS NOT NULL \
        ) a \
; \
 \
SET odps.sql.udf.python.memory=3072; \
 \
SET odps.sql.reshuffle.dynamicpt=false; \
  \
 INSERT OVERWRITE TABLE nc_ae_offline_gauc PARTITION(ds='${out_pt}') \
SELECT  ctr_auc,lp_auc,ctr_gauc,lp_gauc \
FROM    ( \
            SELECT  1 AS k \
                    ,tengmu_auc(1.0 - click, click, ctr) AS ctr_auc \
                    ,tengmu_auc(1.0 - pay, pay, ctr*cvr) AS lp_auc \
            FROM    nc_ae_rank_predict_parsed \
            WHERE   ds = '${out_pt}' \
        ) x \
JOIN    ( \
            SELECT  1 AS k \
                    ,AVG(IF(click > 0, ctr_auc, NULL)) AS ctr_gauc \
                    ,AVG(IF(pay > 0, lp_auc, NULL)) AS lp_gauc \
            FROM    ( \
                        SELECT  pv_id \
                                ,sum(click) AS click \
                                ,sum(pay) AS pay \
                                ,tengmu_auc(1.0 - click, click, ctr) AS ctr_auc \
                                ,tengmu_auc(1.0 - pay, pay, cvr * ctr) AS lp_auc \
                        FROM    nc_ae_rank_predict_parsed \
                        WHERE   ds = '${out_pt}' \
                        GROUP BY pv_id \
                    ) b \
        ) y \
ON      x.k = y.k \
; \
 \
SELECT  * \
FROM    nc_ae_offline_gauc ;  \
"
}

}

copy2hdfs(){
     ${odps} -e " \
    pai -name tensorflow
    -Dscript=\"odps://searchweb/resources/oss2dfs_overwrite.py\" \
    -Dbuckets=\"oss://41655/?host=oss-cn-zhangjiakou.aliyuncs.com&role_arn=${role}\" \
    -DuserDefinedParameters=\"--source_ckpt_dir=${model_name}/${train_date}/ --export_dir=dfs://ea119dfssearch1--cn-shanghai/pai/ae_rmd/41655_ningci/${model_name}/${train_date}/data --delete_dir=dfs://ea119dfssearch1--cn-shanghai/pai/ae_rmd/41655_ningci/${model_name}/${deldate} \" \
    -DgpuRequired=''; \
    "
}


checkAuc(){ 
    ${odps} -e "  SELECT lp_auc  FROM nc_ae_offline_gauc where ds='${version}';" > auc_${bizname}
    auc=`cut -d " " -f 2 auc_${bizname}  | grep 0`
    echo auc=$auc

    if [[ $(echo "$auc &lt; 0.8" | bc) == 1 ]];then
        echo "auc is abnormal!!! ${auc}"
        exit 1
    else  
        echo "auc is normal! ${auc}"
    fi 
}


train_on_pai
test_on_pai
checkAuc
copy2hdfs
