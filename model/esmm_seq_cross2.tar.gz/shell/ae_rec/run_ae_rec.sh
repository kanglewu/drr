#!/usr/bin/env sh

root_dir=$(dirname $(greadlink -f "$0"))/../../
cd $root_dir

echo $root_dir

home='/Users/miaoyujia/alibaba/run/odps_clt_release_64'
odps="$home/bin/odpscmd"
config="$home/conf/odps_config.ini"


script='target/ae_rec.tar.gz'

#update -> main py
entry='pai/pai_run.py'


function package()
{
    if [ -f ${script} ]
    then
        rm -f ${script}
    fi

    tar czf ${script} --exclude=./target  --exclude=./data  --exclude=./.git ./
    echo "tar package updated"
}


function local_test()
{
    entry='pai/pai_run.py'
    userDefinedParameters="--global_conf=conf/ae_recommend/param.json
                           --mode=local \
                           --num_epochs=1 \
                           --batch_size=100 \
                           --update_params=dnn_l2_reg=0&dropout_rate=0 \
                           --tables=data/ae_rec_test.csv \
                           --checkpointDir=data/ckpt \
                           --dataset_name=dataset.ae_recommend.text_dataset.TextDataset
                            "

    export LD_LIBRARY_PATH=~/env1/lib/
    export PYTHONPATH=~/env1/lib64/python2.7/site-packages
    python ${entry} $userDefinedParameters &
}


#hangzhou -> zhangjiakou TODO
function train_on_pai()
{
    package

    echo "begin to train"

    ctr_train_table='odps://searchweb/tables/jfy_ctr_sample_full'
    cvr_train_table='odps://searchweb/tables/jfy_cvr_sample_full'
    ctr_test_table='odps://searchweb/tables/jfy_ctr_sample_full'
    cvr_test_table='odps://searchweb/tables/jfy_cvr_sample_full'

    day="20200319"
    day1="20200320"
    day2='20200318'
    ctr_train_data="${ctr_train_table}/ds=${day}"
    cvr_train_data="${cvr_train_table}/ds=${day}"
    ctr_test_data="${ctr_test_table}/ds=${day1}"
    cvr_test_data="${cvr_test_table}/ds=${day1}"

    #tmp
    ctr_train_data="${cvr_train_table}/ds=${day2}"

    userDefinedParameters="--global_conf=conf/ae_recommend/param.json
                           --mode=train \
                           --num_epochs=1 \
                           --batch_size=512 \
                           --test_params=dnn_l2_reg=0&dropout_rate=0.2
                            "

    ${odps} --config=${config} -e " \
        pai -name tensorflow140
            -project algo_public_dev
            -Dscript=\"file:${script}\" \
            -DentryFile=\"${entry}\" \
            -Dcluster=\"{\\\"ps\\\":{\\\"count\\\":5,\\\"memory\\\":20000},\\\"worker\\\":{\\\"count\\\":20,\\\"gpu\\\":25,\\\"memory\\\":20000}}\" \
            -Dtables=\"${ctr_train_data},${ctr_test_data},${cvr_train_data},${cvr_test_data}\" \
            -DcheckpointDir=\"oss://283506-wujie/test/?host=oss-cn-zhangjiakou.aliyuncs.com&role_arn=acs:ram::1973179712227261:role/wujie\" \
            -DuserDefinedParameters=\"${userDefinedParameters}\" \
            -DmaxHungTimeBeforeGCInSeconds=0 \
        ;
    "


    echo "end to train"
}



function predict_on_pai()
{
    package

    predict_table='odps://icbu_da_dm_dev/tables/lqy_sample_predict_2'
    placeholder='odps://icbu_da_dm_dev/tables/lqy_sample_predict_3'


    userDefinedParameters="--batch_size=512 \
                           --num_epochs=1 \
                           --fg_conf=online_jfy_2020102_add_user_v2.json \
                           --global_conf=mc_20200104.json \
                           --model_name=toggler \
                           --save_chseckpoint_secs=3600 \
                           --save_summaries_steps=10000 \
                           --test_params=dnn_l2_reg=0&dropout_rate=0.2 \
                           --is_predict=1
                          "

    ${odps} --config=${config} -e " \
        pai -name tensorflow140
            -Dscript=\"file:${script}\" \
            -DentryFile=\"${entry}\" \
            -Dcluster=\"{\\\"ps\\\":{\\\"count\\\":1,\\\"memory\\\":30000},\\\"worker\\\":{\\\"count\\\":1,\\\"gpu\\\":25,\\\"memory\\\":30000}}\" \
            -Dtables=\"${predict_table},${placeholder}\" \
            -DcheckpointDir=\"oss://recjfy/cotrain_odps/test/?host=oss-cn-hangzhou-zmf.aliyuncs.com&role_arn=acs:ram::1234837945447194:role/sicilia\" \
            -DuserDefinedParameters=\"${userDefinedParameters}\" \
            -DmaxHungTimeBeforeGCInSeconds=0 \
        ;
    "
}

function tensor_board()
{
    ${odps} --config=${config} -e " \
        pai -name tensorboard 
	          -DsummaryDir='oss://283506-wujie/test/?host=oss-cn-zhangjiakou.aliyuncs.com&role_arn=acs:ram::1973179712227261:role/wujie';"
}



while getopts 'rltp' OPT; do
    case $OPT in
        r)
            train_on_pai
            ;;
        a)
            test_train_on_pai
            ;;
        l)
            local_test
            ;;
        t)
            tensor_board
            ;;
        p)
            predict_on_pai
            ;;
        ?)
            echo "Usage: `basename $0` [options]"
    esac
done

wait
