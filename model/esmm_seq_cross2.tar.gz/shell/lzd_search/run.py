import os
import sys
import json
import time
import argparse
import datetime
import subprocess

current_dir = os.path.abspath(os.path.dirname(__file__))
root_dir = os.path.dirname(os.path.dirname(current_dir))

sys.path.append(root_dir)

from schedule.mode import ModeKeys
from utils.record import TableRecord
from collections import OrderedDict

ENVS = {
    'product_dump_dev': {
        'NAME'    : 'product_dump_dev',
        'ODPS_CMD': '/Users/codewang/bins/odpscmd/bin/odpscmd',
        'OSS_CMD' : '/Users/codewang/bins/ossutilmac64',
        'ODPS_CFG': '/Users/codewang/bins/odpscmd/conf/odps_config.ini.product_dump',
        'OSS_KEY' : '?role_arn=acs:ram::1287270261765012:role/deep-multi-task&host=cn-hangzhou.oss-internal.aliyun-inc.com',
        'PROJECT' : 'product_dump_dev'
    },
    'voyager_algo_dev':{
        'NAME'     : 'voyager_algo_dev',
        'ODPS_CMD' : '/Users/codewang/bins/odpscmd/bin/odpscmd',
        'OSS_CMD'  : '/Users/codewang/bins/ossutilmac64',
        'ODPS_CFG' : '/Users/codewang/bins/odpscmd/conf/odps_config.ini.voyager',
        'OSS_KEY'  : '?role_arn=acs:ram::1287270261765012:role/dev&host=cn-hangzhou.oss-internal.aliyun-inc.com',
        'PROJECT'  : 'voyager_algo_dev'
    }
}

def run_and_wait(cmd):
    p = subprocess.Popen(cmd, shell=True)
    p.wait()
    sta = p.communicate()

    return sta


def update_and_dump(fin, fout, replace_dict={}):
    with open(fin, 'r') as fp:
        context = fp.read()
        for source, target in replace_dict.items():
            if source in context:
                context = context.replace(source, target(context) if callable(target) else target)

    with open(fout, 'w') as fp:
         fp.write(context)

    return json.loads(context)


class PAI(object):
    def __init__(self, configure):
        self.cf = configure
        self.mode       = configure['input']['mode']
        self.train_data = configure['data']['train_data'].split(',')
        self.valid_data = configure['data']['valid_data'].split(',')
        self.test_data  = configure['data']['test_data'].split(',')
        self.output     = configure['data']['result_table'].split(',')

        self.checkpoint_saver = configure['path']['checkpointDir']
        self.summary_saver    = configure['path']['summary_saver']
        self.checkpoint_store = configure['path']['checkpoint_store']

        self.oss_key = configure['input']['oss_key']



    def _filter(self, items):
        """ Example:
            >>> a = [1,9,3,4,5,1,9,4]
            >>> list(set(a))
            [1, 3, 4, 5, 9]
            >>> sorted(set(a), key=a.index)
            [1, 9, 3, 4, 5]
        """
        return ','.join(sorted(set(items), key=items.index))

    def buckets(self):
        all_buckets = [self.checkpoint_saver, self.summary_saver]
        if self.checkpoint_store not in (None, ''):
            all_buckets = all_buckets.append(self.checkpoint_store)

        return self._filter(([all_buckets[0] + self.oss_key] + all_buckets[1:]))


    def tables(self):
        return {
            ModeKeys.TRAIN:   self._filter(self.train_data + self.valid_data),
            ModeKeys.PREDICT: self._filter(self.test_data),
            ModeKeys.DEBUG :  self._filter(self.test_data),
            ModeKeys.EXPORT:  '',
        }.get(self.mode, self._filter(self.train_data + self.valid_data + self.test_data))


    def outputs(self):
        return self._filter(self.output)

    def cluster(self):
        return {
            ModeKeys.TRAIN  :  self.cf['distribution']['cluster'],
            ModeKeys.PREDICT:  self.cf['distribution']['cluster'],
            ModeKeys.DEBUG  :  self.cf['distribution']['cluster_export'],
            ModeKeys.EXPORT :  self.cf['distribution']['cluster_export']
        }.get(self.mode, self.cf['distribution']['cluster'])


def main():
    # 1) parse options
    parser = argparse.ArgumentParser()
    parser.add_argument('-e', type=str, help='experiment name, e.g esmm', default=None)
    parser.add_argument('-v', type=str, help='version, e.g 1.0', default=None)
    parser.add_argument('-n', type=str, help='nation, e.g ph,id,...', default=None)
    parser.add_argument('--mode', type=str, help='mode, [train/test]', default='train')
    parser.add_argument('--env', type=str, help='odps project', default='product_dump_dev')
    options = parser.parse_args()

    ENV     = ENVS[options.env]
    MODE    = options.mode
    VERSION = options.v
    NATION  = options.n
    EXPERIMENT = options.e
    CURRENT = datetime.datetime.strftime(datetime.datetime.now(), '%Y%m%d%H%M')


    # 2) generate configures
    replace_dict = OrderedDict()
    replace_dict["${experiment}"] = EXPERIMENT
    replace_dict["${version}"]    = VERSION
    replace_dict["${nation}"]     = NATION
    replace_dict["${NATION}"]     = NATION.swapcase()
    replace_dict["${current}"]    = CURRENT
    replace_dict["${mode}"]       = MODE
    replace_dict["${space}"]      = 'odps://%s/tables' % options.env
    replace_dict["${oss}"]        = ENV['OSS_KEY']
    replace_dict["${data}"]       = lambda context: TableRecord(context).sha



    param = update_and_dump(fin='conf/lzd_search/param.json', fout='conf/lzd_search/run/param.json', replace_dict=replace_dict)
    fc    = update_and_dump(fin='conf/lzd_search/fc.json',    fout='conf/lzd_search/run/fc.json',    replace_dict=replace_dict)
    fg    = update_and_dump(fin='conf/lzd_search/fg.json',    fout='conf/lzd_search/run/fg.json',    replace_dict=replace_dict)
    mc    = update_and_dump(fin='conf/lzd_search/mc.json',    fout='conf/lzd_search/run/mc.json',    replace_dict=replace_dict)

    # x) clear oss space


    # 3) tar files
    if os.path.exists('run.tar.gz'):
        os.remove('run.tar.gz')

    os.popen('tar czf run.tar.gz    --exclude=./data \
                                    --exclude=./.git \
                                    --exclude=./.history \
                                    --exclude=./.vscode  \
                                    --exclude=./.doc  \
                                    --exclude=./.docs \
                                    --exclude=./logviews \
                                    --exclude=./run.tar.gz \
                                    ./')
    # 4) pai command
    pai = PAI(param)

    pai_command  = 'pai -name tensorflow140 '
    pai_command += '-Dscript=file://{}/run.tar.gz '
    pai_command += '-DentryFile=pai/pai_run.py '
    pai_command += '-Dcluster=\'{}\' '
    pai_command += '-Dtables={} '
    pai_command += '-Doutputs={} '
    pai_command += '-Dbuckets={} '
    pai_command += '-DmaxHungTimeBeforeGCInSeconds=0 '
    pai_command += '-DenableDynamicCluster={} '
    pai_command += '-DuseSparseClusterSchema=true '
    pai_command += '-DuserDefinedParameters=\'{}\''
    pai_command  = pai_command.format(
                        os.getcwd(),
                        pai.cluster(),
                        pai.tables(),
                        pai.outputs(),
                        pai.buckets(),
                        'true' if MODE=='test' else 'false',
                        "--global_conf=conf/lzd_search/run/param.json"
                   )

    pai_command = '%s --config=%s -e \"%s;\"'% (
                        ENV['ODPS_CMD'],
                        ENV['ODPS_CFG'],
                        pai_command)


    # 5) write logs in console in logfile :  2>&1 | tee a.log
    log_path = './logviews/%s/%s/%s' % (NATION, EXPERIMENT, 'v'+ VERSION)
    log_file = time.strftime("%Y-%m-%d-%H-%M-%S", time.localtime()) + '.' + MODE
    if not os.path.exists(log_path):
        os.makedirs(log_path)

    log_file =  log_path + '/' + log_file
    with open(log_file, 'w') as lp:
        lp.write(pai_command + '\n')

    print(pai_command)
    pai_command = pai_command + ' 2>&1 | tee -a ' + log_file
    run_and_wait(pai_command)

if __name__ == '__main__':
    main()
