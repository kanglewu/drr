
from base.runner import BaseRunner
import tensorflow as tf

class LzdRunner(BaseRunner):
    def __init__(self, FLAGS, summary_validation_only=False, *args, **kwargs):
        self.summary_validation_only = summary_validation_only
        with tf.name_scope('summary') as scope :
            self.scope = scope
    
        super(LzdRunner, self).__init__(FLAGS, *args, **kwargs)

    def _summary_switch(self):
        if self.FLAGS.task_index == 0:
            return True
        elif not self.summary_validation_only:
            return True 
        return False



    def add_scalar(self, op, name, toLog=True):
        if self._summary_switch():
            with tf.name_scope(self.scope):
                tf.summary.scalar(name=name, tensor=op)
        if toLog:
            self.add_log_ops([name], [op])
    
    def add_histogram(self, op, name):
        if  self._summary_switch():
            with tf.name_scope(self.scope):
                tf.summary.histogram(name=name, values=op)
    
    def add_auc(self, pred, label, mask=None, name='auc', toLog=True):
        with tf.name_scope(self.scope):
            worker_device = '/job:worker/task:{}'.format(self.FLAGS.task_index)
            with tf.device(worker_device):
                auc_op, update_op = tf.metrics.auc(
                    labels = label,
                    predictions = pred,
                    num_thresholds = 2000,
                    weights = mask,
                    name=name
                )

        if self._summary_switch():
            tf.summary.scalar(name=name, tensor=auc_op)

        if toLog:
            self.add_log_ops([name], [auc_op])

        self.add_train_ops([update_op])
        self.add_evaluate_ops([update_op])
    
    def add_accuracy(self, pred, label, mask=None, name='accuracy', toLog=True):
         with tf.name_scope(self.scope):
            worker_device = '/job:worker/task:{}'.format(self.FLAGS.task_index)
            with tf.device(worker_device):
                corrects = tf.equal(tf.argmax(pred, axis=-1), tf.cast(label, tf.int64))
                accuracy = tf.reduce_mean(tf.cast(corrects, tf.float32))

                if self._summary_switch():
                    tf.summary.scalar(name=name, tensor=accuracy)
                if toLog:
                    self.add_log_ops([name], [accuracy])