import tensorflow as tf 
from tensorflow.contrib import layers
from tensorflow.contrib.framework.python.ops import arg_scope
import json


from base.model import BaseModel
from fg.feature_column_builder import FeatureColumnBuilder
from utils.config import parse_model_conf
from model_ops import ops as base_ops
from utils.util import get_act_fn
from model_ops.sequence  import SequenceFeature
from model_ops.attention import AttentionFeature
from model_ops import Attention
from model_ops import LossFunc, MultiLossLayer
from .lzd_runner import LzdRunner




class RankModel(BaseModel):
    def __init__(self, FLAGS, *args, **kwargs):
        self.FLAGS  = FLAGS
        self.ps_num = len(self.FLAGS.ps_hosts.split(','))
        self.embedding_partition_size = FLAGS.embedding_partition_size
        self.dnn_l2_reg = FLAGS.dnn_l2_reg
        self.dropout    = FLAGS.dropout
        self.dnn_hidden_units_act_op = FLAGS.dnn_hidden_units_act_op
        self.dnn_hidden_units =FLAGS.dnn_hidden_units
        self.learning_rate = FLAGS.learning_rate
        super(RankModel, self).__init__(FLAGS, *args, **kwargs)
        self.runner = LzdRunner(FLAGS, *args, **kwargs)
        self.fg_conf = json.load(open(FLAGS.fg_conf, 'r'))
        self.fc_conf = json.load(open(FLAGS.fc_conf, 'r'))
        self.mc_conf = json.load(open(FLAGS.mc_conf, 'r'))


    def build(self, batch_data, *args, **kwargs):
        self.set_shape_optimize()
        self.build_placeholder()
        self.setup_global_step()
        self.build_inputs(batch_data, *args, **kwargs)
        self.build_model()
        self.predict_op()
        self.loss_op()
        self.training_op()
        self.mark_output()
        self.summary()


    def set_shape_optimize(self):
        tf.get_default_graph().set_shape_optimize(False)

    
    def build_placeholder(self):
        try:
            training = tf.get_default_graph().get_tensor_by_name('training:0')
        except KeyError:
            training = tf.placeholder(tf.bool, name='training')
        
        self.is_training = training

    def setup_global_step(self):
        self.global_step = tf.Variable(
            initial_value=0,
            name='global_step',
            trainable=False,
            collections=[tf.GraphKeys.GLOBAL_STEP, tf.GraphKeys.GLOBAL_VARIABLES])


    def build_feature_layers(self, FLAGS, features):
        # build columns
        column_builder = FeatureColumnBuilder(FLAGS, self.fg_conf, self.fc_conf)
        group_conf     = self.mc_conf['input_columns']


        def _column_features(group, scope):
            column_group = column_builder.get_column_list(group)
            layer = layers.input_from_feature_columns(features, column_group, scope=scope)
            return layer

        def _sequence_features(seq_block, seq_length_block, scope):
            sequence = SequenceFeature(seq_block, seq_length_block, column_builder)
            sequence.concat_seq_features(features)
            
            realtime_sequence_length = sequence.get_sequence_length_layer(features, scope=scope)
            realtime_sequence_layer  = sequence.get_sequence_layer(features, 
                                                                   realtime_sequence_length, 
                                                                   scope)
            return {
                "realtime_sequence_length" : realtime_sequence_length,
                "realtime_sequence"        : realtime_sequence_layer
            }


        def _attention_feature(group, scope):
            attention = AttentionFeature(group, column_builder)
            return attention.get_attention_layer(features, scope=scope)

        with tf.variable_scope(name_or_scope='input_from_feature_columns',
                               partitioner=base_ops.partitioner(ps_num=self.ps_num, 
                                                                mem=self.embedding_partition_size),
                               reuse=tf.AUTO_REUSE) as scope:
            layer_dict = {
                    "user_sparse"    : _column_features(group_conf['user_sparse'],    scope),
                    "query_sparse"   : _column_features(group_conf['query_sparse'],   scope),
                    "business_dense" : _column_features(group_conf['business_dense'], scope),
                    "business_sparse": _column_features(group_conf['business_sparse'],scope),
                    "query_sparse"   : _column_features(group_conf['query_sparse'],   scope),
                    "item_sparse"    : _column_features(group_conf['item_sparse'],    scope), 
                    "item_dense"     : _column_features(group_conf['item_dense'],     scope),
                    "s_features"     : _column_features(group_conf['s_features_bucket'],  scope),
                    "attention"      : _attention_feature(group_conf['attention_block'], scope)
            }

            layer_dict.update(
                        _sequence_features(group_conf['sequence_block'], group_conf['sequence_length_block'], scope)
            )

            return layer_dict
        
    def build_inputs(self, batch_data, use_fg=True, local_mode=False):
        import rtp_fg
        with tf.name_scope('Pipeline'):
            self.unique_id   = tf.reshape(batch_data['id'], [-1, 1])
            self.click_label = tf.reshape(tf.to_float(tf.greater(tf.cast(batch_data['type'], dtype=tf.float32), 0.5)), [-1, 1])
            self.pay_label   = tf.reshape(tf.to_float(tf.greater(tf.cast(batch_data['type'], dtype=tf.float32), 2.5)), [-1, 1])
            self.features    = rtp_fg.parse_genreated_fg(self.fg_conf, batch_data['features'])

            
        self.layer_dict = self.build_feature_layers(self.FLAGS, self.features)

    
    def _build_network(self, name):
        with tf.variable_scope(name_or_scope='Attention_Network_{}'.format(name)):
            with arg_scope(base_ops.model_arg_scope(weight_decay=self.dnn_l2_reg)):
                attention_input_layer = self._create_attention_network(self.layer_dict['attention'],
                                                                       self.layer_dict['realtime_sequence'],
                                                                       self.layer_dict['realtime_sequence_length'],
                                                                       self.layer_dict['query_sparse'])
                
            with tf.variable_scope(name_or_scope='Cross_Network_{}'.format(name)):
                with arg_scope(base_ops.model_arg_scope(weight_decay=self.dnn_l2_reg)):
                    cross_input_layer = self._create_cross_network(self.layer_dict['user_sparse'],
                                                                   self.layer_dict['item_sparse'],
                                                                   self.layer_dict['query_sparse'],
                                                                   self.layer_dict['realtime_sequence'])

            with tf.variable_scope(name_or_scope='DNN_Network_{}'.format(name)):
                self.layer_dict['item_dense'] = layers.batch_norm(self.layer_dict['item_dense'],
                                                                         decay=0.9, scale=False, center=False,
                                                                         epsilon=1e-6, activation_fn=tf.nn.relu,
                                                                         is_training=self.is_training)
                net = tf.concat([self.layer_dict['user_sparse'],
                                 self.layer_dict['item_sparse'],
                                 self.layer_dict['item_dense'],
                                 self.layer_dict['query_sparse'],
                                 attention_input_layer,
                                 cross_input_layer,
                                 self.layer_dict['s_features'],
                                 self.layer_dict['business_sparse'],
                                 self.layer_dict['business_dense']
                                 ], axis=1)

                with arg_scope(base_ops.model_arg_scope(weight_decay=self.dnn_l2_reg)):
                    for layer_id, num_hidden_units in enumerate(self.dnn_hidden_units):
                        with tf.variable_scope('Hidden_{}'.format(layer_id)) as dnn_hidden_layer_scope:
                            net = layers.fully_connected(
                                net,
                                num_hidden_units,
                                activation_fn=get_act_fn(self.dnn_hidden_units_act_op[layer_id]),
                                scope=dnn_hidden_layer_scope,
                                normalizer_fn=layers.batch_norm,
                                normalizer_params={'scale': True, 'is_training': self.is_training}
                            )
                            
                            net = tf.layers.dropout(
                                net,
                                rate=self.FLAGS.dropout,
                                noise_shape=None,
                                seed=None,
                                training=self.is_training,
                                name=None)


                with tf.variable_scope(name_or_scope='Logits') as deep_logits_scope:
                    with arg_scope(base_ops.model_arg_scope(weight_decay=self.dnn_l2_reg)):
                        logits = layers.fully_connected(
                            net,
                            1,
                            activation_fn=None,
                            scope=deep_logits_scope)

            return logits, net

    
    def _create_attention_network(self, attention_input_layer_dict, sequence_input_layer_dict,
                                 sequence_length_layer_dict, query_token_input_layer):

        query_token_input_layer = tf.expand_dims(query_token_input_layer, axis=1)

        common_lst = []
        for name, layer in sequence_input_layer_dict.items():
            if name not in attention_input_layer_dict:
                common_lst.append(layer)
        common_layer = tf.add_n(common_lst)

        seq_layer_list, query_layer_list, seq_length_list = [], [], []
        for name, query_layers in attention_input_layer_dict.items():
            seq_layer = sequence_input_layer_dict[name]
            seq_length = sequence_length_layer_dict.get(name, None)
            if seq_length is None:
                raise Exception('keys {} length is None'.format(name))
            if name.endswith('cate_id'):  # same cate_id within the whole sequence
                seq_layer += common_layer
            query_layer = tf.concat([query_token_input_layer] + query_layers, axis=1)

            seq_layer_list.append(tf.expand_dims(seq_layer, axis=1))
            seq_length_list.append(tf.expand_dims(seq_length, axis=1))
            query_layer_list.append(tf.expand_dims(query_layer, axis=1))

        seq_layer = tf.concat(seq_layer_list, axis=1)
        seq_length = tf.concat(seq_length_list, axis=1)
        query_layer = tf.concat(query_layer_list, axis=1)

        # self attention
        with tf.variable_scope('self'):
            # (?, N, T_q, C), (?, N, T_q, T_k)
            seq_vec, att_vec = Attention('attention')(queries=seq_layer,
                                         queries_length=seq_length,
                                         keys=seq_layer,
                                         keys_length=seq_length,
                                         query_masks=None,
                                         key_masks=None)
            seq_shape = seq_layer.shape.as_list()
            self_att_vec = tf.concat([seq_vec, att_vec], axis=-1)
            self_att_vec = tf.reshape(self_att_vec, [-1, seq_shape[1], seq_shape[2] * (seq_shape[3] + seq_shape[2])])
            # project network
            self_att_net = layers.fully_connected(
                self_att_vec,
                16,
                activation_fn=get_act_fn(self.dnn_hidden_units_act_op[0]),
                normalizer_fn=layers.batch_norm,
                normalizer_params={'scale': True, 'is_training': self.is_training}
            )
            
            self_att_net = tf.layers.dropout(self_att_net, rate=self.dropout,
                                                training=self.is_training)

        # cross attention
        with tf.variable_scope('cross'):
            seq_vec, att_vec = Attention('attention')(queries=query_layer,
                                         queries_length=None,
                                         keys=seq_layer,
                                         keys_length=seq_length,
                                         query_masks=None,
                                         key_masks=None)
            query_shape = query_layer.shape.as_list()
            cross_att_vec = tf.concat([seq_vec, att_vec], axis=-1)
            cross_att_vec = tf.reshape(cross_att_vec, [-1, query_shape[1], query_shape[2] * (query_shape[3] + seq_shape[2])])
            # project network
            cross_att_net = layers.fully_connected(
                cross_att_vec,
                16,
                activation_fn=get_act_fn(self.dnn_hidden_units_act_op[0]),
                normalizer_fn=layers.batch_norm,
                normalizer_params={'scale': True, 'is_training': self.is_training}
            )
            
            cross_att_net = tf.layers.dropout(cross_att_net, rate=self.FLAGS.dropout,
                                                training=self.is_training)

        att_output_layer = tf.concat([self_att_net, cross_att_net], axis=-1)
        att_shape = att_output_layer.shape.as_list()
        attention_output_layer = tf.reshape(att_output_layer, [-1, att_shape[1] * att_shape[2]])
        return attention_output_layer

        

    def _create_cross_network(self, user_sparse_input_layer, item_sparse_input_layer,
                             query_token_input_layer, sequence_input_layer_dict):

        query_token_input_layer = tf.expand_dims(query_token_input_layer, axis=1)

        user_s_shape = user_sparse_input_layer.shape.as_list()[1] // 8
        user_sparse = tf.reshape(user_sparse_input_layer, [-1, user_s_shape, 8])

        seq_sparse = []
        for name, layer in sequence_input_layer_dict.items():
            seq_sparse.append(tf.reduce_sum(layer, axis=1, keep_dims=True))
        seq_sparse = tf.concat(seq_sparse, axis=1)

        user_sparse = tf.concat([user_sparse, seq_sparse, query_token_input_layer], axis=1)
        user_s_shape = user_sparse.shape.as_list()[1]

        item_s_shape = item_sparse_input_layer.shape.as_list()[1] // 8
        item_sparse = tf.reshape(item_sparse_input_layer, [-1, item_s_shape, 8])

        sparse_cross = tf.matmul(user_sparse, item_sparse, transpose_b=True)
        sparse_cross = tf.reshape(sparse_cross, [-1, user_s_shape * item_s_shape])

        with tf.variable_scope('Sparse_Cross_Layer') as dnn_hidden_layer_scope:
            sparse_net = layers.fully_connected(
                sparse_cross,
                64,
                activation_fn=get_act_fn(self.dnn_hidden_units_act_op[0]),
                scope=dnn_hidden_layer_scope,
                normalizer_fn=layers.batch_norm,
                normalizer_params={'scale': True, 'is_training': self.is_training}
            )

            sparse_net = tf.layers.dropout(
                sparse_net,
                rate=self.dropout,
                noise_shape=None,
                seed=None,
                training=self.is_training,
                name=None)

        return sparse_net


    def build_model(self):
         # build shared GRU 
        cell  = tf.nn.rnn_cell.GRUCell(num_units=128)

        logits_ctr, net_ctr = self._build_network('CTR')
        logits_cvr, net_cvr = self._build_network('CVR')

        cvr_net, _ = cell(net_cvr, net_ctr)

        self.ctr_logits = logits_ctr
        self.cvr_logits = logits_cvr
        with tf.variable_scope('Classifier'):
            with tf.variable_scope('CVR'):
                self.pvp_logits = layers.fully_connected(
                                cvr_net,
                                1,
                                activation_fn=None)

    def predict_op(self):
        with tf.name_scope('Predict'):
            self.ctr_prediction  = tf.sigmoid(self.ctr_logits)
            self.cvr_prediction  = tf.sigmoid(self.cvr_logits)
            self.pvp_prediction  = tf.sigmoid(self.pvp_logits)
            self.mpvp_prediction = self.ctr_prediction * self.cvr_prediction

    def loss_op(self):
        self.LOSSES = {
            'ctr' : LossFunc('bce')(y_true=self.click_label, y_pred = self.ctr_prediction, mask=None),
            'pvp' : LossFunc('bce')(y_true=self.pay_label,   y_pred = self.pvp_prediction, mask=None),
            'cvr' : LossFunc('bce')(y_true=self.pay_label,   y_pred = self.cvr_prediction, mask=self.click_label),
            'reg' : tf.reduce_sum(tf.get_collection(tf.GraphKeys.REGULARIZATION_LOSSES))
        }
        
        self.LOSSES['loss'] = self.loss = self.LOSSES['ctr'] + self.LOSSES['cvr'] + self.LOSSES['pvp'] + self.LOSSES['reg']

    def training_op(self):
        optimizer = tf.train.AdamOptimizer(learning_rate=self.learning_rate)
        self.update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)
        with tf.control_dependencies(self.update_ops):
            self.train_op = optimizer.minimize(self.loss, global_step=self.global_step)

        self.runner.add_train_ops([self.train_op])
        


    def mark_output(self):
        with tf.name_scope('Mark_Output'):
            rank_predict_ctr = tf.identity(self.ctr_prediction, name='rank_predict_ctr')
            rank_predict_cvr = tf.identity(self.pvp_prediction, name='rank_predict_cvr')
            rank_predict_lp  = tf.identity(self.pvp_prediction, name='rank_predict_lp')


        self.runner.add_inference_ops([self.unique_id,
                                       self.click_label,
                                       self.pay_label,
                                       self.ctr_prediction,
                                       self.cvr_prediction,
                                       self.pvp_prediction])


    def summary(self, local_mode=False):
        self.runner.add_auc(pred=self.ctr_prediction, label=self.click_label, mask=None, name='AUC_ctr')
        self.runner.add_auc(pred=self.cvr_prediction, label=self.pay_label, mask=self.click_label, name='AUC_cvr')
        self.runner.add_auc(pred=self.pvp_prediction, label=self.pay_label, mask=None, name='AUC_pvp')
        self.runner.add_auc(pred=self.mpvp_prediction,label=self.pay_label, mask=None, name='AUC_mpvp')

        self.runner.add_scalar(self.LOSSES['reg'],  'loss_reg')
        self.runner.add_scalar(self.LOSSES['ctr'],  'loss_ctr')
        self.runner.add_scalar(self.LOSSES['pvp'],  'loss_pvp')
        self.runner.add_scalar(self.LOSSES['loss'], 'loss_total')
