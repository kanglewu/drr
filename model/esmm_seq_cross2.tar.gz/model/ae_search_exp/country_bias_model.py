from __future__ import print_function
from base.model import BaseModel
from tensorflow.contrib import layers
from model_ops.attention import AttentionFeature
from model_ops.sequence import SequenceFeature
from model.ae_search_exp.action import ActionFeature
from model.ae_search_exp.query import Query
from model.ae_search_exp.sub_model import SubModel
from fg.feature_column_builder import FeatureColumnBuilder
from utils.config import parse_model_conf
import tensorflow as tf


class CountryBiasModel(BaseModel):

    def __init__(self, FLAGS, *args, **kwargs):
        super(CountryBiasModel, self).__init__(FLAGS, *args, **kwargs)
        self.FLAGS = FLAGS

        # job config
        self.ps_num = len(self.FLAGS.ps_hosts.split(','))

        # network hyper parameters
        self.dnn_l2_reg = FLAGS.dnn_l2_reg
        self.learning_rate = FLAGS.learning_rate
        self.embedding_partition_size = FLAGS.embedding_partition_size
        self.need_dropout = FLAGS.need_dropout
        self.dropout_rate = FLAGS.dropout_rate
        self.dnn_hidden_units = FLAGS.dnn_hidden_units
        self.dnn_hidden_units_act_op = FLAGS.dnn_hidden_units_act_op

        ######################################################################################################################
        #                                                                                                                    #
        #                                               Feature Group                                                        #
        #                                                                                                                    #
        ######################################################################################################################
        parse_model_conf(FLAGS)
        column_conf = FLAGS.mc_conf['input_columns']

        self.user_sparse_features = column_conf['user_sparse']
        self.user_dense_features = column_conf['user_dense']
        self.user_behavior_features = column_conf['user_behavior']
        self.item_sparse_features = column_conf['item_sparse']
        self.item_dense_features = column_conf['item_dense']
        self.item_behavior_features = column_conf['item_behavior']
        self.query_sparse_features = column_conf['query_sparse']
        self.country_id_features = column_conf['country_id']
        self.diverse_target_features = column_conf['diverse_target']

        ######################################################################################################################
        #                                                                                                                    #
        #                                               Feature Column                                                       #
        #                                                                                                                    #
        ######################################################################################################################
        self.column_builder = FeatureColumnBuilder(FLAGS, FLAGS.fg_conf, FLAGS.fc_conf)

        # feature column
        self.user_sparse_column = self.column_builder.get_column_list(self.user_sparse_features)
        self.user_dense_column = self.column_builder.get_column_list(self.user_dense_features)
        self.user_behavior_column = self.column_builder.get_column_list(self.user_behavior_features)
        self.item_sparse_column = self.column_builder.get_column_list(self.item_sparse_features)
        self.item_dense_column = self.column_builder.get_column_list(self.item_dense_features)
        self.item_behavior_column = self.column_builder.get_column_list(self.item_behavior_features)
        self.country_id_column = self.column_builder.get_column_list(self.country_id_features)
        self.diverse_target_column = self.column_builder.get_column_list(self.diverse_target_features)

        # price level column
        self.origin_item_price_level_column = [layers.real_valued_column(column_name='origin_item_price_level', dimension=1, default_value=0.0)]

        ######################################################################################################################
        #                                                                                                                    #
        #                                      Sequence & Attention & Query & Action Feature                                 #
        #                                                                                                                    #
        ######################################################################################################################
        self.sequence = SequenceFeature(column_conf['sequence_block'], column_conf['sequence_length_block'], self.column_builder)
        self.attention = AttentionFeature(column_conf['attention_block'], self.column_builder)
        self.query = Query(self.column_builder)
        self.user_action = ActionFeature(column_conf['user_action'], self.column_builder)
        self.query_action = ActionFeature(column_conf['query_action'], self.column_builder)

        ######################################################################################################################
        #                                                                                                                    #
        #                                               Graph Node                                                           #
        #                                                                                                                    #
        ######################################################################################################################
        self.ctr_sub_model = SubModel(self, 'CTR')
        self.cvr_sub_model = SubModel(self, 'CVR')
        self.reg_loss = None
        self.loss = None

        self.global_step = None
        self.is_training = None
        self.train_op = None
        self.sample_id = None


    def build(self, batch_data, *args, **kwargs):
        self._build_preliminary()
        self._build_inputs(batch_data)
        self._build_model()
        self._build_loss()
        self._build_optimizer()
        self._build_rtp()
        self._build_summary()
        self._build_runner()

    def _build_preliminary(self):
        tf.get_default_graph().set_shape_optimize(False)
        try:
            training = tf.get_default_graph().get_tensor_by_name('training:0')
        except KeyError:
            training = tf.placeholder_with_default(False, shape=(), name='training')
        self.is_training = training
        self.global_step = tf.Variable(initial_value=0, name='global_step', trainable=False,
                                       collections=[tf.GraphKeys.GLOBAL_STEP, tf.GraphKeys.GLOBAL_VARIABLES])

    def _build_inputs(self, batch_data):
        ctr_batch = batch_data.get('ctr_batch_data', None)
        cvr_batch = batch_data.get('cvr_batch_data', None)
        if ctr_batch is None or cvr_batch is None:
            raise Exception('invalid batch data')
        ctr_label = tf.to_float(tf.greater(tf.string_to_number(ctr_batch[3], out_type=tf.float32), 0.5))
        cvr_label = tf.to_float(tf.greater(tf.string_to_number(cvr_batch[3], out_type=tf.float32), 3.5))
        self.ctr_sub_model.build_inputs(ctr_batch[1], tf.reshape(ctr_label, [-1, 1]))
        self.cvr_sub_model.build_inputs(cvr_batch[1], tf.reshape(cvr_label, [-1, 1]))
        self.sample_id = tf.reshape(ctr_batch[0], [-1, 1])

    def _build_model(self):
        self.ctr_sub_model.build_model()
        self.cvr_sub_model.build_model()

    def _build_loss(self):
        with tf.name_scope('Loss'):
            self.ctr_sub_model.build_loss()
            self.cvr_sub_model.build_loss()
            self.reg_loss = tf.reduce_sum(tf.get_collection(tf.GraphKeys.REGULARIZATION_LOSSES))
            self.loss = self.ctr_sub_model.loss + self.cvr_sub_model.loss + self.reg_loss

    def _build_optimizer(self):
        varlist_p0 = [var for var in tf.trainable_variables() if 'Diverse_Network' not in var.name]
        varlist_p1 = [var for var in tf.trainable_variables() if 'Diverse_Network' in var.name]

        update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)
        with tf.control_dependencies(update_ops):
            train_op_0 = tf.train.AdamOptimizer(learning_rate=self.learning_rate).minimize(
                self.loss, global_step=self.global_step, var_list=varlist_p0)
            train_op_1 = tf.train.AdamOptimizer(learning_rate=self.learning_rate).minimize(
                self.loss, global_step=self.global_step, var_list=varlist_p1)

        self.train_op = train_op_0 if self.FLAGS.train_phase==0 else train_op_1

    def _build_rtp(self):
        with tf.name_scope('Mark_Output'):
            rank_predict_ctr = tf.identity(self.ctr_sub_model.predicts, name='rank_predict_ctr')
            rank_predict_cvr = tf.identity(self.cvr_sub_model.predicts, name='rank_predict_cvr')
            rank_predict_lp = tf.identity(self.ctr_sub_model.predicts * self.cvr_sub_model.predicts, name='rank_predict_lp')

    def _build_summary(self):
        self.ctr_sub_model.build_summary()
        self.cvr_sub_model.build_summary()

        with tf.name_scope('Summary/Cotrain'):
            tf.summary.scalar(name='Reg', tensor=self.reg_loss)
            tf.summary.scalar(name='Loss', tensor=self.loss)

    def _build_runner(self):
        self.runner.add_train_ops([self.train_op,
                                   self.ctr_sub_model.auc_update,
                                   self.cvr_sub_model.auc_update,
                                   ])

        self.runner.add_evaluate_ops([self.ctr_sub_model.auc_update,
                                      self.cvr_sub_model.auc_update,
                                      ])

        self.runner.add_inference_ops([self.sample_id,
                                       self.cvr_sub_model.labels,
                                       self.ctr_sub_model.labels,
                                       self.cvr_sub_model.predicts,
                                       self.ctr_sub_model.predicts])

        self.runner.add_log_ops(['global_step', 'loss', 'ctr_auc', 'cvr_auc'],
                                [self.global_step, self.loss, self.ctr_sub_model.auc, self.cvr_sub_model.auc])
