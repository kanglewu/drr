from __future__ import print_function
from schedule.mode import ModeKeys
from utils.util import get_act_fn
from tensorflow.contrib import layers
from tensorflow.contrib.framework.python.ops import arg_scope
from tensorflow.python.ops import variable_scope
from model_ops import ops as base_ops
from model_ops.attention import attention_4d
from model_ops.attentional_bias import attentional_bias
import tensorflow as tf


class SubModel(object):

    def __init__(self, cnty_bias_model, name, *args, **kwargs):
        self.cnty_bias_model = cnty_bias_model
        self.name = name
        self.labels = None
        self.input_dict = None
        self.loss = None
        self.logits = None
        self.predicts = None
        self.train_op = None
        self.auc = None
        self.auc_update = None

    def build_inputs(self, batch_features, batch_labels):
        with tf.name_scope('Input_Pipeline'):
            import rtp_fg
            fg_features = rtp_fg.parse_genreated_fg(self.cnty_bias_model.FLAGS.fg_conf, batch_features)
            self.cnty_bias_model.sequence.concat_seq_features(fg_features)
            self.cnty_bias_model.query.update_query_length(fg_features)
            SubModel._update_item_price(fg_features)
            self.labels = batch_labels

        with tf.variable_scope(name_or_scope='Input_Column',
                               partitioner=base_ops.partitioner(ps_num=self.cnty_bias_model.ps_num, mem=self.cnty_bias_model.embedding_partition_size),
                               reuse=tf.AUTO_REUSE):
            self.input_dict = self._build_input_layer(fg_features)

    def _build_input_layer(self, fg_features):
        user_sparse_input_layer = layers.input_from_feature_columns(fg_features, self.cnty_bias_model.user_sparse_column)
        user_dense_input_layer = layers.input_from_feature_columns(fg_features, self.cnty_bias_model.user_dense_column)
        user_behavior_input_layer = layers.input_from_feature_columns(fg_features, self.cnty_bias_model.user_behavior_column)
        item_sparse_input_layer = layers.input_from_feature_columns(fg_features, self.cnty_bias_model.item_sparse_column)
        item_dense_input_layer = layers.input_from_feature_columns(fg_features, self.cnty_bias_model.item_dense_column)
        item_behavior_input_layer = layers.input_from_feature_columns(fg_features, self.cnty_bias_model.item_behavior_column)
        query_token_input_layer = self.cnty_bias_model.query.get_query_token_layer(fg_features)
        sequence_length_layer_dict = self.cnty_bias_model.sequence.get_sequence_length_layer(fg_features)
        sequence_input_layer_dict = self.cnty_bias_model.sequence.get_sequence_layer(fg_features, sequence_length_layer_dict)
        attention_input_layer_dict = self.cnty_bias_model.attention.get_attention_layer(fg_features)
        item_price_level = layers.input_from_feature_columns(fg_features, self.cnty_bias_model.origin_item_price_level_column) / 20.0

        with tf.variable_scope('Diverse_Network_country_id') as t_name:
            country_id_input_layer = layers.input_from_feature_columns(fg_features, self.cnty_bias_model.country_id_column, scope=t_name)
        diverse_target_input_layer = layers.input_from_feature_columns(fg_features, self.cnty_bias_model.diverse_target_column)

        with tf.variable_scope(name_or_scope='Input_BN_{}'.format(self.name)):
            item_dense_input_layer = layers.batch_norm(item_dense_input_layer,
                                                       decay=0.9, scale=False, center=False,
                                                       epsilon=1e-6, activation_fn=tf.nn.relu,
                                                       is_training=self.cnty_bias_model.is_training)
            user_dense_input_layer = layers.batch_norm(user_dense_input_layer,
                                                       decay=0.9, scale=False, center=False,
                                                       epsilon=1e-6, activation_fn=tf.nn.relu,
                                                       is_training=self.cnty_bias_model.is_training)
            item_behavior_input_layer = tf.log1p(tf.nn.relu(item_behavior_input_layer))
            item_behavior_input_layer = layers.batch_norm(item_behavior_input_layer,
                                                          decay=0.9, scale=False, center=False,
                                                          epsilon=1e-6, activation_fn=tf.nn.relu,
                                                          is_training=self.cnty_bias_model.is_training)
            user_behavior_input_layer = tf.log1p(tf.nn.relu(user_behavior_input_layer))
            user_behavior_input_layer = layers.batch_norm(user_behavior_input_layer,
                                                          decay=0.9, scale=False, center=False,
                                                          epsilon=1e-6, activation_fn=tf.nn.relu,
                                                          is_training=self.cnty_bias_model.is_training)
        return {
            'user_sparse_input_layer': user_sparse_input_layer,
            'user_dense_input_layer': user_dense_input_layer,
            'user_behavior_input_layer': user_behavior_input_layer,
            'item_sparse_input_layer': item_sparse_input_layer,
            'item_dense_input_layer': item_dense_input_layer,
            'item_behavior_input_layer': item_behavior_input_layer,
            'query_token_input_layer': query_token_input_layer,
            'sequence_length_layer_dict': sequence_length_layer_dict,
            'sequence_input_layer_dict': sequence_input_layer_dict,
            'attention_input_layer_dict': attention_input_layer_dict,
            'item_price_level': item_price_level,
            'country_id_input_layer': country_id_input_layer,
            'diverse_target_input_layer': diverse_target_input_layer,
        }

    def build_model(self):
        with tf.variable_scope(name_or_scope='{}_SubModel'.format(self.name)):
            with arg_scope(base_ops.model_arg_scope(weight_decay=self.cnty_bias_model.dnn_l2_reg)):
                with tf.variable_scope(name_or_scope='Attention_Network'):
                    attention_input_layer = self._create_attention_network(self.input_dict['attention_input_layer_dict'],
                                                                           self.input_dict['sequence_input_layer_dict'],
                                                                           self.input_dict['sequence_length_layer_dict'],
                                                                           self.input_dict['query_token_input_layer'],
                                                                           dropout_rate=self.cnty_bias_model.dropout_rate)
                with tf.variable_scope(name_or_scope='Cross_Network'):
                    cross_input_layer = self._create_cross_network(self.input_dict['user_sparse_input_layer'],
                                                                   self.input_dict['item_sparse_input_layer'],
                                                                   self.input_dict['query_token_input_layer'],
                                                                   self.input_dict['sequence_input_layer_dict'],
                                                                   dropout_rate=self.cnty_bias_model.dropout_rate)

                with tf.variable_scope(name_or_scope='Diverse_Network_{}'.format(self.name)):
                    with arg_scope(base_ops.model_arg_scope(weight_decay=self.cnty_bias_model.dnn_l2_reg)):
                        diverse_logits = attentional_bias(
                            attention_input_layer=self.input_dict['country_id_input_layer'],
                            target_input_layer=self.input_dict['diverse_target_input_layer'],
                            hidden_size = [64,32],
                            is_training=self.cnty_bias_model.is_training
                        )

                with tf.variable_scope(name_or_scope='DNN_Network'):
                    query_shape = self.input_dict['query_token_input_layer'].shape.as_list()
                    query_token_input_layer = tf.reshape(self.input_dict['query_token_input_layer'], [-1, query_shape[1] * query_shape[2]])
                    net = tf.concat([self.input_dict['user_dense_input_layer'],
                                     self.input_dict['user_behavior_input_layer'],
                                     self.input_dict['item_dense_input_layer'],
                                     self.input_dict['item_behavior_input_layer'],
                                     self.input_dict['user_sparse_input_layer'],
                                     self.input_dict['item_sparse_input_layer'],
                                     query_token_input_layer,
                                     attention_input_layer,
                                     cross_input_layer,
                                     ], axis=1)
                    for layer_id, num_hidden_units in enumerate(self.cnty_bias_model.dnn_hidden_units):
                        with variable_scope.variable_scope('Hidden_{}'.format(layer_id)):
                            net = layers.fully_connected(net,
                                                         num_hidden_units,
                                                         activation_fn=get_act_fn(self.cnty_bias_model.dnn_hidden_units_act_op[layer_id]),
                                                         normalizer_fn=layers.batch_norm,
                                                         normalizer_params={'scale': True, 'is_training': self.cnty_bias_model.is_training}
                                                         )
                            if self.cnty_bias_model.need_dropout and self.cnty_bias_model.dropout_rate > 0:
                                net = tf.layers.dropout(net, rate=self.cnty_bias_model.dropout_rate, training=self.cnty_bias_model.is_training)

                    with tf.variable_scope(name_or_scope='Logits'):
                        logits = layers.fully_connected(net, 1, activation_fn=None)

                    if self.cnty_bias_model.FLAGS.train_phase == 0:
                        logits_out = tf.cond(self.cnty_bias_model.is_training,
                                             lambda: tf.add(logits, tf.constant(value=0.0, dtype=tf.float32)),
                                             lambda: tf.add(logits, diverse_logits))
                    else:
                        logits_out = logits + diverse_logits
                    self.logits = logits_out

    def build_loss(self):
        self.predicts = tf.sigmoid(self.logits)
        with tf.name_scope('Loss'):
            self.loss = tf.reduce_mean(
                tf.nn.sigmoid_cross_entropy_with_logits(labels=self.labels, logits=self.logits))

    def build_optimizer(self):
        optimizer = tf.train.AdamOptimizer(learning_rate=self.cnty_bias_model.learning_rate)
        update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)
        with tf.control_dependencies(update_ops):
            self.train_op = optimizer.minimize(self.loss, global_step=self.cnty_bias_model.global_step)

    def build_summary(self):
        with tf.name_scope('Metrics/{}'.format(self.name)):
            if self.cnty_bias_model.FLAGS.mode == ModeKeys.LOCAL:
                self.auc, self.auc_update = tf.metrics.auc(labels=self.labels,
                                                           predictions=self.predicts,
                                                           num_thresholds=2000)
            else:
                worker_device = '/job:worker/task:{}'.format(self.cnty_bias_model.FLAGS.task_index)
                with tf.device(worker_device):
                    self.auc, self.auc_update = tf.metrics.auc(labels=self.labels,
                                                               predictions=self.predicts,
                                                               num_thresholds=2000)
        with tf.name_scope('Summary/{}'.format(self.name.upper())):
            tf.summary.scalar(name='AUC', tensor=self.auc)
            tf.summary.scalar(name='Loss', tensor=self.loss)
            tf.summary.scalar(name='Label_Mean', tensor=tf.reduce_mean(self.labels))
            tf.summary.scalar(name='Predict_Mean', tensor=tf.reduce_mean(self.predicts))

    @staticmethod
    def _update_item_price(features):
        item_price_level = features['item_price_level']
        features.update({'origin_item_price_level': item_price_level})

    def _create_attention_network(self,
                                  attention_input_layer_dict,
                                  sequence_input_layer_dict,
                                  sequence_length_layer_dict,
                                  query_token_input_layer,
                                  units=16,
                                  dropout_rate=0.0):
        common_lst = []
        for name, layer in sequence_input_layer_dict.items():
            if name not in attention_input_layer_dict:
                common_lst.append(layer)
        common_layer = tf.add_n(common_lst)

        seq_layer_list, query_layer_list, seq_length_list = [], [], []
        for name, query_layers in attention_input_layer_dict.items():
            seq_layer = sequence_input_layer_dict[name]
            seq_length = sequence_length_layer_dict.get(name, None)
            if seq_length is None:
                raise Exception('keys {} length is None'.format(name))
            if name.endswith('cate_id'):  # same cate_id within the whole sequence
                seq_layer += common_layer
            query_layer = tf.concat([query_token_input_layer] + query_layers, axis=1)

            seq_layer_list.append(tf.expand_dims(seq_layer, axis=1))
            seq_length_list.append(tf.expand_dims(seq_length, axis=1))
            query_layer_list.append(tf.expand_dims(query_layer, axis=1))

        seq_layer = tf.concat(seq_layer_list, axis=1)
        seq_length = tf.concat(seq_length_list, axis=1)
        query_layer = tf.concat(query_layer_list, axis=1)

        # self attention
        with variable_scope.variable_scope('self'):
            # (?, N, T_q, C), (?, N, T_q, T_k)
            seq_vec, att_vec = attention_4d(queries=seq_layer,
                                            queries_length=seq_length,
                                            keys=seq_layer,
                                            keys_length=seq_length,
                                            query_masks=None,
                                            key_masks=None)
            seq_shape = seq_layer.shape.as_list()
            self_att_vec = tf.concat([seq_vec, att_vec], axis=-1)
            self_att_vec = tf.reshape(self_att_vec, [-1, seq_shape[1], seq_shape[2] * (seq_shape[3] + seq_shape[2])])
            # project network
            self_att_net = layers.fully_connected(
                self_att_vec,
                units,
                activation_fn=get_act_fn(self.cnty_bias_model.dnn_hidden_units_act_op[0]),
                normalizer_fn=layers.batch_norm,
                normalizer_params={'scale': True, 'is_training': self.cnty_bias_model.is_training}
            )
            if self.cnty_bias_model.need_dropout and dropout_rate > 0:
                self_att_net = tf.layers.dropout(self_att_net, rate=dropout_rate, training=self.cnty_bias_model.is_training)

        # cross attention
        with variable_scope.variable_scope('cross'):
            seq_vec, att_vec = attention_4d(queries=query_layer,
                                            queries_length=None,
                                            keys=seq_layer,
                                            keys_length=seq_length,
                                            query_masks=None,
                                            key_masks=None)
            query_shape = query_layer.shape.as_list()
            cross_att_vec = tf.concat([seq_vec, att_vec], axis=-1)
            cross_att_vec = tf.reshape(cross_att_vec, [-1, query_shape[1], query_shape[2] * (query_shape[3] + seq_shape[2])])
            # project network
            cross_att_net = layers.fully_connected(
                cross_att_vec,
                units,
                activation_fn=get_act_fn(self.cnty_bias_model.dnn_hidden_units_act_op[0]),
                normalizer_fn=layers.batch_norm,
                normalizer_params={'scale': True, 'is_training': self.cnty_bias_model.is_training}
            )
            if self.cnty_bias_model.need_dropout and dropout_rate > 0:
                cross_att_net = tf.layers.dropout(cross_att_net, rate=dropout_rate,
                                                  training=self.cnty_bias_model.is_training)

        att_output_layer = tf.concat([self_att_net, cross_att_net], axis=-1)
        att_shape = att_output_layer.shape.as_list()
        attention_output_layer = tf.reshape(att_output_layer, [-1, att_shape[1] * att_shape[2]])
        return attention_output_layer

    def _create_cross_network(self,
                              user_sparse_input_layer,
                              item_sparse_input_layer,
                              query_token_input_layer,
                              sequence_input_layer_dict,
                              dim=8,
                              units=64,
                              dropout_rate=0.0):
        user_s_shape = user_sparse_input_layer.shape.as_list()[1] // dim
        user_sparse = tf.reshape(user_sparse_input_layer, [-1, user_s_shape, dim])

        seq_sparse = []
        for name, layer in sequence_input_layer_dict.items():
            seq_sparse.append(tf.reduce_sum(layer, axis=1, keep_dims=True))
        seq_sparse = tf.concat(seq_sparse, axis=1)

        user_sparse = tf.concat([user_sparse, seq_sparse, query_token_input_layer], axis=1)
        user_s_shape = user_sparse.shape.as_list()[1]

        item_s_shape = item_sparse_input_layer.shape.as_list()[1] // dim
        item_sparse = tf.reshape(item_sparse_input_layer, [-1, item_s_shape, dim])

        sparse_cross = tf.matmul(user_sparse, item_sparse, transpose_b=True)
        sparse_cross = tf.reshape(sparse_cross, [-1, user_s_shape * item_s_shape])

        with variable_scope.variable_scope('Sparse_Cross_Layer'):
            sparse_net = layers.fully_connected(
                sparse_cross,
                units,
                activation_fn=get_act_fn(self.cnty_bias_model.dnn_hidden_units_act_op[0]),
                normalizer_fn=layers.batch_norm,
                normalizer_params={'scale': True, 'is_training': self.cnty_bias_model.is_training}
            )
            if self.cnty_bias_model.need_dropout and dropout_rate > 0:
                sparse_net = tf.layers.dropout(
                    sparse_net,
                    rate=dropout_rate,
                    noise_shape=None,
                    seed=None,
                    training=self.cnty_bias_model.is_training,
                    name=None)

        return sparse_net

