from __future__ import print_function
import tensorflow as tf
from tensorflow.contrib import layers
from tensorflow.contrib.framework.python.ops import arg_scope
from tensorflow.python.ops import variable_scope
from model_ops import ops as base_ops
from tensorflow.python.ops import control_flow_ops
from fg.feature_column_builder import FeatureColumnBuilder
from utils.config import parse_model_conf


from base.model import BaseModel
from schedule.mode import ModeKeys
from utils.util import get_act_fn
from collections import OrderedDict
from model_ops.attention import attention, attention_4d



class AERecModel(BaseModel):

    #test done
    def __init__(self, FLAGS,*args, **kwargs):
        super(AERecModel, self).__init__(FLAGS, *args, **kwargs)

        self.FLAGS = FLAGS




        # job config
        self.ps_num = len(self.FLAGS.ps_hosts.split(","))
        self.max_checkpoints_to_keep = self.FLAGS.max_checkpoints_to_keep

        # model structure config
        self.dnn_hidden_units = FLAGS.dnn_hidden_units
        self.dnn_hidden_units_act_op = FLAGS.dnn_hidden_units_act_op
        self.learning_rate = FLAGS.learning_rate
        self.dnn_l2_reg = FLAGS.dnn_l2_reg
        self.max_grad_norm = FLAGS.max_grad_norm
        self.ortho_init_scale = FLAGS.ortho_init_scale
        self.need_dropout = FLAGS.need_dropout
        self.dropout_rate = FLAGS.dropout_rate
        self.embedding_partition_size = FLAGS.embedding_partition_size

        print("dnn_l2_reg-%s" % self.dnn_l2_reg)
        print("learning_rate-%s" % self.learning_rate)

        parse_model_conf(FLAGS)
        column_conf = FLAGS.mc_conf['input_columns']

        self.user_features = column_conf['user']
        self.query_features = column_conf['query']
        self.item_sparse_features = column_conf['item_sparse']
        self.item_dense_features = column_conf['item_dense']
        self.ui_features = column_conf['ui']
        self.context_features = column_conf['context']
        self.trick_features = column_conf['trick']
        
        # print("user_features-%s" % self.user_features)

        # all features
        self.all_features = (self.user_features + self.query_features + self.item_sparse_features
                             + self.item_dense_features + self.ui_features + self.context_features
                             + self.trick_features)

        print(len(self.all_features))  # => 497


        self.column_builder = FeatureColumnBuilder(FLAGS, FLAGS.fg_conf, FLAGS.fc_conf)


        # Feature Column of BaseModel
        self.user_column        = self.column_builder.get_column_list(self.user_features)
        self.item_sparse_column = self.column_builder.get_column_list(self.item_sparse_features)
        self.item_dense_column  = self.column_builder.get_column_list(self.item_dense_features)

        # print("user_column-%s" % self.user_column)


        # A string Tensor with shape [batch_size, 1].
        self.ctr_id = None
        
        self.cvr_id = None
        # A batch of dict of feature-name & feature-value.
        self.features = None
        self.ctr_features = None
        self.cvr_features = None

        # A int32 Tensor with shape [batch_size, 1].
        self.ctr_label = None
        self.cvr_label = None

        # Base Layer. A float32 Tensor with shape [batch_size, N-dim].
        self.user_input_layer = None
        self.query_input_layer = None
        self.item_sparse_input_layer = None
        self.item_dense_input_layer = None
        self.ui_input_layer = None
        self.context_input_layer = None
        # Cross Layer
        self.query_item_cross_layer = None

        # A float32 Tensor with shape [batch_size, 1].
        self.ctr_logits = None

        # A float32 Tensor with shape [batch_size, 1]. after sigmoid
        self.ctr_predictions = None

        # A float32 scalar Tensor; the total loss for the trainer to optimize.
        self.loss = None

        # Define model variables collection
        self.collections_dnn_hidden_layer = "collections_dnn_hidden_layer"
        self.collections_dnn_hidden_output = "collections_dnn_hidden_output"

        # model name
        self.name = "AERecModel"

        # A trace dict,key is feature_name and value is [original feature,output feature]
        self.trace = {}

        self.ctr_train_op = None
        self.cvr_train_op = None
        self.current_ctr_auc = None
        self.current_cvr_auc = None
        self.ctr_auc_update_op = None
        self.cvr_auc_update_op = None

        super(AERecModel, self).__init__(FLAGS, *args, **kwargs)



    #done
    def _set_shape_optimize(self):
        tf.get_default_graph().set_shape_optimize(False)

    #done
    def _build_placeholder(self):
        try:
            training = tf.get_default_graph().get_tensor_by_name("training:0")
        except KeyError as e:
            training = tf.placeholder(tf.bool, name="training")
        self.is_training = training


    # def _build_ctr_train_placeholder(self):
    #     try:
    #         ctr_training = tf.get_default_graph().get_tensor_by_name("ctr_train:0")
    #     except KeyError as e:
    #         ctr_training = tf.placeholder(tf.bool, name="ctr_train")
    #     self.is_ctr_training = ctr_training


    #becareful done
    def _build_inputs(self, batch_data):

        ctr_batch_data = batch_data.get('ctr_batch_data', None)
        cvr_batch_data = batch_data.get('cvr_batch_data', None)
        if ctr_batch_data is None or cvr_batch_data is None:
            raise Exception('invalid batch data')

        with tf.name_scope("%s_Input_Pipeline" % self.name):
            self.build_training_inputs(ctr_batch_data, cvr_batch_data)

    # def _build_global_step(self):
    #     self.global_step = tf.Variable(
    #         initial_value=0,
    #         name="global_step",
    #         trainable=False,
    #         collections=[tf.GraphKeys.GLOBAL_STEP, tf.GraphKeys.GLOBAL_VARIABLES])

    #     self.global_step_reset = tf.assign(self.global_step, 0)
    #     self.global_step_add = tf.assign_add(self.global_step, 1, use_locking=True)

    def _build_global_step(self):
        self.global_step = tf.Variable(initial_value=0, name='global_step', trainable=False,
                                       collections=[tf.GraphKeys.GLOBAL_STEP, tf.GraphKeys.GLOBAL_VARIABLES])


    #done
    def build_model(self):

        def build_model_from_input(input, name):
            net = input

            with tf.variable_scope(name_or_scope="%s-DNN" % name):
                with arg_scope(base_ops.model_arg_scope(weight_decay=self.dnn_l2_reg)):

                    #mlp
                    for layer_id, num_hidden_units in enumerate(self.dnn_hidden_units):
                        with variable_scope.variable_scope(
                                "Hidden_Layer_%d" % layer_id) as dnn_hidden_layer_scope:

                            net = layers.fully_connected(
                                net,
                                num_hidden_units,
                                activation_fn=get_act_fn(self.dnn_hidden_units_act_op[layer_id]),
                                variables_collections=[self.collections_dnn_hidden_layer],
                                outputs_collections=[self.collections_dnn_hidden_output],
                                scope=dnn_hidden_layer_scope,
                                normalizer_fn=layers.batch_norm,
                                normalizer_params={"scale": True,
                                                   "is_training": self.get_is_training()}
                            )

                            if self.need_dropout:
                                net = tf.layers.dropout(
                                    net,
                                    rate=self.dropout_rate,
                                    noise_shape=None,
                                    seed=None,
                                    training=self.get_is_training(),
                                    name=None)

                    #score
                    with tf.variable_scope(name_or_scope="Logits") as deep_logits_scope:
                        with arg_scope(base_ops.model_arg_scope(weight_decay=self.dnn_l2_reg)):
                            concat_layer = tf.concat([net], axis=1)
                            logits = layers.fully_connected(
                                concat_layer,
                                1,
                                activation_fn=None,
                                variables_collections=[self.collections_dnn_hidden_layer],
                                outputs_collections=[self.collections_dnn_hidden_output],
                                scope=deep_logits_scope)

            return net, logits

        def build_input_layer(features, name):

            self.user_input_layer = layers.input_from_feature_columns(features, self.user_column, scope=scope)

            self.item_sparse_input_layer = layers.input_from_feature_columns(features, self.item_sparse_column,scope=scope)

            self.item_dense_input_layer = layers.input_from_feature_columns(features, self.item_dense_column,scope=scope)
            
            # bn for dense
            self.user_input_layer = layers.batch_norm(self.user_input_layer,scale=True,is_training=self.get_is_training())

            self.item_dense_input_layer = layers.batch_norm(self.item_dense_input_layer,scale=True,is_training=self.get_is_training())


            self.input = tf.concat([self.user_input_layer, self.item_sparse_input_layer,self.item_dense_input_layer], axis=1)

            return self.input


        #features 
        if not (self.ctr_features and isinstance(self.ctr_features, dict)):
            raise ValueError("features must be defined and must be a dict.")
        if not self.dnn_hidden_units:
            raise ValueError("configuration dnn_hidden_units must be defined.")


        #input layer
        with tf.variable_scope(
                name_or_scope="input_from_feature_columns",
                partitioner=base_ops.partitioner(ps_num=self.ps_num, mem=self.embedding_partition_size),
                reuse=tf.AUTO_REUSE) as scope:
            self.ctr_input = build_input_layer(self.ctr_features, scope)
            self.cvr_input = build_input_layer(self.cvr_features, scope)


        #build net 
        with tf.variable_scope(name_or_scope="%s-Score-Network" % self.name,
                               partitioner=base_ops.partitioner(
                               ps_num=self.ps_num,
                               mem=self.embedding_partition_size)):
            # self.input = tf.concat([self.user_input_layer, self.item_sparse_input_layer,self.item_dense_input_layer], axis=1)

            #add to collection??? why
            tf.add_to_collection(self.collections_dnn_hidden_output, self.ctr_input)

            #ctr_net last, score
            self.ctr_net, self.ctr_logits = build_model_from_input(self.ctr_input, "CTR")
            self.cvr_net, self.cvr_logits = build_model_from_input(self.cvr_input, "CVR")

    #done
    def _build_inference_op(self):
        with tf.name_scope("Predict"):
            self.ctr_predictions = tf.sigmoid(self.ctr_logits)
            self.cvr_predictions = tf.sigmoid(self.cvr_logits)

    #diff done
    def _build_loss_op(self):
        with tf.name_scope("Loss"):
            self.ctr_loss = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(
                labels=self.ctr_label,
                logits=self.ctr_logits))

            self.cvr_loss = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(
                labels=self.cvr_label,
                logits=self.cvr_logits))

            #??? reg_loss
            self.reg_loss = tf.get_collection(tf.GraphKeys.REGULARIZATION_LOSSES)
            self.reg_loss = tf.reduce_sum(self.reg_loss)

            # self.total_ctr_loss = self.ctr_loss + self.reg_loss
            # self.total_cvr_loss = self.cvr_loss + self.reg_loss

            self.total_ctr_loss = self.ctr_loss
            self.total_cvr_loss = self.cvr_loss


    #done convert to up at the same time
    def _build_training_op(self):
        optimizer = tf.train.AdamOptimizer(learning_rate=self.learning_rate)
        self.update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)
        with tf.control_dependencies(self.update_ops):
            self.ctr_train_op = optimizer.minimize(self.total_ctr_loss, global_step=self.global_step)
            self.cvr_train_op = optimizer.minimize(self.total_cvr_loss, global_step=self.global_step)


    # def training_op(self, name, loss):
        
    #     params = tf.trainable_variables()
        
    #     all_update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)
        
    #     optimizer = tf.train.AdamOptimizer(learning_rate=self.learning_rate, name='optimizer-%s' % name)

    #     grads = tf.gradients(loss, params)
    #     grads, _ctr_grad_norm = tf.clip_by_global_norm(grads, self.max_grad_norm)
    #     grads = list(zip(grads, params))
        
    #     with tf.control_dependencies(all_update_ops):
    #         self.train_op = optimizer.apply_gradients(grads, global_step=self.global_step)

    #     return self.train_op
       

    #done
    def setup_saver(self):
        self.saver = tf.train.Saver(max_to_keep=self.max_checkpoints_to_keep)

    #done
    def _build_rtp_op(self):
        with tf.name_scope("Mark_Output"):
            rank_predict_ctr = tf.identity(self.ctr_predictions, name='rank_predict_ctr')
            rank_predict_cvr = tf.identity(self.cvr_predictions, name='rank_predict_cvr')
            rank_predict_lp = tf.identity(self.ctr_predictions * self.cvr_predictions, name='rank_predict_lp')

    #done
    def _build_summary(self):
        with tf.name_scope("Metrics"):
            if self.FLAGS.mode == ModeKeys.LOCAL:
                self.current_ctr_auc, self.ctr_auc_update_op = tf.metrics.auc(
                    labels=self.ctr_label,
                    predictions=self.ctr_predictions,
                    num_thresholds=2000)
                self.current_cvr_auc, self.cvr_auc_update_op = tf.metrics.auc(
                    labels=self.cvr_label,
                    predictions=self.cvr_predictions,
                    num_thresholds=2000)
            else:
                worker_device = "/job:worker/task:{}".format(self.FLAGS.task_index)
                with tf.device(worker_device):
                    self.current_ctr_auc, self.ctr_auc_update_op = tf.metrics.auc(
                        labels=self.ctr_label,
                        predictions=self.ctr_predictions,
                        num_thresholds=2000)
                    self.current_cvr_auc, self.cvr_auc_update_op = tf.metrics.auc(
                        labels=self.cvr_label,
                        predictions=self.cvr_predictions,
                        num_thresholds=2000)

        with tf.name_scope("Summary"):
            tf.summary.scalar(name="scalar/auc", tensor=self.current_ctr_auc)
            tf.summary.scalar(name="scalar/cvr_auc", tensor=self.current_cvr_auc)
            tf.summary.scalar(name="scalar/ctr_loss", tensor=self.ctr_loss)
            tf.summary.scalar(name="scalar/reg_loss", tensor=self.reg_loss)
            tf.summary.scalar(name="scalar/cvr_loss", tensor=self.cvr_loss)
            tf.summary.scalar(name="scalar/logits_max", tensor=tf.reduce_max(self.ctr_logits))
            tf.summary.scalar(name="scalar/logits_min", tensor=tf.reduce_min(self.ctr_logits))
            tf.summary.scalar(name="scalar/logits_sum", tensor=tf.reduce_sum(self.ctr_logits))
            tf.summary.scalar(name="scalar/logits_size", tensor=tf.size(self.ctr_logits))
            tf.summary.scalar(name="scalar/label_mean", tensor=tf.reduce_mean(self.ctr_label))
            tf.summary.scalar(name="scalar/logits_mean", tensor=tf.reduce_mean(self.ctr_logits))
            tf.summary.scalar(name="scalar/predictions_mean", tensor=tf.reduce_mean(self.ctr_predictions))

    def trace_op(self):
        """
        trace feature input and feature output
        :return:
        """
        with tf.variable_scope(
                name_or_scope="input_from_feature_columns",
                partitioner=base_ops.partitioner(self.ps_num,
                                                 mem=self.embedding_partition_size),
                reuse=tf.AUTO_REUSE) as scope:
            columns = self.user_column + self.item_sparse_column + self.item_dense_column
            for column in columns:
                feature_name = column.name
                feature_inputs = column.config.keys()
                # not support for two input
                assert len(feature_inputs) == 1
                feature_original = self.features[feature_inputs[0]]
                feature_output = layers.input_from_feature_columns(self.features, [column], scope=scope)
                self.trace[feature_name] = [feature_original, feature_output]


    # def build_local_inputs(self, batch_data, use_fg):
    #     if use_fg:
    #         self.build_training_inputs(batch_data)
    #         return

    #     #???
    #     features = {"user_sex": batch_data[0],
    #                 "origin_keyword_hash": batch_data[1],
    #                 "s_nid_ctr_30": tf.string_to_number(batch_data[3], out_type=tf.float32),
    #                 'label': tf.reshape(tf.string_to_number(batch_data[4], out_type=tf.float32), [-1, 1]),
    #                 'click_weight': tf.reshape(tf.string_to_number(batch_data[5], out_type=tf.float32), [-1, 1])
    #                 }
    #     self.features = features
    #     self.ctr_label = features['label']


    #feature diff
    def build_training_inputs(self, ctr_batch_data, cvr_batch_data):

        import rtp_fg

        #batch_data[2] => [id,label,feature]
        self.ctr_features = rtp_fg.parse_genreated_fg(self.column_builder._fg_config, tf.squeeze(ctr_batch_data[2]))
        self.cvr_features = rtp_fg.parse_genreated_fg(self.column_builder._fg_config, tf.squeeze(cvr_batch_data[2]))


        self.tmp_ctr_labels = tf.map_fn(lambda x: tf.string_split(x, delimiter=';').values, tf.reshape(ctr_batch_data[1],[-1,1]))
        self.ctr_label = tf.reshape(tf.string_to_number(self.tmp_ctr_labels[:,0],out_type=tf.float32),[-1,1])

        self.tmp_cvr_labels = tf.map_fn(lambda x: tf.string_split(x, delimiter=';').values, tf.reshape(cvr_batch_data[1],[-1,1]))
        self.cvr_label = tf.reshape(tf.string_to_number(self.tmp_cvr_labels[:,1],out_type=tf.float32),[-1,1])


    @property
    def model_name(self):
        return self.name

    def get_is_training(self):
        try:
            training = tf.get_default_graph().get_tensor_by_name("training:0")
        except KeyError as e:
            training = tf.placeholder(tf.bool, name="training")
        return training


    # def get_is_train_ctr(self):
    #     try:
    #         self.is_train_ctr = tf.get_default_graph().get_tensor_by_name("ctr_train:0")
    #     except KeyError as e:
    #         self.is_train_ctr = tf.placeholder(tf.bool, name="ctr_train")
    #     return self.is_train_ctr


    #tmp local_mode to true
    def build(self, batch_data):
        """Creates all ops for training and evaluation."""

        self._set_shape_optimize()
        self._build_placeholder()
        # self._build_ctr_train_placeholder()
        self._build_global_step()
        self._build_inputs(batch_data)

        #key model
        self.build_model()
        self._build_inference_op()
        self._build_loss_op()
        self._build_training_op()
        # self.setup_saver()
        self._build_rtp_op()
        self._build_summary()
        self._build_runner()

        #build ctr/cvr op sepratly ??? why
        # self.ctr_train_op = tf.cond(tf.logical_and(self.get_is_training(),self.get_is_train_ctr()),
        #     lambda: self.training_op('CTR', self.total_ctr_loss),lambda:control_flow_ops.no_op())

        # self.cvr_train_op = tf.cond(tf.logical_and(self.get_is_training(),tf.logical_not(self.get_is_train_ctr())),
        #     lambda: self.training_op('CVR', self.total_cvr_loss),lambda:control_flow_ops.no_op())
        



    #done
    def _build_runner(self):
        self.runner.add_train_ops([self.ctr_train_op,
                                   self.cvr_train_op,
                                   self.ctr_auc_update_op,
                                   self.cvr_auc_update_op
                                   ])


        self.runner.add_evaluate_ops([self.ctr_auc_update_op,
                                      self.cvr_auc_update_op])

        self.runner.add_inference_ops([self.ctr_id,
                                       self.cvr_label,
                                       self.ctr_label,
                                       self.cvr_predictions,
                                       self.ctr_predictions])

        self.runner.add_log_ops(['global_step', 'ctr_loss', 'cvr_loss', 'ctr_auc', 'cvr_auc'],
                                [self.global_step, self.total_ctr_loss, self.total_cvr_loss, self.current_ctr_auc, self.current_cvr_auc])

