#coding:utf8

from __future__ import print_function
from base.model import BaseModel
from utils.util import get_act_fn
from tensorflow.contrib import layers
from tensorflow.python.framework import ops
from fg.feature_column_builder import FeatureColumnBuilder
from utils.config import parse_model_conf
from lzd_rec_model_ops.dnn_fn import dnn_layer,dnn_multihead_attention_count_without_forward,keep_multihead_attention,dnn_multihead_attention
from model_ops.lr_ops import lr_warm_restart
from model_ops.sequence import SequenceFeature
from lzd_rec_runner import LzdRecRunner
import tensorflow as tf
import json

class LzdRecModel(BaseModel):

    def __init__(self, FLAGS, *args, **kwargs):
        super(LzdRecModel, self).__init__(FLAGS, *args, **kwargs)


        self.FLAGS = FLAGS
        self.runner = LzdRecRunner(FLAGS)
        # job config
        self.ps_num = len(self.FLAGS.ps_hosts.split(','))

        # network hyper parameters
        self.periodic_step = int(FLAGS.data_size / FLAGS.batch_size)
        self.train_step = FLAGS.begin_step + int(FLAGS.data_size * FLAGS.num_epoch / FLAGS.batch_size)
        self.mode = FLAGS.mode

        self._variable_partitioner = tf.min_max_variable_partitioner(
            max_partitions=self.ps_num,
            min_slice_size=(256 * 1024 * 1024),
            bytes_per_string_element=16)

        self.ubb_time = [3, 7, 14, 30, 90]
        self.ubb_neg_time = [3, 7, 14, 30]

        ######################################################################################################################
        #                                                                                                                    #
        #                                               Feature Group                                                        #
        #                                                                                                                    #
        ######################################################################################################################
        parse_model_conf(FLAGS)
        self.model_conf = FLAGS.mc_conf
        column_conf = self.model_conf['input_columns']

        self.user_sparse_features = column_conf['user_sparse']
        self.item_sparse_features = column_conf['item_sparse']
        self.item_dense_features = column_conf['item_dense']
        self.item_realtime_features = column_conf['item_real']
        self.match_features = column_conf['match_feature']
        self.seq_length_features = column_conf['seq_length']

        ######################################################################################################################
        #                                                                                                                    #
        #                                               Feature Column                                                       #
        #                                                                                                                    #
        ######################################################################################################################

        self.column_builder = FeatureColumnBuilder(FLAGS, FLAGS.fg_conf, FLAGS.fc_conf)

        # feature column
        self.user_sparse_column = self.column_builder.get_column_list(self.user_sparse_features)
        self.item_sparse_column = self.column_builder.get_column_list(self.item_sparse_features)
        self.item_dense_column = self.column_builder.get_column_list(self.item_dense_features)
        self.item_realtime_column = self.column_builder.get_column_list(self.item_realtime_features)
        self.match_column = self.column_builder.get_column_list(self.match_features)
        self.sequence = SequenceFeature(column_conf['sequence_block'], column_conf['sequence_length_block'],self.column_builder)
        self.seq_length_column = self.column_builder.get_column_list(self.seq_length_features)
        self.ubb_column_dict = {}

        for i in self.ubb_time:
            ubb_jfy_id_name = 'user_item_clk_jfy_%d_id' % i
            ubb_jfy_value_name = 'user_item_clk_jfy_%d_value' % i
            ubb_allnet_id_name = 'user_item_clk_allnet_%d_id' % i
            ubb_allnet_value_name = 'user_item_clk_allnet_%d_value' % i

            self.ubb_column_dict[ubb_jfy_id_name] = self.column_builder.get_column_list([ubb_jfy_id_name])
            self.ubb_column_dict[ubb_jfy_value_name] = self.column_builder.get_column_list([ubb_jfy_value_name])
            self.ubb_column_dict[ubb_allnet_id_name] = self.column_builder.get_column_list([ubb_allnet_id_name])
            self.ubb_column_dict[ubb_allnet_value_name] = self.column_builder.get_column_list([ubb_allnet_value_name])

        for i in self.ubb_neg_time:
            ubb_noclk_jfy_id_name = 'user_item_noclk_jfy_%d_id' % i
            ubb_noclk_jfy_value_name = 'user_item_noclk_jfy_%d_value' % i
            self.ubb_column_dict[ubb_noclk_jfy_id_name] = self.column_builder.get_column_list([ubb_noclk_jfy_id_name])
            self.ubb_column_dict[ubb_noclk_jfy_value_name] = self.column_builder.get_column_list([ubb_noclk_jfy_value_name])



    def build(self, batch_data, *args, **kwargs):
        LzdRecModel._set_shape_optimize()
        self._build_placeholder()
        self._build_global_step()
        self._build_inputs(batch_data)
        self._build_model()
        self._build_inference_op()
        self._build_loss_op()
        self._build_training_op()
        self._build_rtp_op()
        self._build_summary()
        self._build_runner()

    @staticmethod
    def _set_shape_optimize():
        tf.get_default_graph().set_shape_optimize(False)

    def _build_placeholder(self):
        try:
            training = tf.get_default_graph().get_tensor_by_name('training:0')
        except KeyError:
            training = tf.placeholder_with_default(False, shape=(), name='training')
        self.is_training = training

    def _build_global_step(self):
        self.global_step = tf.Variable(initial_value=0, name='global_step', trainable=False,
                                       collections=[tf.GraphKeys.GLOBAL_STEP, tf.GraphKeys.GLOBAL_VARIABLES])

    def _build_inputs(self, batch_data):
        self.features = batch_data.get('features')
        self.labels = batch_data.get('labels')

    def _build_model(self):
        def pool(ubb_combiner, value, name, axis=1):
            with tf.variable_scope(name + 'pool', partitioner=None):
                embedding_i_pool = []
                for method in ubb_combiner.split(','):
                    if method == 'sum':
                        ubbi = tf.reduce_sum(value, axis=axis)
                    elif method == 'max':
                        ubbi = tf.reduce_max(value, axis=axis)
                    elif method == 'avg':
                        ubbi = tf.divide(tf.reduce_sum(value, axis=1),tf.cast(tf.count_nonzero(value, axis=1), tf.float32))
                    else:
                        ubbi = None
                    embedding_i_pool.append(ubbi)
                output = tf.concat(embedding_i_pool, -1)
            return output

        activation = get_act_fn(self.FLAGS.dnn_activation)
        keep_prob = 1 - self.FLAGS.drop_out
        features = self.features

        with tf.variable_scope('item/input',partitioner=self._variable_partitioner):
            item_dense_emb = layers.input_from_feature_columns(features, self.item_dense_column)
            item_dense_emb = layers.batch_norm(item_dense_emb,decay=0.9, scale=False, center=False,
                                               epsilon=1e-6, activation_fn=tf.nn.relu,is_training=self.is_training)
            item_sparse_emb = layers.input_from_feature_columns(features, self.item_sparse_column)

        with tf.variable_scope('context/input',partitioner=self._variable_partitioner):
            item_real_emb = layers.input_from_feature_columns(features, self.item_realtime_column)

        with tf.variable_scope('user/input/profile',partitioner=self._variable_partitioner):
            user_profile_emb = layers.input_from_feature_columns(features, self.user_sparse_column)

        with tf.variable_scope('ubb_pos_jfy'):
            clk_jfy_emb = []
            clk_jfy_orig_emb = []
            clk_jfy_values = []
            for time_i in self.ubb_time:
                ubb_jfy_id_name = 'user_item_clk_jfy_%d_id' % time_i
                ubb_jfy_value_name = 'user_item_clk_jfy_%d_value' % time_i
                with tf.variable_scope(str(time_i)):
                    with tf.variable_scope('input', partitioner=self._variable_partitioner):
                        ubb_embed_id_i = layers.input_from_feature_columns(features,self.ubb_column_dict[ubb_jfy_id_name])
                        ubb_embed_value_i = layers.input_from_feature_columns(features,self.ubb_column_dict[ubb_jfy_value_name])
                        value_i = tf.multiply(ubb_embed_id_i, ubb_embed_value_i)
                        value_i = tf.reshape(value_i, [tf.shape(user_profile_emb)[0], -1, self.FLAGS.ubb_dim])
                        clk_jfy_orig_emb.append(value_i)

                    with tf.variable_scope('pool_fcn'):
                        embedding_i_pool_output = pool(self.FLAGS.ubb_combiner, value_i, name='p0', axis=1)
                        embedding_i_pool_output = dnn_layer(name='p_fc',
                                                            net=embedding_i_pool_output,
                                                            mode=self.mode,
                                                            hidden_units=self.FLAGS.attention_num_units_forward.split(","),
                                                            dropout=self.FLAGS.drop_out,
                                                            activation_fn=activation,
                                                            dnn_parent_scope='p_fc',
                                                            is_training=self.is_training,
                                                            kernel_regularizer=tf.contrib.layers.l2_regularizer(
                                                                scale=self.FLAGS.dnn_l2_weight),
                                                            kernel_initializer=tf.contrib.layers.xavier_initializer(),
                                                            FLAGS=self.FLAGS)
                        embedding_i_pool_output = tf.contrib.layers.batch_norm(embedding_i_pool_output,
                                                                               is_training=self.is_training)

                    with tf.variable_scope('gru'):
                        ubb_embed_id_i_reshape = tf.reshape(ubb_embed_id_i,[tf.shape(user_profile_emb)[0], -1, self.FLAGS.ubb_dim])
                        ubb_embed_value_i_reshape = tf.reshape(ubb_embed_value_i, [tf.shape(user_profile_emb)[0], -1, 1])

                        clk_jfy_values.append(tf.reduce_sum(ubb_embed_value_i_reshape, axis=1))

                        embedding_i_concat = tf.slice(ubb_embed_id_i_reshape, [0, 0, 0],[-1, self.FLAGS.ubb_pos_slice_len, -1])
                        embedding_i_concat_counts = tf.slice(ubb_embed_value_i_reshape, [0, 0, 0],[-1, self.FLAGS.ubb_pos_slice_len, -1])
                        ubb_seq_length = tf.count_nonzero(tf.squeeze(embedding_i_concat_counts, axis=-1), axis=-1)

                        embedding_self_att, att_w2 = dnn_multihead_attention_count_without_forward(
                            queries=embedding_i_concat, keys=embedding_i_concat, key_length=ubb_seq_length,
                            scope='comp',
                            counts=embedding_i_concat_counts,
                            num_heads=4,
                            keep_prob=keep_prob,
                            num_units=self.FLAGS.attention_num_units,
                            num_output_units=self.FLAGS.attention_num_output_units,
                            is_training=self.is_training,
                            num_units_forward=map(int, self.FLAGS.attention_num_units_forward.split(",")),
                            activation_fn=activation)

                        cell = tf.contrib.rnn.GRUCell(num_units=self.FLAGS.attention_num_units)
                        outputs, last_states = tf.nn.dynamic_rnn(
                            cell=cell,
                            inputs=embedding_self_att,
                            sequence_length=ubb_seq_length,
                            dtype=tf.float32)
                        embedding_gru = last_states

                    embedding_pool_att = tf.concat([embedding_i_pool_output, embedding_gru], -1)
                    clk_jfy_emb.append(embedding_pool_att)

            with tf.variable_scope('pyramid'):
                tensors = []
                for tensori in clk_jfy_emb:
                    tensors.append(tf.expand_dims(tensori, axis=1))
                input_to_gru = tf.concat(tensors, axis=1)
                cell = tf.contrib.rnn.GRUCell(num_units=self.FLAGS.attention_num_units)
                outputs, last_states = tf.nn.dynamic_rnn(cell=cell,inputs=input_to_gru,dtype=tf.float32)
                clk_jfy_emb.append(
                    tf.reshape(outputs, [tf.shape(outputs)[0], len(clk_jfy_emb) * self.FLAGS.attention_num_units]))
                clk_jfy_emb.append(last_states)


            with tf.variable_scope('orig', partitioner=None):
                m0 = clk_jfy_orig_emb[0]
                for j in range(1, len(self.ubb_time)):
                    with tf.variable_scope(str(j), partitioner=None):
                        m1 = clk_jfy_orig_emb[j]
                        m = tf.concat([m0, m1], axis=1)
                        p_emb = pool(self.FLAGS.ubb_combiner, m, name='ubb_orig')
                        clk_jfy_emb.append(p_emb)
                        m0 = m

            clk_jfy_embedding = tf.concat(clk_jfy_emb, -1)

        with tf.variable_scope('ubb_pos_allnet'):
            clk_allnet_emb = []
            clk_allnet_orig_emb = []
            clk_allnet_values = []
            for time_i in self.ubb_time:
                with tf.variable_scope(str(time_i)):
                    ubb_allnet_id_name = 'user_item_clk_allnet_%d_id' % time_i
                    ubb_allnet_value_name = 'user_item_clk_allnet_%d_value' % time_i
                    with tf.variable_scope('input',partitioner=self._variable_partitioner):
                        ubb_embed_id_i = layers.input_from_feature_columns(features,self.ubb_column_dict[ubb_allnet_id_name])
                        ubb_embed_value_i = layers.input_from_feature_columns(features,self.ubb_column_dict[ubb_allnet_value_name])
                        value_i = tf.multiply(ubb_embed_id_i, ubb_embed_value_i)
                        value_i = tf.reshape(value_i, [tf.shape(user_profile_emb)[0], -1, self.FLAGS.ubb_dim])
                        clk_allnet_orig_emb.append(value_i)

                    with tf.variable_scope('pool_fcn', partitioner=self._variable_partitioner):
                        embedding_i_pool_output = pool(self.FLAGS.ubb_combiner, value_i, name='p0', axis=1)
                        embedding_i_pool_output = dnn_layer(name='p_fc', net=embedding_i_pool_output, mode=self.mode,
                                                            hidden_units=self.FLAGS.attention_num_units_forward.split(","),
                                                            dropout=self.FLAGS.drop_out,
                                                            activation_fn=activation,
                                                            dnn_parent_scope='p_fc',
                                                            is_training=self.is_training,
                                                            kernel_regularizer=tf.contrib.layers.l2_regularizer(
                                                                scale=self.FLAGS.dnn_l2_weight),
                                                            kernel_initializer=tf.contrib.layers.xavier_initializer(),
                                                            FLAGS=self.FLAGS)
                        embedding_i_pool_output = tf.contrib.layers.batch_norm(embedding_i_pool_output,
                                                                               is_training=self.is_training)

                    with tf.variable_scope('gru', partitioner=None):
                        ubb_embed_id_i_reshape = tf.reshape(ubb_embed_id_i,
                                                            [tf.shape(user_profile_emb)[0], -1, self.FLAGS.ubb_dim])
                        ubb_embed_value_i_reshape = tf.reshape(ubb_embed_value_i, [tf.shape(user_profile_emb)[0], -1, 1])

                        clk_allnet_values.append(tf.reduce_sum(ubb_embed_value_i_reshape, axis=1))

                        embedding_i_concat = tf.slice(ubb_embed_id_i_reshape, [0, 0, 0],[-1, self.FLAGS.ubb_pos_slice_len, -1])
                        embedding_i_concat_counts = tf.slice(ubb_embed_value_i_reshape, [0, 0, 0],[-1, self.FLAGS.ubb_pos_slice_len, -1])
                        ubb_seq_length = tf.count_nonzero(tf.squeeze(embedding_i_concat_counts, axis=-1), axis=-1)

                        embedding_self_att, att_w2 = dnn_multihead_attention_count_without_forward(
                            queries=embedding_i_concat,
                            keys=embedding_i_concat,
                            key_length=ubb_seq_length,
                            scope='comp',
                            counts=embedding_i_concat_counts,
                            num_heads=4,
                            keep_prob=keep_prob,
                            num_units=self.FLAGS.attention_num_units,
                            num_output_units=self.FLAGS.attention_num_output_units,
                            is_training=self.is_training,
                            num_units_forward=map(int, self.FLAGS.attention_num_units_forward.split(",")),
                            activation_fn=activation)

                        cell = tf.contrib.rnn.GRUCell(num_units=self.FLAGS.attention_num_units)
                        outputs, last_states = tf.nn.dynamic_rnn(
                            cell=cell,
                            inputs=embedding_self_att,
                            sequence_length=ubb_seq_length,
                            dtype=tf.float32)
                        embedding_gru = last_states

                    embedding_pool_att = tf.concat([embedding_i_pool_output, embedding_gru], -1)

                    clk_allnet_emb.append(embedding_pool_att)

            with tf.variable_scope('pyramid', partitioner=None):
                tensors = []
                for tensori in clk_allnet_emb:
                    tensors.append(tf.expand_dims(tensori, axis=1))
                input_to_gru = tf.concat(tensors, axis=1)
                cell = tf.contrib.rnn.GRUCell(num_units=self.FLAGS.attention_num_units)
                outputs, last_states = tf.nn.dynamic_rnn(cell=cell,inputs=input_to_gru,dtype=tf.float32)
                clk_allnet_emb.append(tf.reshape(outputs, [tf.shape(outputs)[0], len(clk_allnet_emb) * self.FLAGS.attention_num_units]))
                clk_allnet_emb.append(last_states)

            with tf.variable_scope('orig', partitioner=None):
                m0 = clk_allnet_orig_emb[0]
                for j in range(1, len(self.ubb_time)):
                    with tf.variable_scope(str(j), partitioner=None):
                        m1 = clk_allnet_orig_emb[j]
                        m = tf.concat([m0, m1], axis=1)
                        p_emb = pool(self.FLAGS.ubb_combiner, m, name='ubb_orig')
                        clk_allnet_emb.append(p_emb)
                        m0 = m

            clk_allnet_embedding = tf.concat(clk_allnet_emb, -1)

        ubb_embedding = tf.concat([clk_jfy_embedding, clk_allnet_embedding], -1)

        noclk_jfy_scope = 'noclk_jfy'
        with tf.variable_scope('ubb_neg'):
            with tf.variable_scope(noclk_jfy_scope):
                noclk_jfy_emb = []
                noclk_jfy_orig_emb = []
                for time_i in self.ubb_neg_time:
                    ubb_noclk_jfy_id_name = 'user_item_noclk_jfy_%d_id' % time_i
                    ubb_noclk_jfy_value_name = 'user_item_noclk_jfy_%d_value' % time_i
                    with tf.variable_scope(str(time_i)):
                        with tf.variable_scope('input', partitioner=self._variable_partitioner):
                            ubb_embed_id_i = layers.input_from_feature_columns(features,self.ubb_column_dict[ubb_noclk_jfy_id_name])
                            ubb_embed_value_i = tf.contrib.layers.input_from_feature_columns(features,self.ubb_column_dict[ubb_noclk_jfy_value_name])
                            value_i = tf.multiply(ubb_embed_id_i, ubb_embed_value_i)
                            value_i = tf.reshape(value_i, [tf.shape(user_profile_emb)[0], -1, self.FLAGS.ubb_dim])
                            noclk_jfy_orig_emb.append(value_i)

            with tf.variable_scope('orig', partitioner=None):
                m1 = []
                for j in range(len(self.ubb_neg_time)):
                    with tf.variable_scope(str(j), partitioner=None):
                        m1.append(noclk_jfy_orig_emb[j])
                        m = tf.concat(m1, axis=1)
                        p_emb = pool(self.FLAGS.ubb_combiner, m, name='ubb_orig')
                        noclk_jfy_emb.append(p_emb)

            noclk_jfy_embedding = tf.concat(noclk_jfy_emb, -1)
            ubb_embedding_neg = noclk_jfy_embedding

        with tf.variable_scope('ubb_mlp', partitioner=None):
            ubb_embedding = dnn_layer(name='ubb_pos', net=ubb_embedding, mode=self.mode,
                                      hidden_units=self.FLAGS.uig_pos_layer_units.split(","),
                                      dropout=self.FLAGS.drop_out,
                                      activation_fn=activation,
                                      dnn_parent_scope='ubb_pos',
                                      is_training=self.is_training,
                                      kernel_regularizer=tf.contrib.layers.l2_regularizer(
                                          scale=self.FLAGS.dnn_l2_weight),
                                      kernel_initializer=tf.contrib.layers.xavier_initializer()
                                      , FLAGS=self.FLAGS)
            ubb_embedding = tf.contrib.layers.batch_norm(ubb_embedding, is_training=self.is_training)

            ubb_embedding_neg = dnn_layer(name='ubb_neg', net=ubb_embedding_neg, mode=self.mode,
                                          hidden_units=self.FLAGS.uig_neg_layer_units.split(","),
                                          dropout=self.FLAGS.drop_out,
                                          activation_fn=activation,
                                          dnn_parent_scope='ubb_neg',
                                          is_training=self.is_training,
                                          kernel_regularizer=tf.contrib.layers.l2_regularizer(
                                              scale=self.FLAGS.dnn_l2_weight),
                                          kernel_initializer=tf.contrib.layers.xavier_initializer()
                                          , FLAGS=self.FLAGS)
            ubb_embedding_neg = tf.contrib.layers.batch_norm(ubb_embedding_neg,is_training=self.is_training)

        with tf.variable_scope('comp_att', partitioner=None):
            attention_compids = tf.reshape(item_sparse_emb,
                                           [tf.shape(item_sparse_emb)[0], self.FLAGS.target_comp_num, self.FLAGS.target_comp_dim])
            all_length = self.FLAGS.target_comp_num * tf.ones([tf.shape(item_sparse_emb)[0], ])
            ubb2att = tf.concat([ubb_embedding, ubb_embedding_neg], -1)
            with tf.variable_scope('ubb2comp', partitioner=None):
                att1 = tf.expand_dims(ubb2att, 1)

                item_emb_ubb2comp, att_w2 = keep_multihead_attention(queries=att1, keys=attention_compids,
                                                                     key_length=all_length,
                                                                     scope='comp',
                                                                     num_heads=4,
                                                                     keep_prob=keep_prob,
                                                                     num_units=self.FLAGS.attention_num_units,
                                                                     num_output_units=self.FLAGS.attention_num_output_units,
                                                                     is_training=self.is_training,
                                                                     num_units_forward=map(int,self.FLAGS.attention_num_units_forward.split(",")),
                                                                     activation_fn=activation)
                item_emb_ubb2comp = tf.reshape(item_emb_ubb2comp,
                                               [tf.shape(item_emb_ubb2comp)[0],
                                                self.FLAGS.target_comp_num * self.FLAGS.attention_num_output_units])
        item_emb_for_id = item_emb_ubb2comp

        with tf.variable_scope('dnn_seq'):
            with tf.variable_scope('input'):
                self.sequence.concat_seq_features(features)
                sequence_length_layer_dict = self.sequence.get_sequence_length_layer(features)
                sequence_input_layer_dict = self.sequence.get_sequence_layer(features, sequence_length_layer_dict)
            seq_tensors = []
            for name,column in sequence_input_layer_dict.items():
                seq_tensors.append(column)
            items_stack = tf.concat(seq_tensors,axis=-1)
            key_length = tf.to_int32(tf.contrib.layers.input_from_feature_columns(features, self.seq_length_column))
            cell = tf.contrib.rnn.GRUCell(num_units=self.FLAGS.attention_num_units)
            sequence_length = tf.squeeze(key_length, axis=-1)
            sequence_length = tf.where(tf.greater(sequence_length, 20), tf.ones_like(sequence_length) * 20,sequence_length)
            outputs, seq_emb = tf.nn.dynamic_rnn(cell=cell,sequence_length=sequence_length,inputs=items_stack,dtype=tf.float32)

            target = tf.expand_dims(item_emb_for_id, 1)
            seq_target_emb, w0 = dnn_multihead_attention(queries=target, keys=outputs,
                                                         key_length=sequence_length, scope='seq_target',
                                                         num_heads=4, keep_prob=keep_prob,
                                                         num_units=self.FLAGS.attention_num_units,
                                                         num_output_units=self.FLAGS.attention_num_output_units,
                                                         is_training=self.is_training,
                                                         num_units_forward=map(int,self.FLAGS.attention_num_units_forward.split(",")),
                                                         activation_fn=activation)
            seq_target_emb = tf.squeeze(seq_target_emb, axis=1)
        user_emb = tf.concat((user_profile_emb, seq_emb, seq_target_emb), axis=-1)  # use input from

        user_emb = tf.concat([user_emb, ubb_embedding, ubb_embedding_neg], axis=-1)

        item_emb = tf.concat((item_emb_for_id, item_dense_emb, item_real_emb), axis=-1)

        with tf.variable_scope("hard_att"):
            with tf.variable_scope('input',partitioner=self._variable_partitioner):
                att_emb = tf.contrib.layers.input_from_feature_columns(features, self.match_column)
                att_emb = dnn_layer(name='mlp', net=att_emb,
                                    mode=self.mode,
                                    hidden_units=[128, 64],
                                    dropout=self.FLAGS.drop_out,
                                    activation_fn=activation,
                                    dnn_parent_scope='hard_att',
                                    is_training=self.is_training,
                                    kernel_regularizer=tf.contrib.layers.l2_regularizer(scale=self.FLAGS.dnn_l2_weight),
                                    kernel_initializer=tf.contrib.layers.xavier_initializer(),
                                    FLAGS=self.FLAGS)
        output_emb = tf.concat([item_emb, user_emb, att_emb], axis=-1)

        with tf.variable_scope('forward', partitioner=None):
            output_emb = dnn_layer(name='forward',
                                   net=output_emb,
                                   mode=self.mode,
                                   hidden_units=self.FLAGS.decision_layer_units.split(","),
                                   dropout=self.FLAGS.drop_out,
                                   activation_fn=activation,
                                   dnn_parent_scope='forward',
                                   is_training=self.is_training,
                                   kernel_regularizer=tf.contrib.layers.l2_regularizer(scale=self.FLAGS.dnn_l2_weight),
                                   kernel_initializer=tf.contrib.layers.xavier_initializer()
                                   , FLAGS=self.FLAGS)
            output_emb = tf.contrib.layers.batch_norm(output_emb, is_training=self.is_training)

        with tf.variable_scope("logits"):
            deep_logits = tf.contrib.layers.fully_connected(inputs=output_emb,
                                                            num_outputs=1,
                                                            activation_fn=None,
                                                            normalizer_fn=None,
                                                            weights_initializer=tf.contrib.layers.xavier_initializer()
                                                            )

            self.logits = deep_logits

        # 为了适应RTP
        # 用户如果需要使用额外的 tf.Variable 或者用 contrib 之外的一些网络函数，
        # 注意把 variable 加到 MODEL_VARIABLES 这个 collection 里，我们会根据这个加载权重。
        # 请注意，需要在线加载权重的再加入，像global_step这种是不需要的！是不需要的！是不需要的！是不需要的！

        var_models = ops.get_collection(ops.GraphKeys.TRAINABLE_VARIABLES)
        v_global = ops.get_collection(ops.GraphKeys.GLOBAL_VARIABLES)
        v_model = ops.get_collection(ops.GraphKeys.MODEL_VARIABLES)
        for v in var_models:
            if v not in v_global:
                ops.add_to_collections([ops.GraphKeys.GLOBAL_VARIABLES], v)
            if v not in v_model:
                ops.add_to_collections([ops.GraphKeys.MODEL_VARIABLES], v)

    def _build_inference_op(self):
        self.predict_score = tf.sigmoid(self.logits)

    def _build_loss_op(self):
        with tf.name_scope('Loss'):
            if self.FLAGS.multi_label == 'true':
                a = 1 * tf.ones_like(self.labels['time'])
                b = 3 * tf.ones_like(self.labels['time'])
                c = 5 * tf.ones_like(self.labels['time'])
                d = 7 * tf.ones_like(self.labels['time'])
                label_w = tf.where(self.labels['time'] < 3, a, self.labels['time'])
                label_w = tf.where(((label_w < 9) & (label_w >= 3)), b, label_w)
                label_w = tf.where(((label_w < 20) & (label_w >= 9)), c, label_w)
                label_w = tf.where(label_w >= 20, d, label_w)
            else:
                label_w = self.labels['weight']

            raw_loss = tf.nn.sigmoid_cross_entropy_with_logits(labels=tf.cast(self.labels['click'], tf.float32),
                                                               logits=self.logits,
                                                               name='logits_cross_entropy')

            weighted_loss = tf.multiply(raw_loss, tf.cast(label_w, tf.float32))

            clk_loss = weighted_loss
            cart_loss = self.FLAGS.cart_loss_weight * tf.multiply(tf.cast(self.labels['cart'], tf.float32),weighted_loss)
            pay_loss = self.FLAGS.pay_loss_weight * tf.multiply(tf.cast(self.labels['pay'], tf.float32), weighted_loss)
            ltr_loss = clk_loss + cart_loss + pay_loss

            reduce_loss = tf.reduce_mean(ltr_loss)
            reg_loss = tf.reduce_sum(tf.get_collection(tf.GraphKeys.REGULARIZATION_LOSSES))
            loss = reduce_loss + reg_loss
            self.loss = loss

            # use moving average loss to indicate training loss
            ema = tf.train.ExponentialMovingAverage(decay=self.FLAGS.ema_decay, zero_debias=True)
            self.loss_ema_op = ema.apply([reduce_loss, reg_loss, loss])
            self.avg_reduce_loss = ema.average(reduce_loss)
            self.avg_reg_loss = ema.average(reg_loss)
            self.avg_loss = ema.average(loss)

    def _build_training_op(self):
        if self.FLAGS.lr_op == 'lr_rate_dacay':
            dnn_learning_rate = tf.train.exponential_decay(learning_rate=self.FLAGS.dnn_lr,
                                                           global_step=tf.train.get_global_step(),
                                                           decay_steps=self.FLAGS.lr_decay_steps,
                                                           decay_rate=self.FLAGS.lr_decay_rate,
                                                           staircase=True)
        elif self.FLAGS.lr_op == 'lr_warm_restart':
            dnn_learning_rate = lr_warm_restart(lr_max=self.FLAGS.dnn_lr,
                                                globalstep=self.global_step,
                                                lr_min=self.FLAGS.lr_min,
                                                periodic_step=self.periodic_step)
        else:
            dnn_learning_rate = self.FLAGS.dnn_lr

        self.optimizer = tf.train.AdamAsyncOptimizer(dnn_learning_rate)

        update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)
        with tf.control_dependencies(update_ops):

            if self.FLAGS.clip_gradients == 'true':
                print("clip gradients")
                gradients = self.optimizer.compute_gradients(self.loss)
                capped_gradients = [(tf.clip_by_value(grad, -5., 5.), var) for grad, var in gradients if grad is not None]
                train_op = self.optimizer.apply_gradients(capped_gradients, self.global_step)
            else:
                train_op = self.optimizer.minimize(self.loss, global_step=self.global_step)
        self.train_op = train_op
        self.dnn_learning_rate = dnn_learning_rate

    def _build_rtp_op(self):
        self.rank_predict = tf.identity(self.predict_score, name="rank_predict")

    def _build_summary(self):
        with tf.name_scope('Metric'):
            _, self.ctr_auc_op = tf.metrics.auc(labels=tf.cast(self.labels['click'], tf.bool), predictions=self.predict_score)

        with tf.name_scope('Summary'):
            tf.summary.scalar("auc/ctr_auc", self.ctr_auc_op)
            tf.summary.scalar("loss/ori_loss", self.avg_reduce_loss)
            tf.summary.scalar("loss/reg_loss", self.avg_reg_loss)
            tf.summary.scalar("loss/total_loss", self.avg_loss)
            tf.summary.scalar("loss/batch_loss", self.loss)

        # update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)
        # with tf.control_dependencies(update_ops):
        #     add_summary_gradient(self.optimizer, self.loss, scop_gra=self.FLAGS.grad_summary_scope)

    def _build_runner(self):
        self.runner.add_train_ops([self.train_op,
                                   self.ctr_auc_op
                                   ])

        self.runner.add_log_ops(['global_step', 'loss', 'ctr_auc'],
                                [self.global_step, self.loss, self.ctr_auc_op])


        # self.runner.add_inference_ops([self.sequence_input_layer_dict])