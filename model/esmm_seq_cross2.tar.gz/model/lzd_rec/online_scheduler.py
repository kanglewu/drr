from base.scheduler import BaseScheduler

class OnlineScheduler(BaseScheduler):
    def __init__(self, FLAGS, *args, **kwargs):
        super(OnlineScheduler,self).__init__()
        self.FLAGS = FLAGS

    def run(self):
        print('hello world')