# -*- coding:utf-8 -*-
"""

Author:
    @bunny: bani.ly@alibaba-inc.com
"""
from __future__ import division, print_function

import tensorflow as tf
from tensorflow.python.estimator.estimator import Estimator

from ..layers import CIN, DNN, get_linear_logit
from ..layers.utils import Linear
from ..utils import combined_dnn_input,get_emb_list,get_all_emb_list
from .estimator import EsmmEstimator
from ..layers.utils import add_variable

class CGC_ESMM(EsmmEstimator, Estimator):

    def  __init__(self, share_experts_num, ctr_experts_num, cvr_experts_num, experts_units,
                 use_experts_bias = True, use_gate_bias = True, gate_emb_feature_columns=None,
                 ctr_gate_colums=None, cvr_gate_colums=None, bias_feature_columns=None, linear_feature_columns=None,
                 linear_optimizer='Ftrl',
                 dnn_feature_columns=None,
                 dnn_optimizer='Adagrad', l2_reg_linear=0.0, l2_reg_embedding=0.0, l2_reg_dnn=0.0,
                 dnn_hidden_units=(128, 128), cin_layer_size=(128, 128,), cin_split_half=True,
                 cin_activation='selu', l2_reg_cin=0.0,
                 seed=1024, dnn_dropout=0, dnn_activation='relu', dnn_use_bn=False, task='binary',
                 config=None, model_dir=None, use_metrics=False, chief_hooks=None):
        """ initializes a `EsmmEstimator` instance.
        :param input_feature_column_dict:
        :param dnn_hidden_units: list,list of positive integer or empty list, the layer number and units in each layer of DNN
        :param dnn_learning_rate:
        :param dnn_optimizer:
        :param l2_reg_linear:  float. L2 regularizer strength applied to linear part
        :param l2_reg_embedding: float. L2 regularizer strength applied to embedding vector
        :param l2_reg_dnn: float. L2 regularizer strength applied to DNN
        :param seed: integer ,to use as random seed.
        :param dnn_dropout: float in [0,1), the probability we will drop out a given DNN coordinate.
        :param dnn_activation: Activation function to use in DNN
        :param dnn_use_bn:  bool. Whether use BatchNormalization before activation or not in DNN
        :param task: str, "binary" for binary logloss or "regression" for regression loss
        :param config: `RunConfig` object to configure the runtime settings.
        :param model_dir:
        :param use_metrics:
        """

        def _model_fn(features, labels, mode, config):
            print('-----model_fn-----------')
            print('-----mode=',mode,'')
            print('features:\n', features)
            print('\n\nlabels:\n', labels)

            train_flag = (mode == tf.estimator.ModeKeys.TRAIN)


            if bias_feature_columns:
                with tf.variable_scope("bias_net"):
                    bias_sparse_emb_list, bias_dense_value_list = get_emb_list(
                        features, bias_feature_columns, l2_reg_embedding)
                    bias_dnn_input = combined_dnn_input(bias_sparse_emb_list, bias_dense_value_list)
                    bias_deep_out = DNN((64,32), dnn_activation, l2_reg_dnn, dnn_dropout,
                                   dnn_use_bn, seed)(bias_dnn_input, training=train_flag)
                    bias_deep_logit = tf.contrib.layers.fully_connected(
                        bias_deep_out, 1, activation_fn=None, biases_initializer=None)
                    print('bias_deep_logit.shape=', bias_deep_logit.shape)



            if linear_feature_columns:
                with tf.variable_scope("linear"):
                    _, dense_list = get_emb_list(
                        features, linear_feature_columns, l2_reg_linear)
                    linear_input = combined_dnn_input([], dense_list)
                    print('before linear_input=\n', linear_input)

                    with tf.variable_scope("ctr_linear"):
                        ctr_linear_logit = Linear(l2_reg_linear, mode=1)(linear_input, training=train_flag)
                        print('before ctr_linear_logit.shape=', ctr_linear_logit.shape)

                        # ctr_linear_logit = get_linear_logit(
                        #     features, linear_feature_columns, l2_reg_linear, train_flag=train_flag)

                    with tf.variable_scope("cvr_linear"):
                        cvr_linear_logit = Linear(l2_reg_linear, mode=1)(linear_input, training=train_flag)
                        print('before cvr_linear_logit.shape=', cvr_linear_logit.shape)

                        # cvr_linear_logit = get_linear_logit(
                        #     features, linear_feature_columns, l2_reg_linear, train_flag=train_flag)

            with tf.variable_scope("dnn"):
                # share embedding
                # sparse_emb_list, dense_value_list = get_emb_list(
                #     features, dnn_feature_columns, l2_reg_embedding)

                sparse_emb_list, dense_value_list, gate_sparse_emb_list  = get_all_emb_list(
                    features, dnn_feature_columns, gate_emb_feature_columns, l2_reg_embedding)

                if len(cin_layer_size) > 0:
                    fm_emb_list = [emb for emb in sparse_emb_list if emb.shape[2] <= 16]
                    print('fm_emb_list:\n', fm_emb_list)

                    fm_input = tf.concat(fm_emb_list, axis=1)
                    exFM_out = CIN(cin_layer_size, cin_activation,
                                   cin_split_half, l2_reg_cin, seed)(fm_input)
                    exFM_logit = tf.contrib.layers.fully_connected(exFM_out, 1, activation_fn=None,
                                                                   biases_initializer=None, )

                dnn_input = combined_dnn_input(sparse_emb_list, dense_value_list)

                with tf.variable_scope("CGC"):

                    with tf.variable_scope("ctr_gate"):
                        if ctr_gate_colums:
                            _, ctr_gate_dense_value_list = get_emb_list(
                                features, ctr_gate_colums, l2_reg_embedding)
                            ctr_gate_input = combined_dnn_input(gate_sparse_emb_list, ctr_gate_dense_value_list)
                            print('ctr_gate_sparse_emb_list='+str(gate_sparse_emb_list)+', ctr_gate_dense_value_list='+str(ctr_gate_dense_value_list))
                            print('ctr_gate_input.shape=', ctr_gate_input.shape)
                        else:
                            ctr_gate_input = dnn_input

                    with tf.variable_scope("cvr_gate"):
                        if cvr_gate_colums:
                            _, cvr_gate_dense_value_list = get_emb_list(
                                features, cvr_gate_colums, l2_reg_embedding)
                            cvr_gate_input = combined_dnn_input(gate_sparse_emb_list, cvr_gate_dense_value_list)
                            print('cvr_gate_sparse_emb_list='+str(gate_sparse_emb_list)+', cvr_gate_dense_value_list='+str(cvr_gate_dense_value_list))
                            print('cvr_gate_input.shape=', cvr_gate_input.shape)
                        else:
                            cvr_gate_input = dnn_input

                    # 3 experts:
                    ctr_experts_weight = tf.get_variable(name='ctr_experts_weight',
                                                     dtype=tf.float32,
                                                     # (input, 128) × 1个
                                                     shape=(dnn_input.get_shape()[1], experts_units,
                                                            ctr_experts_num),
                                                     initializer=tf.contrib.layers.xavier_initializer(),
                                                     trainable=True)
                    ctr_experts_bias = tf.get_variable(name='ctr_experts_bias',
                                                   dtype=tf.float32,
                                                   shape=(experts_units, ctr_experts_num), # 128, 1
                                                   initializer=tf.contrib.layers.xavier_initializer(),
                                                   trainable=True)

                    cvr_experts_weight = tf.get_variable(name='cvr_experts_weight',
                                                     dtype=tf.float32,
                                                     # (input, 128) × 1个
                                                     shape=(dnn_input.get_shape()[1], experts_units,
                                                            cvr_experts_num),
                                                     initializer=tf.contrib.layers.xavier_initializer(),
                                                     trainable=True)
                    cvr_experts_bias = tf.get_variable(name='cvr_experts_bias',
                                                   dtype=tf.float32,
                                                   shape=(experts_units, cvr_experts_num), # 128, 1
                                                   initializer=tf.contrib.layers.xavier_initializer(),
                                                   trainable=True)

                    # task share expert
                    share_experts_weight = tf.get_variable(name='share_experts_weight',
                                                     dtype=tf.float32,
                                                     # (input, 128) × 1个
                                                     shape=(dnn_input.get_shape()[1], experts_units,
                                                            share_experts_num),
                                                     initializer=tf.contrib.layers.xavier_initializer(),
                                                     trainable=True)
                    share_experts_bias = tf.get_variable(name='share_experts_bias',
                                                   dtype=tf.float32,
                                                   shape=(experts_units, share_experts_num), # 128, 1
                                                   initializer=tf.contrib.layers.xavier_initializer(),
                                                   trainable=True)

                    # 2nd layer 2 gates
                    ctr_gate_weight = tf.get_variable(name='ctr_gate_weight',
                                                   dtype=tf.float32,
                                                   # 输入 x=dnn_input.get_shape()[1]，experts_num是softmax的输出，代表选哪个gate
                                                   shape=(ctr_gate_input.get_shape()[1], ctr_experts_num+share_experts_num),
                                                   initializer=tf.contrib.layers.xavier_initializer(),
                                                   trainable=True)
                    ctr_gate_bias = tf.get_variable(name='ctr_gate_bias',
                                                 dtype=tf.float32,
                                                 shape=(ctr_experts_num+share_experts_num,),
                                                 initializer=tf.contrib.layers.xavier_initializer(),
                                                 trainable=True)
                    cvr_gate_weight = tf.get_variable(name='cvr_gate_weight',
                                                   dtype=tf.float32,
                                                   shape=(cvr_gate_input.get_shape()[1], cvr_experts_num+share_experts_num),
                                                   initializer=tf.contrib.layers.xavier_initializer())
                    cvr_gate_bias = tf.get_variable(name='cvr_gate_bias',
                                                 dtype=tf.float32,
                                                 shape=(ctr_experts_num+share_experts_num,),
                                                 initializer=tf.contrib.layers.xavier_initializer())

                    add_variable([ctr_experts_weight, ctr_experts_bias, cvr_experts_weight, cvr_experts_bias, share_experts_weight, share_experts_bias,
                                  ctr_gate_weight, ctr_gate_bias, cvr_gate_weight, cvr_gate_bias])

                    # add_variable([experts_weight, experts_bias, ctr_gate_weight, ctr_gate_bias, cvr_gate_weight, cvr_gate_bias])
                    # add_variable([experts_weight, experts_bias, ctr_gate_weight, ctr_gate_bias])



                    #  ctr expert output  (1, 128, 3)
                    ctr_experts_output = tf.tensordot(dnn_input, ctr_experts_weight, axes=1)
                    print('-----ctr_experts_output.shape=', ctr_experts_output.shape)

                    if use_experts_bias:
                        ctr_experts_output = tf.add(ctr_experts_output, ctr_experts_bias)
                    ctr_experts_output = tf.nn.relu(ctr_experts_output)


                    #  cvr expert output
                    cvr_experts_output = tf.tensordot(dnn_input, cvr_experts_weight, axes=1)
                    print('-----cvr_experts_output.shape=', cvr_experts_output.shape)
                    if use_experts_bias:
                        cvr_experts_output = tf.add(cvr_experts_output, cvr_experts_bias)
                    cvr_experts_output = tf.nn.relu(cvr_experts_output)


                    #  task share expert output
                    share_experts_output = tf.tensordot(dnn_input, share_experts_weight, axes=1)
                    print('-----share_experts_output.shape=', share_experts_output.shape)
                    if use_experts_bias:
                        share_experts_output = tf.add(share_experts_output, share_experts_bias)
                    share_experts_output = tf.nn.relu(share_experts_output)



                    #  2 gate output
                    # g^k(x) = softmax(W_{gk}x + b)
                    # dnn_input: (1, 214)  ctr_gate_weight: (214, 3)
                    ctr_gate_output = tf.matmul(ctr_gate_input, ctr_gate_weight)
                    cvr_gate_output = tf.matmul(cvr_gate_input, cvr_gate_weight)
                    if use_gate_bias:
                        ctr_gate_output = tf.add(ctr_gate_output, ctr_gate_bias)
                        cvr_gate_output = tf.add(cvr_gate_output, cvr_gate_bias)
                    ctr_gate_output = tf.nn.softmax(ctr_gate_output)  # (?, 2)
                    cvr_gate_output = tf.nn.softmax(cvr_gate_output)  # (?, 2)
                    print('-----ctr_gate_output.shape=', ctr_gate_output.shape)
                    print('-----cvr_gate_output.shape=', cvr_gate_output.shape)


                    #  ctr/cvr input
                    # f^{k}(x) = sum_{i=1}^{n}(g^{k}(x)_{i} * f_{i}(x))
                    ctr_input = tf.multiply(tf.concat([ctr_experts_output, share_experts_output], -1), tf.expand_dims(ctr_gate_output, axis=1))
                    ctr_input = tf.reduce_sum(ctr_input, axis=2)
                    ctr_input = tf.reshape(ctr_input, [-1, experts_units])
                    print('-----ctr_input.shape=', ctr_input.shape)  # (?, 512)

                    cvr_input = tf.multiply(tf.concat([share_experts_output, cvr_experts_output], -1), tf.expand_dims(cvr_gate_output, axis=1))
                    cvr_input = tf.reduce_sum(cvr_input, axis=2)
                    cvr_input = tf.reshape(cvr_input, [-1, experts_units])
                    print('-----cvr_input.shape=', cvr_input.shape)  # (?, 512)

                # # 除最后一层外均共享
                # deep_out = DNN(dnn_hidden_units, dnn_activation, l2_reg_dnn, dnn_dropout,
                #                dnn_use_bn, seed)(ctr_input, training=train_flag)

                with tf.variable_scope("ctr_dnn"):
                    print('---------ctr_dnn--------\n')
                    print('ctr_dnn_input.shape=', ctr_input.shape)
                    ctr_deep_out = DNN(dnn_hidden_units, dnn_activation, l2_reg_dnn, dnn_dropout,
                                   dnn_use_bn, seed)(ctr_input, training=train_flag)

                    ctr_deep_logit = tf.contrib.layers.fully_connected(
                        ctr_deep_out, 1, activation_fn=None, biases_initializer=None)

                    # ctr_deep_logit = tf.reshape(ctr_deep_logit, [1024, 1])
                    print('--------before ctr_deep_logit.shape=', ctr_deep_logit.shape)

                with tf.variable_scope("cvr_dnn"):
                    print('---------cvr_dnn--------\n')
                    print('cvr_dnn_input.shape=', cvr_input.shape)
                    cvr_deep_out = DNN(dnn_hidden_units, dnn_activation, l2_reg_dnn, dnn_dropout,
                                   dnn_use_bn, seed)(cvr_input, training=train_flag)

                    cvr_deep_logit = tf.contrib.layers.fully_connected(
                        cvr_deep_out, 1, activation_fn=None, biases_initializer=None)


            if len(dnn_hidden_units) == 0:  # only linear
                ctr_final_logit = ctr_linear_logit
                cvr_final_logit = cvr_linear_logit

            else:
                tf.contrib.layers.summarize_tensor(ctr_deep_logit, tag='ctr_deep_logit')
                tf.contrib.layers.summarize_tensor(cvr_deep_logit, tag='cvr_deep_logit')
                if len(cin_layer_size) > 0:
                    ctr_final_logit = ctr_linear_logit + ctr_deep_logit + exFM_logit
                    cvr_final_logit = cvr_linear_logit + cvr_deep_logit + exFM_logit
                else:
                    if linear_feature_columns:
                        # ctr_linear_logit = tf.reshape(ctr_linear_logit, [1024, 1])
                        # print('--------after ctr_linear_logit.shape=', ctr_linear_logit.shape)

                        ctr_final_logit = ctr_linear_logit + ctr_deep_logit  # linear + deep
                        cvr_final_logit = cvr_linear_logit + cvr_deep_logit  # linear + deep
                    else:
                        ctr_final_logit = ctr_deep_logit  # deep
                        cvr_final_logit = cvr_deep_logit  # deep

            if bias_feature_columns:
                bias_logit = tf.reshape(bias_deep_logit, [-1])
            else:
                bias_logit = None

            ctr_logit = tf.reshape(ctr_final_logit, [-1])
            cvr_logit = tf.reshape(cvr_final_logit, [-1])

            return self._create_estimator_spec(bias_logit, ctr_logit, cvr_logit, labels['click'], labels['pay'], mode,
                                               linear_optimizer,
                                               dnn_optimizer)

        super(CGC_ESMM, self).__init__(task=task, use_metrics=use_metrics, linear_feature_columns=linear_feature_columns,
                                  dnn_feature_columns=dnn_feature_columns, chief_hooks=chief_hooks)

        super(EsmmEstimator, self).__init__(
            model_fn=_model_fn, model_dir=model_dir, config=config)

