from __future__ import print_function
from base.model import BaseModel
from tensorflow.contrib import layers
from model_ops.sequence import SequenceFeature
from model.ae_detail.esmm.sub_model import SubModel
from fg.feature_column_builder import FeatureColumnBuilder
from utils.config import parse_model_conf
from schedule.mode import ModeKeys
from model_ops.ranking.losses import make_loss_fn, RankingLossKey
from model_ops.ranking.metrics import compute_mean, RankingMetricKey

import tensorflow as tf


class ListModel(BaseModel):

    def __init__(self, FLAGS, *args, **kwargs):
        super(ListModel, self).__init__(FLAGS, *args, **kwargs)
        self.FLAGS = FLAGS

        # job config
        self.ps_num = len(self.FLAGS.ps_hosts.split(','))

        # network hyper parameters
        self.dnn_l2_reg = FLAGS.dnn_l2_reg
        self.learning_rate = FLAGS.learning_rate
        self.embedding_partition_size = FLAGS.embedding_partition_size
        self.need_dropout = FLAGS.need_dropout
        self.dropout_rate = FLAGS.dropout_rate
        self.dnn_hidden_units = FLAGS.dnn_hidden_units
        self.dnn_hidden_units_act_op = FLAGS.dnn_hidden_units_act_op

        ######################################################################################################################
        #                                                                                                                    #
        #                                               Feature Group                                                        #
        #                                                                                                                    #
        ######################################################################################################################
        parse_model_conf(FLAGS)
        column_conf = FLAGS.mc_conf['input_columns']

        self.user_sparse_features = column_conf['user_sparse']
        self.user_dense_features = column_conf['user_dense']
        self.user_behavior_features = column_conf['user_behavior']
        self.item_sparse_features = column_conf['item_sparse']
        self.item_dense_features = column_conf['item_dense']
        self.item_behavior_features = column_conf['item_behavior']
        self.item_other_features = column_conf['item_other']
        self.query_sparse_features = column_conf['query_sparse']
        self.query_dense_features = column_conf['query_dense']

        ######################################################################################################################
        #                                                                                                                    #
        #                                               Feature Column                                                       #
        #                                                                                                                    #
        ######################################################################################################################
        self.column_builder = FeatureColumnBuilder(FLAGS, FLAGS.fg_conf, FLAGS.fc_conf)

        # feature column
        self.user_sparse_column = self.column_builder.get_column_list(self.user_sparse_features)
        self.user_dense_column = self.column_builder.get_column_list(self.user_dense_features)
        self.user_behavior_column = self.column_builder.get_column_list(self.user_behavior_features)
        self.item_sparse_column = self.column_builder.get_column_list(self.item_sparse_features)
        self.item_dense_column = self.column_builder.get_column_list(self.item_dense_features)
        self.item_behavior_column = self.column_builder.get_column_list(self.item_behavior_features)
        self.item_other_column = self.column_builder.get_column_list(self.item_other_features)

        # price column
        self.origin_item_price_column = [layers.real_valued_column(column_name='origin_item_price', dimension=1, default_value=0.0)]

        ######################################################################################################################
        #                                                                                                                    #
        #                                      Sequence Feature                                                              #
        #                                                                                                                    #
        ######################################################################################################################
        self.sequence = SequenceFeature(column_conf['sequence_block'], {}, self.column_builder)

        ######################################################################################################################
        #                                                                                                                    #
        #                                               Graph Node                                                           #
        #                                                                                                                    #
        ######################################################################################################################
        self.ctr_sub_model = SubModel(self, 'CTR')
        self.cvr_sub_model = SubModel(self, 'CVR')
        self.reg_loss = None
        self.dcg_loss = None
        self.loss = None
        self.logits = None
        self.predicts = None

        self.global_step = None
        self.is_training = None
        self.train_op = None
        self.auc = None
        self.auc_update = None
        self.sample_id = None
        self.step_per_epoch = getattr(FLAGS, 'step_per_epoch', int(1e+9))
        self.name = 'List'
        print('task_index={}, step_per_epoch:{}'.format(self.FLAGS.task_index, self.step_per_epoch))

    def build(self, batch_data, *args, **kwargs):
        self._build_preliminary()
        self._build_inputs(batch_data)
        self._build_model()
        self._build_loss()
        self._build_optimizer()
        self._build_rtp()
        self._build_summary()
        self._build_runner()

    def _build_preliminary(self):
        tf.get_default_graph().set_shape_optimize(False)
        try:
            training = tf.get_default_graph().get_tensor_by_name('training:0')
        except KeyError:
            training = tf.placeholder_with_default(False, shape=(), name='training')
        self.is_training = training
        self.global_step = tf.Variable(initial_value=0, name='global_step', trainable=False,
                                       collections=[tf.GraphKeys.GLOBAL_STEP, tf.GraphKeys.GLOBAL_VARIABLES])
        self.global_step_add = tf.assign_add(self.global_step, 1, use_locking=True)

        with tf.variable_scope(name_or_scope='STEP', reuse=tf.AUTO_REUSE):
            self.pvp_step = tf.get_variable(name='pvp_step',
                                            shape=(),
                                            dtype=tf.int32,
                                            trainable=False,
                                            initializer=tf.zeros_initializer,
                                            collections=[tf.GraphKeys.GLOBAL_VARIABLES])
            self.dcg_step = tf.get_variable(name='dcg_step',
                                            shape=(),
                                            dtype=tf.int32,
                                            trainable=False,
                                            initializer=tf.zeros_initializer,
                                            collections=[tf.GraphKeys.GLOBAL_VARIABLES])

    def _build_inputs(self, batch_data):
        ctr_batch_iter = batch_data.get('ctr_batch_data', None)
        if ctr_batch_iter is None:
            raise Exception('invalid batch data')
        ctr_batch = ctr_batch_iter.get_next()
        ctr_batch = [tf.reshape(t, [-1]) for t in ctr_batch]
        ctr_batch = [tf.placeholder_with_default(t, shape=(None,)) for t in ctr_batch]
        ctr_label = tf.to_float(tf.greater(tf.string_to_number(ctr_batch[3], out_type=tf.float32), 0.5))
        cvr_label = tf.to_float(tf.greater(tf.string_to_number(ctr_batch[3], out_type=tf.float32), 3.5))
        self.ctr_sub_model.build_inputs(ctr_batch[1], tf.reshape(ctr_label, [-1, 1]))
        self.cvr_sub_model.build_inputs(ctr_batch[1], tf.reshape(cvr_label, [-1, 1]))
        self.sample_id = tf.reshape(ctr_batch[0], [-1, 1])

    def _build_model(self):
        self.ctr_sub_model.build_model()
        self.cvr_sub_model.build_model()

    def _build_loss(self):
        self.ctr_sub_model.build_loss()
        self.cvr_sub_model.build_loss()

        def _esmm_logits(ctr_logits, cvr_logits):
            clip_value_min, clip_value_max = -20., 20.
            ctr_logits = tf.clip_by_value(ctr_logits, clip_value_min, clip_value_max)
            cvr_logits = tf.clip_by_value(cvr_logits, clip_value_min, clip_value_max)
            pvp_logits = ctr_logits + cvr_logits - tf.log(1 + tf.exp(ctr_logits) + tf.exp(cvr_logits))
            return pvp_logits

        self.logits = _esmm_logits(self.ctr_sub_model.logits, self.cvr_sub_model.logits)
        self.predicts = tf.sigmoid(self.logits)

        with tf.variable_scope(name_or_scope='Uncertainty', reuse=tf.AUTO_REUSE):
            sigma_ctr = tf.get_variable(name='sigma_ctr',
                                        shape=(),
                                        dtype=tf.float32,
                                        initializer=tf.initializers.zeros,
                                        collections=[tf.GraphKeys.TRAINABLE_VARIABLES, tf.GraphKeys.GLOBAL_VARIABLES])
            sigma_pvp = tf.get_variable(name='sigma_pvp',
                                        shape=(),
                                        dtype=tf.float32,
                                        initializer=tf.initializers.zeros,
                                        collections=[tf.GraphKeys.TRAINABLE_VARIABLES, tf.GraphKeys.GLOBAL_VARIABLES])
            sigma_gmv = tf.get_variable(name='sigma_gmv',
                                        shape=(),
                                        dtype=tf.float32,
                                        initializer=tf.initializers.zeros,
                                        collections=[tf.GraphKeys.TRAINABLE_VARIABLES, tf.GraphKeys.GLOBAL_VARIABLES])
            factor_ctr = tf.exp(-sigma_ctr)
            factor_pvp = tf.exp(-sigma_pvp)
            factor_gmv = tf.exp(-sigma_gmv)
            self.factor_ctr, self.factor_pvp, self.factor_gmv = factor_ctr, factor_pvp, factor_gmv

        with tf.name_scope('Loss'):
            ctr_loss = factor_ctr * self.ctr_sub_model.loss + 0.5 * sigma_ctr

            pvp_loss = tf.losses.sigmoid_cross_entropy(self.cvr_sub_model.labels, self.logits)
            pvp_loss = factor_pvp * pvp_loss + 0.5 * sigma_pvp

            self.reg_loss = tf.reduce_sum(tf.get_collection(tf.GraphKeys.REGULARIZATION_LOSSES))
            self.loss = pvp_loss + ctr_loss + self.reg_loss

            dcg_loss_op = make_loss_fn(RankingLossKey.LIST_MLE_LOSS)
            dcg_logits = tf.reshape(self.logits, [-1, self.FLAGS.batch_size])
            # dcg_labels = tf.sigmoid(self.logits) + self.cvr_sub_model.labels * tf.log1p(self.cvr_sub_model.input_dict['item_price'])
            dcg_labels = self.ctr_sub_model.labels + self.cvr_sub_model.labels * tf.log1p(self.cvr_sub_model.input_dict['item_price'])
            dcg_labels = tf.reshape(dcg_labels, [-1, self.FLAGS.batch_size])

            dcg_loss = dcg_loss_op(dcg_labels, dcg_logits, None)
            dcg_loss = factor_gmv * dcg_loss + 0.5 * sigma_gmv

            self.dcg_loss = dcg_loss + pvp_loss + ctr_loss
            self.dcg_labels, self.dcg_logits = dcg_labels, dcg_logits

    def _build_optimizer(self):
        update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)
        dcg_optimizer = tf.train.AdamOptimizer(learning_rate=self.learning_rate)
        pvp_optimizer = tf.train.AdamOptimizer(learning_rate=self.learning_rate)

        with tf.control_dependencies(update_ops):
            train_op = tf.cond(tf.less(self.global_step, self.step_per_epoch),
                               lambda: pvp_optimizer.minimize(self.loss, global_step=self.pvp_step),
                               lambda: dcg_optimizer.minimize(self.dcg_loss, global_step=self.dcg_step))
            self.train_op = tf.group(train_op, self.global_step_add)

    def _build_rtp(self):
        with tf.name_scope('Mark_Output'):
            rank_predict_ctr = tf.identity(self.ctr_sub_model.predicts, name='rank_predict_ctr')
            rank_predict_cvr = tf.identity(self.cvr_sub_model.predicts, name='rank_predict_cvr')
            rank_predict_lp = tf.identity(self.predicts, name='rank_predict_lp')

    def _build_summary(self):
        self.ctr_sub_model.build_summary()
        self.cvr_sub_model.build_summary()

        with tf.name_scope('Metrics/{}'.format(self.name.upper())):
            if self.FLAGS.mode == ModeKeys.LOCAL:
                self.auc, self.auc_update = tf.metrics.auc(labels=self.cvr_sub_model.labels,
                                                           predictions=self.predicts,
                                                           num_thresholds=2000)
                self.ndcg_a = compute_mean(RankingMetricKey.NDCG, self.dcg_labels, self.dcg_logits)
                self.ndcg_1 = compute_mean(RankingMetricKey.NDCG, self.dcg_labels, self.dcg_logits, topn=int(self.FLAGS.batch_size * 0.1))
                self.ndcg_2 = compute_mean(RankingMetricKey.NDCG, self.dcg_labels, self.dcg_logits, topn=int(self.FLAGS.batch_size * 0.2))
                self.ndcg_5 = compute_mean(RankingMetricKey.NDCG, self.dcg_labels, self.dcg_logits, topn=int(self.FLAGS.batch_size * 0.5))
            else:
                worker_device = '/job:worker/task:{}'.format(self.FLAGS.task_index)
                with tf.device(worker_device):
                    self.auc, self.auc_update = tf.metrics.auc(labels=self.cvr_sub_model.labels,
                                                               predictions=self.predicts,
                                                               num_thresholds=2000)
                    self.ndcg_a = compute_mean(RankingMetricKey.NDCG, self.dcg_labels, self.dcg_logits)
                    self.ndcg_1 = compute_mean(RankingMetricKey.NDCG, self.dcg_labels, self.dcg_logits, topn=int(self.FLAGS.batch_size * 0.1))
                    self.ndcg_2 = compute_mean(RankingMetricKey.NDCG, self.dcg_labels, self.dcg_logits, topn=int(self.FLAGS.batch_size * 0.2))
                    self.ndcg_5 = compute_mean(RankingMetricKey.NDCG, self.dcg_labels, self.dcg_logits, topn=int(self.FLAGS.batch_size * 0.5))
        with tf.name_scope('Summary/{}'.format(self.name.upper())):
            tf.summary.scalar(name='AUC', tensor=self.auc)
            tf.summary.scalar(name='Reg', tensor=self.reg_loss)
            tf.summary.scalar(name='Loss', tensor=self.loss)
            tf.summary.scalar(name='Label_Mean', tensor=tf.reduce_mean(self.cvr_sub_model.labels))
            tf.summary.scalar(name='Predict_Mean', tensor=tf.reduce_mean(self.predicts))
            tf.summary.scalar(name='NDCG@All', tensor=self.ndcg_a)
            tf.summary.scalar(name='NDCG@Per10', tensor=self.ndcg_1)
            tf.summary.scalar(name='NDCG@Per20', tensor=self.ndcg_2)
            tf.summary.scalar(name='NDCG@Per50', tensor=self.ndcg_5)
            tf.summary.scalar(name='DCG_Loss', tensor=self.dcg_loss)
            tf.summary.scalar(name='Factor_CTR', tensor=self.factor_ctr)
            tf.summary.scalar(name='Factor_PVP', tensor=self.factor_pvp)
            tf.summary.scalar(name='Factor_GMV', tensor=self.factor_gmv)

    def _build_runner(self):
        self.runner.add_train_ops([self.train_op,
                                   self.ctr_sub_model.auc_update,
                                   self.cvr_sub_model.auc_update,
                                   self.auc_update,
                                   ])

        self.runner.add_evaluate_ops([self.ctr_sub_model.auc_update,
                                      self.cvr_sub_model.auc_update,
                                      self.auc_update,
                                      ])

        self.runner.add_inference_ops([self.sample_id,
                                       self.cvr_sub_model.labels,
                                       self.ctr_sub_model.labels,
                                       self.cvr_sub_model.predicts,
                                       self.ctr_sub_model.predicts])

        self.runner.add_log_ops(['global_step', 'dcg_step', 'pvp_step', 'loss', 'dcg_loss',
                                 'ctr_auc', 'cvr_auc', 'pvp_auc',
                                 'ndcg@All', 'ndcg@Per10', 'ndcg@Per20', 'ndcg@Per50',
                                 'factor_ctr', 'factor_pvp', 'factor_gmv'],
                                [self.global_step, self.dcg_step, self.pvp_step, self.loss, self.dcg_loss,
                                 self.ctr_sub_model.auc, self.cvr_sub_model.auc, self.auc,
                                 self.ndcg_a, self.ndcg_1, self.ndcg_2, self.ndcg_5,
                                 self.factor_ctr, self.factor_pvp, self.factor_gmv])

