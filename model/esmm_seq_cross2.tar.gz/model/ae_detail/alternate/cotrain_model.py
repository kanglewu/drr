from __future__ import print_function
from base.model import BaseModel
from tensorflow.contrib import layers
from model_ops.attention import AttentionFeature
from model_ops.sequence import SequenceFeature
from model.ae_detail.abfs.sub_model import SubModel
from fg.feature_column_builder import FeatureColumnBuilder
from utils.config import parse_model_conf
from schedule.mode import ModeKeys
import tensorflow as tf


class CotrainModel(BaseModel):

    def __init__(self, FLAGS, *args, **kwargs):
        super(CotrainModel, self).__init__(FLAGS, *args, **kwargs)
        self.FLAGS = FLAGS

        # job config
        self.ps_num = len(self.FLAGS.ps_hosts.split(','))

        # network hyper parameters
        self.dnn_l2_reg = FLAGS.dnn_l2_reg
        self.learning_rate = FLAGS.learning_rate
        self.embedding_partition_size = FLAGS.embedding_partition_size
        self.need_dropout = FLAGS.need_dropout
        self.dropout_rate = FLAGS.dropout_rate
        self.dnn_hidden_units = FLAGS.dnn_hidden_units
        self.dnn_hidden_units_act_op = FLAGS.dnn_hidden_units_act_op

        ######################################################################################################################
        #                                                                                                                    #
        #                                               Feature Group                                                        #
        #                                                                                                                    #
        ######################################################################################################################
        parse_model_conf(FLAGS)
        column_conf = FLAGS.mc_conf['input_columns']

        self.user_sparse_features = column_conf['user_sparse']
        self.user_dense_features = column_conf['user_dense']
        self.user_behavior_features = column_conf['user_behavior']
        self.item_sparse_features = column_conf['item_sparse']
        self.item_dense_features = column_conf['item_dense']
        self.item_behavior_features = column_conf['item_behavior']
        self.item_other_features = column_conf['item_other']
        self.query_sparse_features = column_conf['query_sparse']
        self.query_dense_features = column_conf['query_dense']

        ######################################################################################################################
        #                                                                                                                    #
        #                                               Feature Column                                                       #
        #                                                                                                                    #
        ######################################################################################################################
        self.column_builder = FeatureColumnBuilder(FLAGS, FLAGS.fg_conf, FLAGS.fc_conf)
        self.attention = AttentionFeature(column_conf['attention_block'], self.column_builder)
        # feature column
        self.user_sparse_column = self.column_builder.get_column_list(self.user_sparse_features)
        self.user_dense_column = self.column_builder.get_column_list(self.user_dense_features)
        self.user_behavior_column = self.column_builder.get_column_list(self.user_behavior_features)
        self.item_sparse_column = self.column_builder.get_column_list(self.item_sparse_features)
        self.item_dense_column = self.column_builder.get_column_list(self.item_dense_features)
        self.item_behavior_column = self.column_builder.get_column_list(self.item_behavior_features)
        self.item_other_column = self.column_builder.get_column_list(self.item_other_features)

        # price column
        self.origin_item_price_column = [layers.real_valued_column(column_name='origin_item_price', dimension=1, default_value=0.0)]

        ######################################################################################################################
        #                                                                                                                    #
        #                                      Sequence Feature                                                              #
        #                                                                                                                    #
        ######################################################################################################################
        self.sequence = SequenceFeature(column_conf['sequence_block'], column_conf['sequence_length_block'], self.column_builder)
        self.attention = AttentionFeature(column_conf['attention_block'], self.column_builder)
        ######################################################################################################################
        #                                                                                                                    #
        #                                               Graph Node                                                           #
        #                                                                                                                    #
        ######################################################################################################################
        self.ctr_sub_model = SubModel(self, 'CTR')
        self.cvr_sub_model = SubModel(self, 'CVR')
        self.reg_loss = None
        self.loss = None

        self.global_step = None
        self.ctr_global_step = None
        self.cvr_global_step = None
        self.global_step_add = None
        self.is_training = None
        self.train_op = None
        self.sample_id = None
        self.cross_ratio = getattr(FLAGS, 'cross_ratio', 1.0)
        self.cross_prob = tf.random_uniform(shape=())

    def build(self, batch_data, *args, **kwargs):
        self._build_preliminary()
        self._build_inputs(batch_data)
        self._build_model()
        self._build_loss()
        self._build_optimizer()
        self._build_rtp()
        self._build_summary()
        self._build_runner()

    def _build_preliminary(self):
        tf.get_default_graph().set_shape_optimize(False)
        try:
            training = tf.get_default_graph().get_tensor_by_name('training:0')
        except KeyError:
            training = tf.placeholder_with_default(False, shape=(), name='training')
        self.is_training = training
        self.global_step = tf.Variable(initial_value=0,
                                       name='global_step',
                                       trainable=False,
                                       collections=[tf.GraphKeys.GLOBAL_STEP, tf.GraphKeys.GLOBAL_VARIABLES])
        self.global_step_add = tf.assign_add(self.global_step, 1, use_locking=True)

        with tf.variable_scope(name_or_scope='TRAIN_STEP', reuse=tf.AUTO_REUSE):
            self.ctr_step = tf.get_variable(name='ctr_step',
                                            shape=(),
                                            dtype=tf.int32,
                                            trainable=False,
                                            initializer=tf.zeros_initializer)
            self.cvr_step = tf.get_variable(name='cvr_step',
                                            shape=(),
                                            dtype=tf.int32,
                                            trainable=False,
                                            initializer=tf.zeros_initializer)

    def _build_inputs(self, batch_data):
        print('task_index={}, cross_ration={}'.format(self.FLAGS.task_index, self.cross_ratio))
        ctr_batch_iter = batch_data.get('ctr_batch_data', None)
        cvr_batch_iter = batch_data.get('cvr_batch_data', None)
        if ctr_batch_iter is None or cvr_batch_iter is None:
            raise Exception('invalid batch data')
        ctr_batch = tf.cond(tf.less(self.cross_prob, self.cross_ratio),
                            lambda: ctr_batch_iter.get_next(),
                            lambda: cvr_batch_iter.get_next())
        ctr_batch = [tf.reshape(t, [-1]) for t in ctr_batch]
        cvr_batch = ctr_batch

        ctr_label = tf.to_float(tf.greater(tf.string_to_number(ctr_batch[3], out_type=tf.float32), 0.5))
        cvr_label = tf.to_float(tf.greater(tf.string_to_number(cvr_batch[3], out_type=tf.float32), 3.5))
        self.ctr_sub_model.build_inputs(ctr_batch[1], tf.reshape(ctr_label, [-1, 1]))
        self.cvr_sub_model.build_inputs(cvr_batch[1], tf.reshape(cvr_label, [-1, 1]))
        self.sample_id = tf.reshape(ctr_batch[0], [-1, 1])

    def _build_model(self):
        self.ctr_sub_model.build_model()
        self.cvr_sub_model.build_model()

    def _build_loss(self):
        with tf.name_scope('Loss'):
            self.ctr_sub_model.build_loss()
            self.cvr_sub_model.build_loss()
            self.reg_loss = tf.reduce_sum(tf.get_collection(tf.GraphKeys.REGULARIZATION_LOSSES))
            self.loss = self.ctr_sub_model.loss + self.cvr_sub_model.loss + self.reg_loss

    def _build_optimizer(self):
        def _grad_fn(name, loss):
            opt = tf.train.AdamOptimizer(learning_rate=self.learning_rate)
            variables = [v for v in tf.trainable_variables() if name in v.name.upper()]
            update_ops = [v for v in tf.get_collection(tf.GraphKeys.UPDATE_OPS) if name in v.name.upper()]
            grads = tf.gradients(loss, variables)
            grads_and_vars = zip(grads, variables)
            return grads_and_vars, update_ops, opt

        ctr_grads_and_vars, ctr_update_ops, ctr_opt = _grad_fn('CTR', self.ctr_sub_model.loss)
        cvr_grads_and_vars, cvr_update_ops, cvr_opt = _grad_fn('CVR', self.cvr_sub_model.loss)

        def _apply_fn(grads_and_vars, update_ops, opt, step):
            with tf.control_dependencies(update_ops):
                apply_grad_ops = opt.apply_gradients(grads_and_vars, global_step=step)
            return apply_grad_ops

        train_op = tf.cond(tf.less(self.cross_prob, self.cross_ratio),
                           lambda: _apply_fn(ctr_grads_and_vars, ctr_update_ops, ctr_opt, self.ctr_step),
                           lambda: _apply_fn(cvr_grads_and_vars, cvr_update_ops, cvr_opt, self.cvr_step))

        self.train_op = tf.group(train_op, self.global_step_add)

    def _build_rtp(self):
        with tf.name_scope('Mark_Output'):
            rank_predict_ctr = tf.identity(self.ctr_sub_model.predicts, name='rank_predict_ctr')
            rank_predict_cvr = tf.identity(self.cvr_sub_model.predicts, name='rank_predict_cvr')
            rank_predict_lp = tf.identity(self.ctr_sub_model.predicts * self.cvr_sub_model.predicts, name='rank_predict_lp')

    def _build_summary(self):
        self.ctr_sub_model.build_summary()
        self.cvr_sub_model.build_summary()

    def _build_runner(self):
        auc_update = tf.cond(tf.less(self.cross_prob, self.cross_ratio),
                             lambda: self.ctr_sub_model.auc_update,
                             lambda: self.cvr_sub_model.auc_update)
        self.runner.add_train_ops([self.train_op, auc_update])

        self.runner.add_evaluate_ops([auc_update])

        self.runner.add_inference_ops([self.sample_id,
                                       self.cvr_sub_model.labels,
                                       self.ctr_sub_model.labels,
                                       self.cvr_sub_model.predicts,
                                       self.ctr_sub_model.predicts])

        zero = tf.constant(0.0, dtype=tf.float32)
        ctr_auc = tf.cond(tf.less(self.cross_prob, self.cross_ratio),
                          lambda: tf.identity(self.ctr_sub_model.auc),
                          lambda: zero)
        cvr_auc = tf.cond(tf.less(self.cross_prob, self.cross_ratio),
                          lambda: zero,
                          lambda: tf.identity(self.cvr_sub_model.auc))
        self.runner.add_log_ops(['global_step', 'ctr_step', 'cvr_step', 'ctr_auc', 'cvr_auc'],
                                [self.global_step, self.ctr_step, self.cvr_step, ctr_auc, cvr_auc])

