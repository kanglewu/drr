#coding:utf8

from __future__ import print_function
from base.model import BaseModel
from tensorflow.contrib import layers
from model_ops.sequence import SequenceFeature
from model.ae_detail.esmm_cgc_share.sub_model import SubModel
from fg.feature_column_builder import FeatureColumnBuilder
from utils import util
from utils.config import parse_model_conf
from schedule.mode import ModeKeys
import tensorflow as tf


class ESMMModel(BaseModel):

    def __init__(self, FLAGS, *args, **kwargs):
        super(ESMMModel, self).__init__(FLAGS, *args, **kwargs)
        self.FLAGS = FLAGS

        # job config
        self.ps_num = len(self.FLAGS.ps_hosts.split(','))

        # network hyper parameters
        self.dnn_l2_reg = FLAGS.dnn_l2_reg
        self.learning_rate = FLAGS.learning_rate
        self.embedding_partition_size = FLAGS.embedding_partition_size
        self.need_dropout = FLAGS.need_dropout
        self.dropout_rate = FLAGS.dropout_rate
        self.dnn_hidden_units = FLAGS.dnn_hidden_units
        self.dnn_hidden_units_act_op = FLAGS.dnn_hidden_units_act_op
        if util.getAbConf(self.FLAGS,"use_context"):
            self.context_hidden_units = FLAGS.context_hidden_units
            self.context_hidden_units_act_op = FLAGS.context_hidden_units_act_op

        ######################################################################################################################
        #                                                                                                                    #
        #                                               Feature Group                                                        #
        #                                                                                                                    #
        ######################################################################################################################
        parse_model_conf(FLAGS)
        column_conf = FLAGS.mc_conf['input_columns']

        self.user_sparse_features = column_conf['user_sparse']
        self.user_dense_features = column_conf['user_dense']
        self.user_behavior_features = column_conf['user_behavior']
        self.item_sparse_features = column_conf['item_sparse']
        self.item_dense_features = column_conf['item_dense']
        self.item_behavior_features = column_conf['item_behavior']
        self.item_other_features = column_conf['item_other']
        self.query_sparse_features = column_conf['query_sparse']
        self.query_dense_features = column_conf['query_dense']

        ######################################################################################################################
        #                                                                                                                    #
        #                                               Feature Column                                                       #
        #                                                                                                                    #
        ######################################################################################################################
        self.column_builder = FeatureColumnBuilder(FLAGS, FLAGS.fg_conf, FLAGS.fc_conf)
        if util.getAbConf(self.FLAGS, "use_context"):
            self.context_sparse_features = column_conf['context_sparse']
            self.context_dense_features = column_conf['context_dense']
            self.context_sparse_column = self.column_builder.get_column_list(self.context_sparse_features)
            self.context_dense_column = self.column_builder.get_column_list(self.context_dense_features)
            self.item_price_level_column = [layers.real_valued_column(column_name='item_price_level', dimension=1, default_value=0.0)]
            self.pcate_leaf_id_column = self.column_builder.get_column_list(["pcate_leaf_id"])

        # feature column
        self.user_sparse_column = self.column_builder.get_column_list(self.user_sparse_features)
        self.user_dense_column = self.column_builder.get_column_list(self.user_dense_features)
        self.user_behavior_column = self.column_builder.get_column_list(self.user_behavior_features)
        self.item_sparse_column = self.column_builder.get_column_list(self.item_sparse_features)
        self.item_dense_column = self.column_builder.get_column_list(self.item_dense_features)
        self.item_behavior_column = self.column_builder.get_column_list(self.item_behavior_features)
        self.item_other_column = self.column_builder.get_column_list(self.item_other_features)

        # price column
        self.origin_item_price_column = [layers.real_valued_column(column_name='origin_item_price', dimension=1, default_value=0.0)]

        ######################################################################################################################
        #                                                                                                                    #
        #                                      Sequence Feature                                                              #
        #                                                                                                                    #
        ######################################################################################################################
        self.sequence = SequenceFeature(column_conf['sequence_block'], {}, self.column_builder)

        ######################################################################################################################
        #                                                                                                                    #
        #                                               Graph Node                                                           #
        #                                                                                                                    #
        ######################################################################################################################
        self.ctr_sub_model = SubModel(self, 'CTR')
        self.cvr_sub_model = SubModel(self, 'CVR')
        self.reg_loss = None
        self.loss = None
        self.share_loss = None
        self.logits = None
        self.predicts = None

        self.global_step = None
        self.is_training = None
        self.train_op = None
        self.auc = None
        self.auc_update = None
        self.sample_id = None
        self.name = 'ESMM'

    def build(self, batch_data, *args, **kwargs):
        self._build_preliminary()
        self._build_inputs(batch_data)
        self._build_model()
        self._build_loss()
        self._build_optimizer()
        self._build_rtp()
        self._build_summary()
        self._build_runner()

    def _build_preliminary(self):
        tf.get_default_graph().set_shape_optimize(False)
        try:
            training = tf.get_default_graph().get_tensor_by_name('training:0')
        except KeyError:
            training = tf.placeholder_with_default(False, shape=(), name='training')
        self.is_training = training
        self.global_step = tf.Variable(initial_value=0, name='global_step', trainable=False,
                                       collections=[tf.GraphKeys.GLOBAL_STEP, tf.GraphKeys.GLOBAL_VARIABLES])

    def _build_inputs(self, batch_data):
        ctr_batch_iter = batch_data.get('ctr_batch_data', None)
        if ctr_batch_iter is None:
            raise Exception('invalid batch data')
        ctr_batch = ctr_batch_iter.get_next()
        ctr_batch = [tf.reshape(t, [-1]) for t in ctr_batch]
        ctr_label = tf.to_float(tf.greater(tf.string_to_number(ctr_batch[3], out_type=tf.float32), 0.5))
        cvr_label = tf.to_float(tf.greater(tf.string_to_number(ctr_batch[3], out_type=tf.float32), 3.5))

        is_delay = util.getAbConfAndPrint(self.FLAGS, "is_delay")
        if is_delay:
            cvr_label = tf.to_float(tf.greater(ctr_batch[4], 0))

        self.ctr_sub_model.build_inputs(ctr_batch[1], tf.reshape(ctr_label, [-1, 1]))
        self.cvr_sub_model.build_inputs(ctr_batch[1], tf.reshape(cvr_label, [-1, 1]))
        self.sample_id = tf.reshape(ctr_batch[0], [-1, 1])

    def _build_model(self):
        self.ctr_sub_model.build_model()
        self.cvr_sub_model.build_model()

    def _build_loss(self):
        self.ctr_sub_model.build_loss()
        self.cvr_sub_model.build_loss()

        def _esmm_logits(ctr_logits, cvr_logits):
            clip_value_min, clip_value_max = -20., 20.
            ctr_logits = tf.clip_by_value(ctr_logits, clip_value_min, clip_value_max)
            cvr_logits = tf.clip_by_value(cvr_logits, clip_value_min, clip_value_max)
            pvp_logits = ctr_logits + cvr_logits - tf.log(1 + tf.exp(ctr_logits) + tf.exp(cvr_logits))
            return pvp_logits

        self.logits = _esmm_logits(self.ctr_sub_model.logits, self.cvr_sub_model.logits)
        self.predicts = tf.sigmoid(self.logits)
        with tf.name_scope('Loss'):
            ce_loss = tf.reduce_mean(
                tf.nn.sigmoid_cross_entropy_with_logits(labels=self.cvr_sub_model.labels, logits=self.logits))
            self.reg_loss = tf.reduce_sum(tf.get_collection(tf.GraphKeys.REGULARIZATION_LOSSES))
            self.loss = ce_loss + self.ctr_sub_model.loss + self.reg_loss + 0.1*self.ctr_sub_model.share_loss+0.1*self.cvr_sub_model.share_loss

    def _build_optimizer(self):
        optimizer = tf.train.AdamOptimizer(learning_rate=self.learning_rate)
        update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)
        with tf.control_dependencies(update_ops):
            self.train_op = optimizer.minimize(self.loss, global_step=self.global_step)

    def _build_rtp(self):
        with tf.name_scope('Mark_Output'):
            rank_predict_ctr = tf.identity(self.ctr_sub_model.predicts, name='rank_predict_ctr')
            rank_predict_cvr = tf.identity(self.cvr_sub_model.predicts, name='rank_predict_cvr')
            rank_predict_lp = tf.identity(self.predicts, name='rank_predict_lp')

    def _build_summary(self):
        self.ctr_sub_model.build_summary()
        self.cvr_sub_model.build_summary()

        with tf.name_scope('Metrics/{}'.format(self.name.upper())):
            if self.FLAGS.mode == ModeKeys.LOCAL:
                self.auc, self.auc_update = tf.metrics.auc(labels=self.cvr_sub_model.labels,
                                                           predictions=self.predicts,
                                                           num_thresholds=2000)
            else:
                worker_device = '/job:worker/task:{}'.format(self.FLAGS.task_index)
                with tf.device(worker_device):
                    self.auc, self.auc_update = tf.metrics.auc(labels=self.cvr_sub_model.labels,
                                                               predictions=self.predicts,
                                                               num_thresholds=2000)
        with tf.name_scope('Summary/{}'.format(self.name.upper())):
            tf.summary.scalar(name='AUC', tensor=self.auc)
            tf.summary.scalar(name='Reg', tensor=self.reg_loss)
            tf.summary.scalar(name='Loss', tensor=self.loss)
            tf.summary.scalar(name='Label_Mean', tensor=tf.reduce_mean(self.cvr_sub_model.labels))
            tf.summary.scalar(name='Predict_Mean', tensor=tf.reduce_mean(self.predicts))

    def _build_runner(self):
        self.runner.add_train_ops([self.train_op,
                                   self.ctr_sub_model.auc_update,
                                   self.cvr_sub_model.auc_update,
                                   self.auc_update,
                                   ])

        self.runner.add_evaluate_ops([self.ctr_sub_model.auc_update,
                                      self.cvr_sub_model.auc_update,
                                      self.auc_update,
                                      ])

        self.runner.add_inference_ops([self.sample_id,
                                       self.cvr_sub_model.labels,
                                       self.ctr_sub_model.labels,
                                       self.cvr_sub_model.predicts,
                                       self.ctr_sub_model.predicts])

        self.runner.add_log_ops(['global_step', 'loss', 'ctr_auc', 'cvr_auc', 'pvp_auc'],
                                [self.global_step, self.loss, self.ctr_sub_model.auc, self.cvr_sub_model.auc, self.auc])
