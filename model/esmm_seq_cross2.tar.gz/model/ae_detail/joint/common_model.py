from __future__ import print_function
from schedule.mode import ModeKeys
from utils.util import get_act_fn
from tensorflow.contrib import layers
from tensorflow.contrib.framework.python.ops import arg_scope
from tensorflow.python.ops import variable_scope
from model_ops import ops as base_ops
import tensorflow as tf


class CommonModel(object):

    def __init__(self, co_model, name, *args, **kwargs):
        self.co_model = co_model
        self.name = name
        self.labels = None
        self.input_dict = None
        self.loss = None
        self.logits = None
        self.predicts = None
        self.train_op = None
        self.auc = None
        self.auc_update = None
        self.batch_weights = None

    def build_inputs(self, batch_features, batch_labels, batch_weights=None):
        with tf.name_scope('Input_Pipeline'):
            import rtp_fg
            fg_features = rtp_fg.parse_genreated_fg(self.co_model.FLAGS.cg_conf, batch_features)
            self.labels = batch_labels
            self.batch_weights = batch_weights

        with tf.variable_scope(name_or_scope='Input_Column',
                               partitioner=base_ops.partitioner(ps_num=self.co_model.ps_num, mem=self.co_model.embedding_partition_size),
                               reuse=tf.AUTO_REUSE):
            self.input_dict = self._build_input_layer(fg_features)

    def _build_input_layer(self, fg_features):
        item_sparse_input_layer = layers.input_from_feature_columns(fg_features, self.co_model.item_sparse_column)
        item_dense_input_layer = layers.input_from_feature_columns(fg_features, self.co_model.item_dense_column)
        user_sparse_input_layer = layers.input_from_feature_columns(fg_features, self.co_model.user_sparse_column)
        user_dense_input_layer = layers.input_from_feature_columns(fg_features, self.co_model.user_dense_column)

        with tf.variable_scope(name_or_scope='Input_BN_{}'.format(self.name)):
            item_dense_input_layer = layers.batch_norm(item_dense_input_layer, is_training=self.co_model.is_training, batch_weights=self.batch_weights)
            user_dense_input_layer = layers.batch_norm(user_dense_input_layer, is_training=self.co_model.is_training, batch_weights=self.batch_weights)

        return {
            'item_sparse_input_layer': item_sparse_input_layer,
            'item_dense_input_layer': item_dense_input_layer,
            'user_sparse_input_layer': user_sparse_input_layer,
            'user_dense_input_layer': user_dense_input_layer,
        }

    def build_model(self):
        with tf.variable_scope(name_or_scope='{}_CommonModel'.format(self.name)):
            with arg_scope(base_ops.model_arg_scope(weight_decay=self.co_model.dnn_l2_reg)):
                with tf.variable_scope(name_or_scope='UI_Sparse_Cross'):
                    ui_sparse_cross_input_layer = self._create_sparse_cross_network(self.input_dict['user_sparse_input_layer'],
                                                                                    self.input_dict['item_sparse_input_layer'],
                                                                                    dropout_rate=self.co_model.dropout_rate)
                with tf.variable_scope(name_or_scope='DNN_Network'):
                    net = tf.concat([self.input_dict['user_sparse_input_layer'],
                                     self.input_dict['user_dense_input_layer'],
                                     self.input_dict['item_sparse_input_layer'],
                                     self.input_dict['item_dense_input_layer'],
                                     ui_sparse_cross_input_layer,
                                     ], axis=1)
                    normalizer_params = {'scale': True, 'is_training': self.co_model.is_training, 'batch_weights': self.batch_weights}
                    for layer_id, num_hidden_units in enumerate(self.co_model.dnn_hidden_units):
                        with variable_scope.variable_scope('Hidden_{}'.format(layer_id)):
                            net = layers.fully_connected(net,
                                                         num_hidden_units,
                                                         activation_fn=get_act_fn(self.co_model.dnn_hidden_units_act_op[layer_id]),
                                                         normalizer_fn=layers.batch_norm,
                                                         normalizer_params=normalizer_params
                                                         )
                            if self.co_model.need_dropout and self.co_model.dropout_rate > 0:
                                net = tf.layers.dropout(net, rate=self.co_model.dropout_rate, training=self.co_model.is_training)

                    with tf.variable_scope(name_or_scope='Logits'):
                        self.logits = layers.fully_connected(net, 1, activation_fn=None)

    def build_loss(self):
        self.predicts = tf.sigmoid(self.logits)
        with tf.name_scope('Loss'):
            self.loss = tf.reduce_mean(
                tf.nn.sigmoid_cross_entropy_with_logits(labels=self.labels, logits=self.logits))

    def build_optimizer(self):
        optimizer = tf.train.AdamOptimizer(learning_rate=self.co_model.learning_rate)
        update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)
        with tf.control_dependencies(update_ops):
            self.train_op = optimizer.minimize(self.loss, global_step=self.co_model.global_step)

    def build_summary(self):
        with tf.name_scope('Metrics/{}'.format(self.name)):
            if self.co_model.FLAGS.mode == ModeKeys.LOCAL:
                self.auc, self.auc_update = tf.metrics.auc(labels=self.labels,
                                                           predictions=self.predicts,
                                                           num_thresholds=2000)
            else:
                worker_device = '/job:worker/task:{}'.format(self.co_model.FLAGS.task_index)
                with tf.device(worker_device):
                    self.auc, self.auc_update = tf.metrics.auc(labels=self.labels,
                                                               predictions=self.predicts,
                                                               num_thresholds=2000)
        with tf.name_scope('Summary/{}'.format(self.name.upper())):
            tf.summary.scalar(name='AUC', tensor=self.auc)
            tf.summary.scalar(name='Loss', tensor=self.loss)
            tf.summary.scalar(name='Label_Mean', tensor=tf.reduce_mean(self.labels))
            tf.summary.scalar(name='Predict_Mean', tensor=tf.reduce_mean(self.predicts))

    def _create_sparse_cross_network(self, user_sparse_input_layer, item_sparse_input_layer, dim=8, units=64, dropout_rate=0.0):
        user_s_shape = user_sparse_input_layer.shape.as_list()[1] // dim
        user_sparse = tf.reshape(user_sparse_input_layer, [-1, user_s_shape, dim])
        user_s_shape = user_sparse.shape.as_list()[1]
        item_s_shape = item_sparse_input_layer.shape.as_list()[1] // dim
        item_sparse = tf.reshape(item_sparse_input_layer, [-1, item_s_shape, dim])

        sparse_cross = tf.matmul(user_sparse, item_sparse, transpose_b=True)
        sparse_cross = tf.reshape(sparse_cross, [-1, user_s_shape * item_s_shape])

        normalizer_params = {'scale': True, 'is_training': self.co_model.is_training, 'batch_weights': self.batch_weights}
        with variable_scope.variable_scope('Sparse_Cross_Layer'):
            sparse_net = layers.fully_connected(
                sparse_cross,
                units,
                activation_fn=get_act_fn(self.co_model.dnn_hidden_units_act_op[0]),
                normalizer_fn=layers.batch_norm,
                normalizer_params=normalizer_params
            )
            if self.co_model.need_dropout and dropout_rate > 0:
                sparse_net = tf.layers.dropout(sparse_net, rate=dropout_rate, training=self.co_model.is_training)
        return sparse_net

