import tensorflow as tf
import numpy as np
import copy

from tensorflow.contrib.framework.python.ops import arg_scope
from tensorflow.python.ops import variable_scope
from tensorflow.contrib import layers

from python.utils.utils import logging
from python.utils import featurecolumn_op as myfgop
from python.utils import utils_op as base_ops
from python.utils import metrics_op as metrics
from python.local import local_mode
from base_model import BaseModel


class MMoeModel(BaseModel):
    def forward(self, features, mode='train'):
        with tf.variable_scope(name_or_scope="input_from_feature_columns", reuse=tf.AUTO_REUSE) as scope:
            scene_input = tf.cast(features[self.training_config.scene_feat_name], dtype=tf.int32)
            self.scene_input = tf.squeeze(scene_input, axis=1)
            scene_feature = tf.one_hot(self.scene_input, depth=self.training_config.scene_num)

            user_input_layer = self.get_user_features(features, scope=scope,
                                                      method=self.training_config.user_embed_method)
            user_input_layer = tf.concat([user_input_layer, scene_feature], axis=1)
            item_input_layer, item_cols = self.get_item_feature(features, scope=scope)

            # deep_ctr = item_input_layer[:, 25:26]
            # deep_lp = item_input_layer[:, 27:28]
            # deep_ctr = tf.clip_by_value(deep_ctr, 1e-7, 1 - 1e-7)
            # deep_cvr = deep_lp / deep_ctr
            # deep_cvr = tf.clip_by_value(deep_cvr, 1e-7, 1.0)
            # item_input_layer = tf.concat([item_input_layer, deep_cvr], axis=1)

            if self.training_config.only_use_scene_input:
                gate_input_layer = scene_feature
            else:
                gate_input_layer = tf.concat([user_input_layer, item_input_layer], axis=1)

            if mode == 'train' and self.training_config.embed_l2_reg > 0:
                user_embed_l2_loss = tf.reduce_mean(
                    tf.reduce_sum(tf.multiply(user_input_layer, user_input_layer), axis=1)) * self.training_config.embed_l2_reg
                tf.add_to_collection(tf.GraphKeys.REGULARIZATION_LOSSES, user_embed_l2_loss)

        expert_nets = []
        for i in range(self.training_config.expert_num):
            with tf.variable_scope(name_or_scope="%s-Expert-%d" % (self.name, i), reuse=tf.AUTO_REUSE):
                item_net = item_input_layer
                user_net = user_input_layer
                with arg_scope(base_ops.model_arg_scope(weight_decay=self.training_config.dnn_l2_reg)):
                    normalize_fn = None
                    if self.training_config.dnn_pre_hidden_bn:
                        normalize_fn = layers.batch_norm
                    for layer_id, num_hidden_units in enumerate(self.training_config.dnn_pre_hidden_units):
                        with variable_scope.variable_scope(
                                "user_prehiddenlayer_%d" % layer_id) as user_dnn_pre_hidden_layer_scope:
                            user_net = layers.fully_connected(
                                user_net,
                                num_hidden_units,
                                base_ops.getActivationFunctionOp(self.training_config.pre_activation_op),
                                weights_initializer=base_ops.get_init_op(init_para=None, act_name='xavier')
                                                    if self.training_config.pre_activation_op == 'tanh'
                                                    else base_ops.get_init_op(init_para=None, act_name='he'),
                                scope=user_dnn_pre_hidden_layer_scope,
                                normalizer_fn=normalize_fn,
                                normalizer_params={"scale": True,
                                                   "is_training": self.is_training}
                            )
                        tf.summary.histogram("expert-%d-user-layer-%d" % (i, layer_id), user_net, collections=['train', 'test'])
                        with variable_scope.variable_scope(
                                "item_prehiddenlayer_%d" % layer_id) as item_dnn_pre_hidden_layer_scope:
                            item_net = layers.fully_connected(
                                item_net,
                                num_hidden_units,
                                base_ops.getActivationFunctionOp(self.training_config.pre_activation_op),
                                weights_initializer=base_ops.get_init_op(init_para=None, act_name='xavier')
                                                    if self.training_config.pre_activation_op == 'tanh'
                                                    else base_ops.get_init_op(init_para=None, act_name='he'),
                                scope=item_dnn_pre_hidden_layer_scope,
                                normalizer_fn=normalize_fn,
                                normalizer_params={"scale": True,
                                                   "is_training": self.is_training}
                            )
                        tf.summary.histogram("expert-%d-item-layer-%d" % (i, layer_id), item_net, collections=['train', 'test'])
                        if self.training_config.is_pre_dropout:
                            user_net = layers.dropout(user_net, keep_prob=self.training_config.pre_dropout_rate,
                                                      is_training=self.is_training)
                            item_net = layers.dropout(item_net, keep_prob=self.training_config.pre_dropout_rate,
                                                      is_training=self.is_training)

                    expert_net = tf.concat([user_net, item_net], axis=1)

                    normalize_fn = None
                    if self.training_config.dnn_hidden_bn:
                        normalize_fn = layers.batch_norm
                    for layer_id, num_hidden_units in enumerate(self.training_config.dnn_hidden_units):
                        with variable_scope.variable_scope("expert_hiddenlayer_%d" % layer_id) as dnn_hidden_layer_scope:
                            expert_net = layers.fully_connected(
                                expert_net,
                                num_hidden_units,
                                base_ops.getActivationFunctionOp(self.training_config.activation_op),
                                weights_initializer=base_ops.get_init_op(init_para=None, act_name='xavier')
                                                    if self.training_config.activation_op == 'tanh'
                                                    else base_ops.get_init_op(init_para=None, act_name='he'),
                                scope=dnn_hidden_layer_scope,
                                normalizer_fn=normalize_fn,
                                normalizer_params={"scale": True,
                                                   "is_training": self.is_training}
                            )
                        tf.summary.histogram("expert-%d-layer-%d" % (i, layer_id), item_net, collections=['train', 'test'])
                        if self.training_config.is_dropout:
                            expert_net = layers.dropout(expert_net, keep_prob=self.training_config.dropout_rate,
                                                        is_training=self.is_training)
            expert_nets.append(expert_net)

        with tf.variable_scope(name_or_scope="%s-Expert-Gate" % self.name, reuse=tf.AUTO_REUSE):
            expert_gate = gate_input_layer
            for layer_id, num_hidden_units in enumerate(self.training_config.expert_gate_hidden_units):
                with variable_scope.variable_scope(
                        "expert_gate_hiddenlayer_%d" % layer_id) as expert_gate_scope:
                    expert_gate = layers.fully_connected(
                        expert_gate,
                        num_hidden_units,
                        base_ops.getActivationFunctionOp(self.training_config.expert_gate_activation_op),
                        weights_initializer=tf.constant_initializer(
                                            np.identity(self.training_config.expert_num), dtype=np.float32)
                                            if self.training_config.only_use_scene_input else
                                            base_ops.get_init_op(init_para=None, act_name='xavier'),
                        biases_initializer=base_ops.get_init_op(init_para=None, act_name='zero')
                                           if self.training_config.expert_gate_bias else None,
                        scope=expert_gate_scope,
                        normalizer_fn=None
                    )
                    if self.training_config.expert_gate_is_dropout:
                        expert_gate = layers.dropout(expert_gate,
                                                     keep_prob=self.training_config.expert_gate_dropout_rate,
                                                     is_training=self.is_training)
            else:
                with variable_scope.variable_scope(
                        "expert_gate_hiddenlayer_%d" % len(self.training_config.expert_gate_hidden_units)
                ) as expert_gate_scope:
                    expert_gate = layers.fully_connected(
                        expert_gate,
                        self.training_config.expert_num,
                        base_ops.getActivationFunctionOp(self.training_config.expert_gate_activation_op),
                        weights_initializer=tf.constant_initializer(
                                            np.identity(self.training_config.expert_num), dtype=np.float32)
                                            if self.training_config.only_use_scene_input else
                                            base_ops.get_init_op(init_para=None, act_name='xavier'),
                        biases_initializer=base_ops.get_init_op(init_para=None, act_name='zero')
                                           if self.training_config.expert_gate_bias else None,
                        scope=expert_gate_scope,
                        normalizer_fn=None
                    )
                    if self.training_config.expert_gate_is_dropout:
                        expert_gate = layers.dropout(expert_gate,
                                                     keep_prob=self.training_config.expert_gate_dropout_rate,
                                                     is_training=self.is_training)
            if self.training_config.expert_gate_softmax_output:
                expert_gate = layers.softmax(expert_gate)

            tf.summary.histogram("expert_gate", expert_gate, collections=['train', 'test'])

        with tf.variable_scope(name_or_scope="%s-Expert-Output" % self.name, reuse=tf.AUTO_REUSE):
            expert_output = [tf.einsum('n,nm->nm', expert_gate[:, i], expert_nets[i])
                             for i in range(self.training_config.expert_num)]
            expert_output = tf.reduce_sum(expert_output, axis=0)
        tf.summary.histogram("expert-output", expert_output, collections=['train', 'test'])

        scene_logits = []
        for i in range(self.training_config.scene_num):
            with tf.variable_scope(name_or_scope="%s-Scene-%d" % (self.name, i), reuse=tf.AUTO_REUSE):
                normalize_fn = None
                if self.training_config.scene_hidden_bn:
                    normalize_fn = layers.batch_norm
                scene_logit = expert_output
                with arg_scope(base_ops.model_arg_scope(weight_decay=self.training_config.dnn_l2_reg)):
                    for layer_id, num_hidden_units in enumerate(self.training_config.scene_hidden_units):
                        with variable_scope.variable_scope("scene_hiddenlayer_%d" % layer_id) as dnn_hidden_layer_scope:
                            scene_logit = layers.fully_connected(
                                scene_logit,
                                num_hidden_units,
                                base_ops.getActivationFunctionOp(self.training_config.scene_activation_op),
                                weights_initializer=base_ops.get_init_op(init_para=None, act_name='xavier')
                                                    if self.training_config.scene_activation_op == 'tanh'
                                                    else base_ops.get_init_op(init_para=None, act_name='he'),
                                scope=dnn_hidden_layer_scope,
                                normalizer_fn=normalize_fn,
                                normalizer_params={"scale": True,
                                                   "is_training": self.is_training}
                            )
                        tf.summary.histogram("scene-%d-layer-%d" % (i, layer_id), scene_logit, collections=['train', 'test'])
                        if self.training_config.scene_is_dropout:
                            scene_logit = layers.dropout(scene_logit, keep_prob=self.training_config.scene_dropout_rate,
                                                         is_training=self.is_training)
                    else:
                        with variable_scope.variable_scope(
                                "scene_hiddenlayer_%d" % len(self.training_config.scene_hidden_units)
                        ) as dnn_hidden_layer_scope:
                            scene_logit = layers.fully_connected(
                                scene_logit,
                                1,
                                None,
                                weights_initializer=base_ops.get_init_op(init_para=None, act_name='xavier')
                                                    if self.training_config.scene_activation_op == 'tanh'
                                                    else base_ops.get_init_op(init_para=None, act_name='he'),
                                scope=dnn_hidden_layer_scope,
                                normalizer_fn=normalize_fn,
                                normalizer_params={"scale": True,
                                                   "is_training": self.is_training}
                            )
                        tf.summary.histogram("scene-%d-logit" % i, scene_logit, collections=['train', 'test'])
                scene_logits.append(scene_logit)
                self.scene_logits = [tf.squeeze(scene_logit, axis=1) for scene_logit in scene_logits]
                self.scene_preds = [tf.sigmoid(scene_logit) for scene_logit in self.scene_logits]

        with tf.variable_scope(name_or_scope="%s-Scene-Gate" % self.name, reuse=tf.AUTO_REUSE):
            scene_gate = gate_input_layer
            for layer_id, num_hidden_units in enumerate(self.training_config.scene_gate_hidden_units):
                with variable_scope.variable_scope(
                        "scene_gate_hiddenlayer_%d" % layer_id) as scene_gate_scope:
                    scene_gate = layers.fully_connected(
                        scene_gate,
                        num_hidden_units,
                        base_ops.getActivationFunctionOp(self.training_config.scene_activation_op),
                        weights_initializer=tf.constant_initializer(
                                            np.identity(self.training_config.scene_num), dtype=np.float32)
                                            if self.training_config.only_use_scene_input else
                                            base_ops.get_init_op(init_para=None, act_name='xavier'),
                        biases_initializer=base_ops.get_init_op(init_para=None, act_name='zero')
                                           if self.training_config.scene_gate_bias else None,
                        scope=scene_gate_scope,
                        normalizer_fn=None
                    )
                    if self.training_config.scene_gate_is_dropout:
                        scene_gate = layers.dropout(scene_gate,
                                                    keep_prob=self.training_config.scene_gate_dropout_rate,
                                                    is_training=self.is_training)
            else:
                with variable_scope.variable_scope(
                        "scene_gate_hiddenlayer_%d" % len(self.training_config.scene_gate_hidden_units)
                ) as scene_gate_scope:
                    scene_gate = layers.fully_connected(
                        scene_gate,
                        self.training_config.scene_num,
                        base_ops.getActivationFunctionOp(self.training_config.scene_activation_op),
                        weights_initializer=tf.constant_initializer(
                                            np.identity(self.training_config.scene_num), dtype=np.float32)
                                            if self.training_config.only_use_scene_input else
                                            base_ops.get_init_op(init_para=None, act_name='xavier'),
                        biases_initializer=base_ops.get_init_op(init_para=None, act_name='zero')
                                           if self.training_config.scene_gate_bias else None,
                        scope=scene_gate_scope,
                        normalizer_fn=None
                    )
                    if self.training_config.scene_gate_is_dropout:
                        scene_gate = layers.dropout(scene_gate,
                                                    keep_prob=self.training_config.scene_gate_dropout_rate,
                                                    is_training=self.is_training)
            if self.training_config.scene_gate_softmax_output:
                scene_gate = layers.softmax(scene_gate)
            tf.summary.histogram("scene_gate", scene_gate, collections=['train', 'test'])

        with tf.variable_scope(name_or_scope="%s-Logits-Final" % self.name, reuse=tf.AUTO_REUSE):
            scene_stop_logits = [tf.stop_gradient(scene_logit) for scene_logit in scene_logits]
            final_logits = []
            for scene_id in range(self.training_config.scene_num):
                mix_scene_logits = [scene_logits[i] if i == scene_id else scene_stop_logits[i]
                                    for i in range(self.training_config.scene_num)]
                mix_scene_logits = tf.concat(mix_scene_logits, axis=1)
                final_logit = tf.reduce_sum(mix_scene_logits * scene_gate, axis=1, keep_dims=True)
                final_logits.append(final_logit)

            final_logits = tf.concat(final_logits, axis=1)
            scene_mask = tf.concat([tf.expand_dims(tf.range(tf.shape(final_logits)[0]), axis=1),
                                    scene_input], axis=1)
            final_logits = tf.gather_nd(final_logits, scene_mask)

        return user_input_layer, (item_input_layer, item_cols), [expert_gate, scene_gate], final_logits

    def summary(self):
        with tf.name_scope('%s-Logits' % self.name):
            tf.summary.scalar(name="label_train/mean", tensor=tf.reduce_mean(self.input_labels),
                              collections=['train', 'test'])
            tf.summary.scalar(name="predictions_train/mean", tensor=tf.reduce_mean(self.predictions_train),
                              collections=['train', 'test'])

            tf.summary.histogram("logits_train", self.logits_train, collections=['train', 'test'])

        with tf.name_scope("%s-Metrics" % self.name):
            self.train_auc_all, self.train_auc_update_op_all = metrics.auc(
                predictions=self.predictions_train, labels=self.input_labels, weights=self.pos_weight,
                name="train_all_auc",
                num_thresholds=2000)
            self.test_auc_all, self.test_auc_update_op_all = metrics.auc(
                predictions=self.predictions_train, labels=self.input_labels, weights=self.pos_weight,
                name="test_all_auc",
                num_thresholds=2000)

            tf.summary.scalar(name="scalar/train_auc_all", tensor=self.train_auc_update_op_all, collections=['train'])
            tf.summary.scalar(name="scalar/test_auc_all", tensor=self.test_auc_update_op_all, collections=['test'])

        with tf.name_scope("Scene-Metrics"):
            for i in range(self.training_config.scene_num):
                scene_index = tf.equal(self.scene_input, i)
                scene_pred = tf.boolean_mask(self.scene_preds[i], scene_index)
                scene_label = tf.boolean_mask(self.input_labels, scene_index)

                train_auc_scene, train_auc_update_op_scene = metrics.auc(
                    predictions=scene_pred, labels=scene_label, num_thresholds=2000)
                test_auc_scene, test_auc_update_op_scene = metrics.auc(
                    predictions=scene_pred, labels=scene_label, num_thresholds=2000)

                tf.summary.scalar(name="scalar/train_auc_scene_%d" % i, tensor=train_auc_update_op_scene,
                                  collections=['train'])
                tf.summary.scalar(name="scalar/test_auc_scene_%d" % i, tensor=test_auc_update_op_scene,
                                  collections=['test'])

        with tf.name_scope("%s-Losses" % self.name):
            tf.summary.scalar(name="scalar/loss", tensor=self.loss_train, collections=['train', 'test'])
            tf.summary.scalar(name="scalar/reg_loss", tensor=self.reg_losses, collections=['train', 'test'])
            vars = tf.get_collection(tf.GraphKeys.REGULARIZATION_LOSSES)
            vars = base_ops.combine_parted_variables(vars)
            for var in vars:
                tf.summary.scalar(var.name.replace(":", "_"), var, collections=['train', 'test'])

        vars = tf.get_collection(tf.GraphKeys.MODEL_VARIABLES)
        vars = base_ops.combine_parted_variables(vars)
        for var in vars:
            tf.summary.histogram(var.name.replace(":", "_"), var, collections=['train'])

        self.train_metrics = tf.summary.merge_all('train')
        self.test_metrics = tf.summary.merge_all('test')