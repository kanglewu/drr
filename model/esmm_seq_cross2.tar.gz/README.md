# [用户手册](https://yuque.antfin-inc.com/yanshi.wys/hbq1mn/zq1koa)

# 目录结构
```
.
├── base                                            基类
|   ├── dataset.py                                   ├── 数据基类, 负责数据读取
|   ├── model.py                                     ├── 模型基类
|   ├── runner.py                                    ├── 执行基类, 衔接模型与调度器
|   └── scheduler.py                                 └── 调度器基类, 调度管理训练流程
|
├── conf                                             配置
│   ├── ae_search                                    ├── AE搜索模型配置示例
|   |   ├── fc.json                                  |   ├── 特征Column生成配置
|   |   ├── fg.json                                  |   ├── 特征FG生成配置
|   |   ├── mc.json                                  |   ├── 特征分组及Attention等配置
|   |   └── param.json                               |   └── 全局实验参数默认配置
│   └── ...                                          └──
|
├── data                                             本地样本调试目录
|
├── dataset                                          数据
│   ├── dataset_factory.py                           ├── 按param.json配置生成数据IO实例
│   ├── ae_search                                    ├── AE搜索数据定义目录
|   |   ├── odps_dataset.py                          |   ├── ODPS数据IO
|   |   └── text_dataset.py                          |   └── 本地样本IO
|   └── ...                                          └── 其他场景数据IO定义
|
├── docs                                             文档
|
├── fg                                               特征
│   ├── feature_column_builder.py                    ├── Column生成对外接口
│   ├── column_generator.py                          ├── 内置Column生成逻辑定义
|   └── custom_feature_column.py                     └── 自定义Column类型
|
├── model                                            模型
│   ├── model_factory.py                             ├── 按param.json配置生成模型实例
│   ├── ae_search                                    ├── AE搜索模型目录
|   |   ├── cotrain_model.py                         |   ├── AE搜索模型定义
|   |   └── ...                                      |   └── ...
|   └── ...                                          └── 其他模型目录
|
├── model_ops                                        公共模块
│   ├── attention.py                                 ├── 传统Attention函数
│   ├── sequence.py                                  ├── Sequence特征读取函数
|   ├── ops.py                                       ├── Partitioner等函数
|   └── ...                                          └── 其他实现
|
├── pai                                              参数
|   └── pai_run.py                                   └── 框架参数解析
│
├── schedule                                         调度
│   ├── distributed_scheduler.py                     ├── 分布式训练调度
│   ├── local_scheduler.py                           ├── 本地测试调度
|   └── mode.py                                      └── 调度模型定义
|
├── shell                                            入口
│   ├── ae_search                                    ├── AE搜索
|   |   └── run_ae_search.sh                         |   └── 模型训练脚本入口
|   └── ...                                          └── 其他模型
|
└── utils                                            工具
    ├── config.py                                    ├── 配置解析及参数动态定义
    └── util.py                                      └── 激活函数等定义
```

# 调度流程
![image](docs/structure.png)
