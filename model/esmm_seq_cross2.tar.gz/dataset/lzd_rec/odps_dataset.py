#coding:utf8

from base.dataset import BaseDataset
from schedule.mode import ModeKeys
import tensorflow as tf
import rtp_fg
import json

class OdpsDataset(BaseDataset):
    """Parse data from odps tables."""

    def __init__(self, FLAGS, *args, **kwargs):
        self.FLAGS = FLAGS
        self.batch_size = FLAGS.batch_size
        self.worker_count = len(FLAGS.worker_hosts.split(','))
        self.csv_delimiter = FLAGS.csv_delimiter
        self.selected_cols = FLAGS.selected_cols
        self.record_defaults = FLAGS.record_defaults
        self.capacity = FLAGS.batch_size * 10
        self.num_threads = FLAGS.num_threads

        try:
            with open(FLAGS.fg_conf, 'r') as fp:
                self._fg_config = json.load(fp)
        except Exception as e:
            raise RuntimeError("open file fail :" + FLAGS.fg_conf)

        try:
            with open(FLAGS.fc_conf, 'r') as fp2:
                self._fc_config = json.load(fp2)
        except Exception as e:
            raise RuntimeError("open file fail :" + FLAGS.fc_conf)

        super(OdpsDataset, self).__init__(*args, **kwargs)

    # def dense2sparse(FLAGS, arr_tensor, str_0, len):
    #     # arr_tensor = tf.constant(np.array(arr))
    #     arr_idx = tf.where(tf.not_equal(arr_tensor, str_0))
    #     arr_sparse = tf.SparseTensor(arr_idx, tf.gather_nd(arr_tensor, arr_idx), [FLAGS.batch_size, len])
    #     return arr_sparse

    @staticmethod
    def _string2kv(features, conf):
        for fc in conf['feature_columns']:
            if fc.get('transform_name') == "KvColumn":
                flag = tf.constant([[chr(5).join(['item' + chr(6) + '0' for i in range(int(fc.get('max_length')))])]])

                features[fc.get('feature_name')] = tf.sparse_to_dense(
                    sparse_indices=features[fc.get('feature_name')].indices,
                    sparse_values=features[fc.get('feature_name')].values,
                    output_shape=features['user_activation_level'].dense_shape,
                    default_value='item' + chr(6) + '0')

                feature_flag = tf.concat([flag, tf.reshape(features[fc.get('feature_name')], [-1, 1])], 0)
                feature = tf.sparse_to_dense(
                    sparse_indices=tf.string_split(tf.reshape(feature_flag, [-1, ]), chr(5)).indices,
                    sparse_values=tf.string_split(tf.reshape(feature_flag, [-1, ]), chr(5)).values
                    , output_shape=tf.string_split(tf.reshape(feature_flag, [-1, ]), chr(5)).dense_shape
                    , default_value='item' + chr(6) + '0')
                # feature = feature[:,:int(fc.get(MAX_LENGTH))]
                feature1, feature2 = tf.split(
                    tf.reshape(tf.string_split(tf.reshape(feature, [-1, ]), chr(6)).values, [-1, 2]), 2, -1)
                feature1 = tf.reshape(feature1, [tf.shape(feature_flag)[0], -1])[1:, ]
                feature2 = tf.reshape(feature2, [tf.shape(feature_flag)[0], -1])[1:, ]
                features[fc.get('feature_name') + '_id'] = tf.reshape(feature1, [-1, 1])  # batch_size*max_length
                features[fc.get('feature_name') + '_value'] = tf.reshape(
                    tf.string_to_number(feature2, out_type=tf.float32),
                    [-1, 1])
        return features



    def _rtp_fg_input_fn(self, feature_configs, mode, sliceId=0, sliceCount=1):
        tableList = self.FLAGS.table_list.split(',')
        print('dataHandler tableList: %s, sliceId: %d, sliceCount: %d' % (tableList, sliceId, sliceCount))

        batch_size = self.FLAGS.batch_size
        if mode == ModeKeys.PREDICT:
            batch_size = self.FLAGS.predict_batch_size
        dataset = tf.data.TableRecordDataset(tableList,
                                             record_defaults=['', '', '', 1.0],
                                             slice_id=sliceId,
                                             slice_count=sliceCount
                                             )
        dataset = dataset.shuffle(buffer_size=10000)
        if self.FLAGS.num_epoch > 0:
            dataset = dataset.repeat(self.FLAGS.num_epoch).batch(batch_size)
        else:
            dataset = dataset.repeat().batch(batch_size)
        dataset = dataset.prefetch(10)  # this mean  real buffer size is 10 * batch_size
        unique_id, collabels, feature_kvs, weight = dataset.make_one_shot_iterator().get_next()
        features = rtp_fg.parse_genreated_fg(feature_configs, feature_kvs)

        labels = tf.string_split(collabels, ';')
        labels = tf.reshape(tf.sparse_tensor_to_dense(labels, default_value='0'), [tf.shape(labels)[0], 4])
        label_dict = {}
        label_dict['click'] = tf.reshape(tf.string_to_number(labels[:, 0], tf.int64), [tf.shape(labels)[0], 1])
        label_dict['cart'] = tf.reshape(tf.string_to_number(labels[:, 1], tf.int64), [tf.shape(labels)[0], 1])
        label_dict['pay'] = tf.reshape(tf.string_to_number(labels[:, 2], tf.int64), [tf.shape(labels)[0], 1])
        label_dict['time'] = tf.reshape(tf.string_to_number(labels[:, 3], tf.int64), [tf.shape(labels)[0], 1])
        label_dict['weight'] = weight
        features['sampleID'] = unique_id

        return features, label_dict

    def _rtp_fg_global_producer_input_fn(self,feature_configs, mode, sliceId, cluster, is_chief):
        print(self.FLAGS.table_list)
        tableList = self.FLAGS.table_list.split(',')
        print('use global_input_producer')
        print('tableList: %s' % tableList)
        if mode == ModeKeys.TRAIN:
            batch_size = self.FLAGS.batch_size
            shuffle = True
        else:
            batch_size = self.FLAGS.predict_batch_size
            shuffle = False

        name = ';'.join([tableName.split('/')[-1] for tableName in tableList])
        # global_input_queue放在ps上
        availableWorkerDevice = "/job:worker/task:%d" % sliceId
        with tf.device(tf.train.replica_device_setter(worker_device=availableWorkerDevice, cluster=cluster)):
            splits = tf.contrib.global_input.partition_filenames_once(tableList,
                                                                      partition_size=65536)
            input_queue = tf.contrib.global_input.global_string_input_producer(
                string_tensor=splits,
                num_epochs=self.FLAGS.num_epoch,
                shuffle=shuffle,
                is_chief=is_chief,
                log_inputs=True,
                name=name,
                seed=self.FLAGS.batch_size)

        # io还是放在local device上的
        workerDevice = "/job:worker/task:%d/cpu:%d" % (sliceId, 0)
        print("workerDevice: %s" % workerDevice)
        with tf.device(workerDevice):

            reader = tf.TableRecordReader(csv_delimiter='\t',
                                          selected_cols='unique_id,labels,features_kv,weight',
                                          num_threads=4,
                                          capacity=batch_size * 16)
            _, values = reader.read_up_to(input_queue, num_records=batch_size)
            batch_values = tf.train.batch(
                [values],
                batch_size=batch_size,
                capacity=batch_size * 16,
                enqueue_many=True,
                num_threads=4)
            unique_id, collabels, feature_kvs, weight = tf.decode_csv(batch_values,
                                                                      record_defaults=[[''], [''], [''], [1.0]],
                                                                      field_delim='\t')

            features = rtp_fg.parse_genreated_fg(feature_configs, feature_kvs)

            labels = tf.string_split(collabels, ';')
            labels = tf.reshape(tf.sparse_tensor_to_dense(labels, default_value='0'), [tf.shape(labels)[0], 4])
            label_dict = {}
            label_dict['click'] = tf.reshape(tf.string_to_number(labels[:, 0], tf.int64), [tf.shape(labels)[0], 1])
            label_dict['cart'] = tf.reshape(tf.string_to_number(labels[:, 1], tf.int64), [tf.shape(labels)[0], 1])
            label_dict['pay'] = tf.reshape(tf.string_to_number(labels[:, 2], tf.int64), [tf.shape(labels)[0], 1])
            label_dict['time'] = tf.reshape(tf.string_to_number(labels[:, 3], tf.int64), [tf.shape(labels)[0], 1])
            label_dict['weight'] = weight
            features['sampleID'] = unique_id

            return features, label_dict

    def get_batch(self, scheduler):

        worker_hosts = self.FLAGS.worker_hosts.split(',')
        sliceId = self.FLAGS.task_index
        sliceCount = len(worker_hosts)
        is_chief = (self.FLAGS.task_index == 0)
        cluster = scheduler.cluster

        if self.FLAGS.use_global_producer == "false":
            features, labels = self._rtp_fg_input_fn(self._fg_config, self.FLAGS.mode, sliceId, sliceCount)
        else:
            features, labels = self._rtp_fg_global_producer_input_fn(self._fg_config, self.FLAGS.mode, sliceId, cluster, is_chief)
        features = self._string2kv(features, self._fc_config)

        return {'features':features, 'labels':labels}