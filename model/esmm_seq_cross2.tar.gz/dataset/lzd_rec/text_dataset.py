from base.dataset import BaseDataset
import os
import tensorflow as tf

current_dir = os.path.abspath(os.path.dirname(__file__))
root_dir = os.path.dirname(os.path.dirname(current_dir))


class TextDataset(BaseDataset):
    """Parse data from local text."""

    def __init__(self, FLAGS, *args, **kwargs):
        self.FLAGS = FLAGS
        self.text_files = FLAGS.tables.split(',')
        self.batch_size = FLAGS.batch_size
        self.worker_count = len(FLAGS.worker_hosts.split(','))
        self.csv_delimiter = FLAGS.csv_delimiter
        self.selected_cols = FLAGS.selected_cols
        self.record_defaults = FLAGS.record_defaults
        self.capacity = FLAGS.batch_size * 10
        self.num_threads = FLAGS.num_threads

        super(TextDataset, self).__init__(*args, **kwargs)

    def _batch_data(self, text_files, batch_size, num_epochs=None):
        reader = tf.TextLineReader()
        queue = tf.train.string_input_producer(text_files, capacity=self.capacity, num_epochs=num_epochs, shuffle=True, seed=None)
        _, value = reader.read_up_to(queue, num_records=batch_size)
        batch_data = tf.train.shuffle_batch([value], batch_size=batch_size, capacity=self.capacity, enqueue_many=True,
                                            allow_smaller_final_batch=True, min_after_dequeue=0)
        batch_data = tf.decode_csv(batch_data, record_defaults=self.record_defaults, field_delim=self.csv_delimiter)
        return batch_data

    def get_batch(self):
        text_files = [os.path.join(root_dir, file_name) for file_name in self.text_files]
        ctr_batch_data = self._batch_data(text_files, self.batch_size, num_epochs=1)
        cvr_batch_data = ctr_batch_data
        return [ctr_batch_data, cvr_batch_data]
