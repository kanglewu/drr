from base.dataset import BaseDataset
import os
import numpy as np
import tensorflow as tf


current_dir = os.path.abspath(os.path.dirname(__file__))
root_dir = os.path.dirname(os.path.dirname(os.path.dirname(current_dir)))


class TextDataset(BaseDataset):
    """Parse data from local text."""

    def __init__(self, FLAGS, *args, **kwargs):
        self.FLAGS = FLAGS
        self.text_files = FLAGS.tables.split(',')
        self.batch_size = FLAGS.batch_size
        self.worker_count = len(FLAGS.worker_hosts.split(','))
        self.csv_delimiter = FLAGS.csv_delimiter
        self.selected_cols = FLAGS.selected_cols
        self.record_defaults = FLAGS.record_defaults
        self.shuffle = getattr(FLAGS, 'shuffle', False)
        self.drop_remainder = getattr(FLAGS, 'drop_remainder', False)
        self.prefetch = getattr(FLAGS, 'prefetch', True)

        super(TextDataset, self).__init__(*args, **kwargs)

    def _batch_data(self, text_files, batch_size, num_epochs=None, shuffle=False, drop_remainder=False, prefetch=True, num_parallel_calls=64):
        def _decode_csv(records):
            records = tf.decode_csv(records, record_defaults=self.record_defaults, field_delim=self.csv_delimiter)
            return records

        row_count = np.sum([len(open(f).readlines()) for f in text_files])
        dataset = tf.data.TextLineDataset(text_files)
        dataset = dataset.map(_decode_csv, num_parallel_calls=num_parallel_calls)
        if shuffle:
            dataset = dataset.shuffle(buffer_size=10, reshuffle_each_iteration=True)
        if num_epochs:
            dataset = dataset.repeat(num_epochs)
        else:
            dataset = dataset.repeat()
        if drop_remainder:
            dataset = dataset.apply(tf.contrib.data.batch_and_drop_remainder(batch_size))
        else:
            dataset = dataset.batch(batch_size)
        if prefetch:
            dataset = dataset.prefetch(buffer_size=1)
        batch_data = dataset.make_one_shot_iterator()
        return batch_data, row_count

    def get_batch(self, scheduler, *args, **kwargs):
        text_files = [os.path.join(root_dir, file_name) for file_name in self.text_files]
        ctr_batch_data, ctr_row_count = self._batch_data(text_files,
                                                         self.batch_size,
                                                         num_epochs=self.FLAGS.num_epochs,
                                                         shuffle=self.shuffle,
                                                         drop_remainder=self.drop_remainder,
                                                         prefetch=self.prefetch)
        setattr(self.FLAGS, 'step_per_epoch', ctr_row_count // self.batch_size)
        return {'ctr_batch_data': ctr_batch_data}

