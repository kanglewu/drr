from base.dataset import BaseDataset
from schedule.mode import ModeKeys
from utils.config import get_table_size
import numpy as np
import tensorflow as tf


class OdpsDataset(BaseDataset):
    """Parse data from odps tables."""

    def __init__(self, FLAGS, *args, **kwargs):
        self.FLAGS = FLAGS
        self.odps_tables = FLAGS.tables.split(',')
        self.batch_size = FLAGS.batch_size
        self.worker_count = len(FLAGS.worker_hosts.split(','))
        self.csv_delimiter = FLAGS.csv_delimiter
        self.selected_cols = FLAGS.selected_cols
        self.record_defaults = FLAGS.record_defaults
        self.shuffle = getattr(FLAGS, 'shuffle', False)
        self.drop_remainder = getattr(FLAGS, 'drop_remainder', False)
        self.prefetch = getattr(FLAGS, 'prefetch', True)
        self.capacity = FLAGS.batch_size * 10
        self.num_threads = FLAGS.num_threads

        super(OdpsDataset, self).__init__(*args, **kwargs)

    def _batch_data(self, odps_tables, batch_size, num_epochs=None, slice_count=1, slice_id=0,
                    shuffle=False, drop_remainder=False, prefetch=True, num_parallel_calls=64):
        row_count = np.sum([get_table_size(t) for t in odps_tables])
        dataset = tf.data.TableRecordDataset(filenames=odps_tables,
                                             record_defaults=self.record_defaults,
                                             selected_cols=self.selected_cols,
                                             slice_id=slice_id,
                                             slice_count=slice_count,
                                             num_threads=self.num_threads,
                                             capacity=self.capacity
                                             )
        if shuffle:
            dataset = dataset.shuffle(buffer_size=10, reshuffle_each_iteration=True)
        if num_epochs:
            dataset = dataset.repeat(num_epochs)
        else:
            dataset = dataset.repeat()
        if drop_remainder:
            dataset = dataset.apply(tf.contrib.data.batch_and_drop_remainder(batch_size))
        else:
            dataset = dataset.batch(batch_size)
        if prefetch:
            dataset = dataset.prefetch(buffer_size=1)
        batch_data = dataset.make_one_shot_iterator()
        return batch_data, row_count

    def get_batch(self, scheduler, *args, **kwargs):
        if self.FLAGS.mode == ModeKeys.PREDICT:
            ctr_batch_data, _ = self._batch_data(odps_tables=self.odps_tables[-1:],
                                                 batch_size=self.FLAGS.batch_size,
                                                 num_epochs=1,
                                                 slice_count=self.worker_count,
                                                 slice_id=self.FLAGS.task_index,
                                                 prefetch=self.prefetch)
        else:
            if self.FLAGS.task_index == 0:  # chief node for validation
                ctr_batch_data, ctr_row_count = self._batch_data(odps_tables=self.odps_tables[1:2],
                                                                 batch_size=self.FLAGS.batch_size,
                                                                 slice_count=1,
                                                                 slice_id=0,
                                                                 drop_remainder=self.drop_remainder,
                                                                 prefetch=self.prefetch)
                setattr(self.FLAGS, 'step_per_epoch', ctr_row_count // self.FLAGS.batch_size)
            else:
                ctr_batch_data, ctr_row_count = self._batch_data(odps_tables=self.odps_tables[0:1],
                                                                 batch_size=self.FLAGS.batch_size,
                                                                 num_epochs=self.FLAGS.num_epochs,
                                                                 slice_count=self.worker_count - 1,
                                                                 slice_id=self.FLAGS.task_index - 1,
                                                                 shuffle=self.shuffle,
                                                                 drop_remainder=self.drop_remainder,
                                                                 prefetch=self.prefetch)
                setattr(self.FLAGS, 'step_per_epoch', ctr_row_count // self.FLAGS.batch_size)
        return {'ctr_batch_data': ctr_batch_data}
