from base.dataset import BaseDataset
from schedule.mode import ModeKeys
from utils.config import get_table_size
import os
import tensorflow as tf


current_dir = os.path.abspath(os.path.dirname(__file__))
root_dir = os.path.dirname(os.path.dirname(os.path.dirname(current_dir)))


class TextDataset(BaseDataset):
    """Parse data from local text."""

    def __init__(self, FLAGS, *args, **kwargs):
        self.FLAGS = FLAGS
        self.text_files = FLAGS.tables.split(',')
        self.batch_size = FLAGS.batch_size
        self.worker_count = len(FLAGS.worker_hosts.split(','))
        self.csv_delimiter = FLAGS.csv_delimiter
        self.selected_cols = FLAGS.selected_cols
        self.record_defaults = FLAGS.record_defaults
        self.capacity = FLAGS.batch_size * 10
        self.num_threads = FLAGS.num_threads

        super(TextDataset, self).__init__(*args, **kwargs)

    def _batch_data(self, text_files, batch_size, num_epochs=None):
        def _decode_csv(samples):
            samples = tf.decode_csv(samples, record_defaults=self.record_defaults, field_delim=self.csv_delimiter)
            return samples

        assert len(text_files) == 1, 'more than one input table is not supported'
        row_count = len(open(text_files[0]).readlines())
        dataset = tf.data.TextLineDataset(text_files)
        dataset = dataset.map(_decode_csv)
        if num_epochs is not None and num_epochs > 0:
            dataset = dataset.repeat(num_epochs).batch(batch_size)
        else:
            dataset = dataset.repeat().batch(batch_size)
        batch_data = dataset.make_one_shot_iterator()
        return batch_data, row_count

    def get_batch(self, scheduler, *args, **kwargs):
        text_files = [os.path.join(root_dir, file_name) for file_name in self.text_files]
        cur_batch_data, cur_row_count = self._batch_data(text_files, self.batch_size, num_epochs=1)
        text_files[0] = text_files[0] + '.0'
        com_batch_data, com_row_count = self._batch_data(text_files, self.batch_size, num_epochs=1)
        setattr(self.FLAGS, 'cur_step_per_epoch', cur_row_count // self.FLAGS.batch_size)
        setattr(self.FLAGS, 'com_step_per_epoch', com_row_count // self.FLAGS.batch_size)
        return {'cur_batch_data': cur_batch_data, 'com_batch_data': com_batch_data}
