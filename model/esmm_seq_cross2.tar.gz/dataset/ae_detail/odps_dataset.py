from base.dataset import BaseDataset
from schedule.mode import ModeKeys
from utils.config import get_table_size
import tensorflow as tf


class OdpsDataset(BaseDataset):
    """Parse data from odps tables."""

    def __init__(self, FLAGS, *args, **kwargs):
        self.FLAGS = FLAGS
        self.odps_tables = FLAGS.tables.split(',')
        self.batch_size = FLAGS.batch_size
        self.worker_count = len(FLAGS.worker_hosts.split(','))
        self.csv_delimiter = FLAGS.csv_delimiter
        self.selected_cols = FLAGS.selected_cols
        self.record_defaults = FLAGS.record_defaults
        self.capacity = FLAGS.batch_size * 10
        self.num_threads = FLAGS.num_threads

        super(OdpsDataset, self).__init__(*args, **kwargs)

    def _batch_data(self, odps_tables, batch_size, num_epochs=None, slice_count=1, slice_id=0, name=None):
        assert len(odps_tables) == 1, 'more than one input table is not supported'
        row_count = get_table_size(odps_tables[0])
        dataset = tf.data.TableRecordDataset(filenames=odps_tables,
                                             record_defaults=self.record_defaults,
                                             selected_cols=self.selected_cols,
                                             slice_id=slice_id,
                                             slice_count=slice_count,
                                             num_threads=self.num_threads,
                                             capacity=self.capacity
                                             )
        if num_epochs is not None and num_epochs > 0:
            dataset = dataset.repeat(num_epochs).batch(batch_size)
        else:
            dataset = dataset.repeat().batch(batch_size)
        batch_data = dataset.make_one_shot_iterator()
        return batch_data, row_count

    def get_batch(self, scheduler, *args, **kwargs):
        if self.FLAGS.mode == ModeKeys.PREDICT:
            ctr_batch_data, _ = self._batch_data(odps_tables=self.odps_tables[-1:],
                                                 batch_size=self.FLAGS.batch_size,
                                                 num_epochs=1,
                                                 slice_count=self.worker_count,
                                                 slice_id=self.FLAGS.task_index,
                                                 name='CTR')
            setattr(self.FLAGS, 'cross_ratio', 1.0)
            cvr_batch_data = ctr_batch_data
        else:
            if self.FLAGS.task_index == 0:  # chief node for validation
                ctr_batch_data, ctr_row_count = self._batch_data(odps_tables=self.odps_tables[1:2],
                                                                 batch_size=self.FLAGS.batch_size,
                                                                 slice_count=1,
                                                                 slice_id=0,
                                                                 name='Test_CTR')
                cvr_batch_data, cvr_row_count = self._batch_data(odps_tables=self.odps_tables[3:4],
                                                                 batch_size=self.FLAGS.batch_size,
                                                                 slice_count=1,
                                                                 slice_id=0,
                                                                 name='Test_CVR')
                setattr(self.FLAGS, 'cross_ratio', 0.5)
            else:
                ctr_batch_data, ctr_row_count = self._batch_data(odps_tables=self.odps_tables[0:1],
                                                                 batch_size=self.FLAGS.batch_size,
                                                                 num_epochs=self.FLAGS.num_epochs,
                                                                 slice_count=self.worker_count - 1,
                                                                 slice_id=self.FLAGS.task_index - 1,
                                                                 name='Train_CTR')
                cvr_batch_data, cvr_row_count = self._batch_data(odps_tables=self.odps_tables[2:3],
                                                                 batch_size=self.FLAGS.batch_size,
                                                                 num_epochs=self.FLAGS.num_epochs,
                                                                 slice_count=self.worker_count - 1,
                                                                 slice_id=self.FLAGS.task_index - 1,
                                                                 name='Train_CVR')
                cross_ratio = float(ctr_row_count) / float(ctr_row_count + cvr_row_count)
                setattr(self.FLAGS, 'cross_ratio', cross_ratio)
        return {'ctr_batch_data': ctr_batch_data, 'cvr_batch_data': cvr_batch_data}
