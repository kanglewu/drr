from base.dataset import BaseDataset
from schedule.mode import ModeKeys
import tensorflow as tf


class OdpsDataset(BaseDataset):
    """Parse data from odps tables."""

    def __init__(self, FLAGS, *args, **kwargs):
        self.FLAGS = FLAGS
        self.odps_tables = FLAGS.tables.split(',')
        self.batch_size = FLAGS.batch_size
        self.worker_count = len(FLAGS.worker_hosts.split(','))
        self.csv_delimiter = FLAGS.csv_delimiter
        self.selected_cols = FLAGS.selected_cols
        self.record_defaults = FLAGS.record_defaults
        self.capacity = FLAGS.batch_size * 10
        self.num_threads = FLAGS.num_threads

        super(OdpsDataset, self).__init__(*args, **kwargs)

    def _batch_data(self, odps_tables, batch_size, num_epochs=None, slice_count=1, slice_id=0, name=None):
        reader = tf.TableRecordReader(csv_delimiter=self.csv_delimiter,
                                      selected_cols=self.selected_cols,
                                      slice_count=slice_count,
                                      slice_id=slice_id,
                                      num_threads=self.num_threads,
                                      capacity=self.capacity,
                                      name=name + '_Reader' if name else None)
        queue = tf.train.string_input_producer(odps_tables,
                                               num_epochs=num_epochs,
                                               name=name + '_Queue' if name else None)
        _, value = reader.read_up_to(queue, batch_size)

        sample = tf.decode_csv(value, field_delim=self.csv_delimiter, record_defaults=self.record_defaults)
        batch_data = tf.train.shuffle_batch_join([sample],
                                                 batch_size=batch_size,
                                                 capacity=self.capacity,
                                                 enqueue_many=True,
                                                 allow_smaller_final_batch=True,
                                                 min_after_dequeue=batch_size
                                                 )
        return batch_data

    def get_batch(self, scheduler, *args, **kwargs):
        if self.FLAGS.mode == ModeKeys.PREDICT:
            ctr_batch_data = self._batch_data(odps_tables=self.odps_tables[-1:],
                                              batch_size=self.FLAGS.batch_size,
                                              num_epochs=1,
                                              slice_count=self.worker_count,
                                              slice_id=self.FLAGS.task_index,
                                              name='CTR')
            cvr_batch_data = ctr_batch_data
        else:
            if self.FLAGS.task_index == 0:  # chief node for validation
                ctr_batch_data = self._batch_data(odps_tables=self.odps_tables[1:2],
                                                  batch_size=self.FLAGS.batch_size,
                                                  num_epochs=None,
                                                  slice_count=1,
                                                  slice_id=0,
                                                  name='Test_CTR')
                cvr_batch_data = self._batch_data(odps_tables=self.odps_tables[3:4],
                                                  batch_size=self.FLAGS.batch_size,
                                                  num_epochs=None,
                                                  slice_count=1,
                                                  slice_id=0,
                                                  name='Test_CVR')
            else:
                ctr_batch_data = self._batch_data(odps_tables=self.odps_tables[0:1],
                                                  batch_size=self.FLAGS.batch_size,
                                                  num_epochs=self.FLAGS.num_epochs,
                                                  slice_count=self.worker_count - 1,
                                                  slice_id=self.FLAGS.task_index - 1,
                                                  name='Train_CTR')
                cvr_batch_data = self._batch_data(odps_tables=self.odps_tables[2:3],
                                                  batch_size=self.FLAGS.batch_size // 2,
                                                  num_epochs=self.FLAGS.num_epochs,
                                                  slice_count=self.worker_count - 1,
                                                  slice_id=self.FLAGS.task_index - 1,
                                                  name='Train_CVR')
        return {'ctr_batch_data': ctr_batch_data, 'cvr_batch_data': cvr_batch_data}
