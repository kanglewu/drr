# coding=utf-8
import os
import tensorflow as tf
import numpy as np
import json
import operator
import heapq
from tensorflow.python.platform import gfile
import pickle as pkl

class FeatureSelector:
    def __init__(self, sess, json_path, save_path):
        self.sess = sess
        self.save_path = save_path
        self.feature_list = self._load_features(json_path)


    def _load_features(self, json_path):
        '''
        根据json文件提取特征列表，需自行根据情况实现。
        :param json_path: 参数json文件路径
        :return: 特征list，顺序需与variable中一致。
        '''
        f = open(json_path, 'r')
        conf_dict = json.load(f)
        f.close()

        user_sparse_extend = [[x + '_0', x + '_1', x + '_2', x + '_3', x + '_4', x + '_5', x + '_6', x + '_7'] for x in
                              conf_dict['input_columns']['user_sparse']]
        user_sparse_extend = reduce(operator.add, user_sparse_extend)

        item_sparse_extend = [[x + '_0', x + '_1', x + '_2', x + '_3', x + '_4', x + '_5', x + '_6', x + '_7'] for x in
                              conf_dict['input_columns']['item_sparse']]
        item_sparse_extend = reduce(operator.add, item_sparse_extend)

        features = conf_dict['input_columns']['user_dense'] + conf_dict['input_columns']['user_behavior'] + \
                   conf_dict['input_columns']['item_dense'] + conf_dict['input_columns'][
                       'item_behavior'] + user_sparse_extend + item_sparse_extend
        return features

    def run(self, var_name, topk=40):
        '''
        根据第一层全连接的值分析无用特征
        :param var_name: 全连接tensor name
        :param topk: 选topk无用特征
        :return: print无用特征list
        '''
        vars = [x for x in tf.trainable_variables() if var_name in x.name]
        assert len(vars)==1, "var_len={}, which is not 1".format(len(vars))
        var = self.sess.run(vars[0], feed_dict={'training:0': False})
        var_mean_abs = np.mean(np.abs(var), axis=1)
        var_std = np.var(var, axis=1)

        ft_len = len(self.feature_list)
        var_mean_abs = var_mean_abs[:ft_len]
        var_std = var_std[:ft_len]

        ## 选取低效特征
        min_mean_index_list = map(var_mean_abs.index, heapq.nsmallest(topk, var_mean_abs))
        low_eff_ft = []
        for each in list(min_mean_index_list):
            low_eff_ft.append(each)
            # print(each, ':', self.feature_list[each])

        ## 选取低方差特征
        min_std_index_list = map(var_std.index, heapq.nsmallest(topk, var_std))
        low_var_ft = []
        for each in list(min_std_index_list):
            low_var_ft.append(each)
            # print(each, ':', self.feature_list[each])

        ## 综合选取低质量特征
        del_ft_idx = list(set(low_eff_ft).intersection(set(low_var_ft)))
        for each in del_ft_idx:
            print(each, ':', self.feature_list[each])

        ## save
        f = gfile.GFile(os.path.join(self.save_path, 'weight_variable.pkl'), mode='wb')
        pkl.dump(var, f, protocol=2)
        f.close()

        f = gfile.GFile(os.path.join(self.save_path, 'low_efficient_ft.txt'), mode='w')
        for each in del_ft_idx:
            f.write('{} : {}\n'.format(each, self.feature_list[each]))
        f.close()