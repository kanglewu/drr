# Copyright 2020 Alibaba Group Holding Limited. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================
import tensorflow as tf


def CIN(input_tensor, cin_hidden_units):
    embedding_size = input_tensor.get_shape().as_list()[-1]

    x0 = tf.transpose(input_tensor, perm=[0, 2, 1])  # B, D, T
    x0 = tf.expand_dims(x0, axis=-1)  # B, D, T, 1

    xk_layers = [input_tensor]
    hk = [input_tensor.get_shape().as_list()[1]]

    for idx, layer_size in enumerate(cin_hidden_units):
        xk = tf.transpose(xk_layers[-1], perm=[0, 2, 1])  # B, D, T
        xk = tf.expand_dims(xk, axis=-1)  # B, D, T, 1
        zk = tf.matmul(x0, xk, transpose_b=True)  # B, D, T0, Tk
        zk = tf.reshape(zk, shape=[-1, embedding_size, hk[0] * hk[-1]])  # B, D, T0*Tk

        filters = tf.get_variable(name='filter_' + str(idx), shape=[1, hk[0] * hk[-1], layer_size], dtype=tf.float32,
                                  initializer=tf.truncated_normal_initializer(),
                                  collections=[tf.GraphKeys.TRAINABLE_VARIABLES, tf.GraphKeys.GLOBAL_VARIABLES])
        zk = tf.nn.conv1d(zk, filters=filters, stride=1, padding='VALID')  # B, D, C
        b = tf.get_variable(name='filter_bias_' + str(idx), shape=[layer_size], dtype=tf.float32,
                            initializer=tf.zeros_initializer(),
                            collections=[tf.GraphKeys.TRAINABLE_VARIABLES, tf.GraphKeys.GLOBAL_VARIABLES])
        zk = tf.nn.bias_add(zk, b)  # B, D, C
        zk = tf.nn.relu(zk)  # B, D, C
        zk = tf.transpose(zk, perm=[0, 2, 1])  # B, C, D

        xk_layers.append(zk)
        hk.append(layer_size)

    xk_layers = xk_layers[1:-1]
    ret = tf.concat(xk_layers, axis=1)
    ret = tf.reduce_sum(ret, axis=-1)
    return ret
