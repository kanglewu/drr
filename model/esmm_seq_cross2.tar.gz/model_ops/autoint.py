# -*- coding: utf-8 -*-
import tensorflow as tf
from tensorflow.contrib import layers

'''
#autoint算法中的attention实现
'''

def normalize(inputs, epsilon=1e-8,
                scope="normalize",
                reuse=None):
    '''
    Applies layer normalization
    Args:
        inputs: A tensor with 2 or more dimensions
        epsilon: A floating number to prevent Zero Division
    Returns:
        A tensor with the same shape and data dtype
    '''
    with tf.variable_scope(scope, reuse=reuse):
        inputs_shape = inputs.get_shape()
        params_shape = inputs_shape[-1:]

        mean, variance = tf.nn.moments(inputs, [-1], keep_dims=True)
        beta = tf.Variable(tf.zeros(params_shape), name="beta")
        gamma = tf.Variable(tf.ones(params_shape), name="gamma")
        tf.add_to_collection(tf.GraphKeys.MODEL_VARIABLES, beta) #, name="beta")
        tf.add_to_collection(tf.GraphKeys.MODEL_VARIABLES, gamma) #, name="gamma")
        normalized = (inputs - mean) / ((variance + epsilon) ** (.5))
        outputs = gamma * normalized + beta

    return outputs

        
def multihead_attention(queries,
                        keys,
                        values,
                        num_units=None,
                        num_heads=1,
                        dropout_keep_prob=1,
                        scope="multihead_attention",
                        reuse=None,
                        is_training=True,
                        has_residual=True):

    if num_units is None:
        num_units = queries.get_shape().as_list()[-1]
    print('num_units: %s' % num_units)

    with tf.variable_scope(scope, reuse=reuse):
        # Linear projections
        Q = layers.fully_connected(queries,
                                         num_units,
                                         activation_fn=tf.nn.relu,
                                         scope=scope+"Q")
        K = layers.fully_connected(keys,
                                         num_units,
                                         activation_fn=tf.nn.relu,
                                         scope=scope+"K")
        V = layers.fully_connected(values,
                                         num_units,
                                         activation_fn=tf.nn.relu,
                                         scope=scope+"V")
        if has_residual:
            V_res = layers.fully_connected(values,
                                         num_units,
                                         activation_fn=tf.nn.relu,
                                         scope=scope+"V_res")

        # Split and concat
        Q_ = tf.concat(tf.split(Q, num_heads, axis=2), axis=0)
        K_ = tf.concat(tf.split(K, num_heads, axis=2), axis=0)
        V_ = tf.concat(tf.split(V, num_heads, axis=2), axis=0)

        # Multiplication
        Q_ = normalize(Q_, scope=scope+"Q_", reuse=reuse)
        K_ = normalize(K_, scope=scope+"K_", reuse=reuse)

        weights = tf.matmul(Q_, tf.transpose(K_, [0, 2, 1]))

        # Scale
        weights = weights / (K_.get_shape().as_list()[-1] ** 0.5)

        # Activation
        weights = tf.nn.softmax(weights)


        # Dropouts
        weights = tf.layers.dropout(weights, rate=1-dropout_keep_prob,
                                            training=tf.convert_to_tensor(is_training))

        # Weighted sum
        outputs = tf.matmul(weights, V_)

        # Restore shape
        outputs = tf.concat(tf.split(outputs, num_heads, axis=0), axis=2)

        # Residual connection
        if has_residual:
            outputs += V_res

        outputs = tf.nn.relu(outputs)
        # Normalize
        outputs = normalize(outputs, scope=scope+"outputs", reuse=reuse)
        
    return outputs

