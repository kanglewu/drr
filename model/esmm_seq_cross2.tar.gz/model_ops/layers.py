import tensorflow as tf
from tensorflow.contrib import layers

def feed_forward_net(net,
                     hidden_units,
                     activation_fn=tf.nn.relu,
                     kernel_initializer=None,
                     kernel_regularizer=None,
                     dropout=None,
                     dnn_parent_scope=None,
                     is_training=True):

    for layer_id, num_hidden_units in enumerate(hidden_units):
        with tf.variable_scope(dnn_parent_scope + '_h_%d' % layer_id, values=(net,)) as scope:
            net = tf.layers.dense(net,
                                  units=num_hidden_units,
                                  activation=activation_fn,
                                  kernel_initializer=kernel_initializer,
                                  kernel_regularizer=kernel_regularizer,
                                  name=scope)
            if (layer_id+1)<len(hidden_units):
                net = layers.batch_norm(net, is_training=is_training)
            if dropout is not None:
                keep_prob = 1-dropout
                net = layers.dropout(net, keep_prob=keep_prob, is_training=is_training)
    return net