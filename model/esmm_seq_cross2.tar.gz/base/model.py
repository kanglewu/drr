from abc import ABCMeta, abstractmethod
from base.runner import BaseRunner
import tensorflow as tf


class BaseModel(object):
    __metaclass__ = ABCMeta

    def __init__(self, FLAGS, *args, **kwargs):
        self.FLAGS = FLAGS
        self.runner = BaseRunner(FLAGS)

    @abstractmethod
    def build(self, *args, **kwargs):
        raise NotImplementedError('Calling an abstract method.')

    def get_scaffold(self):
        max_to_keep = getattr(self.FLAGS, 'max_to_keep', 5)
        load_checkpoint_dir = getattr(self.FLAGS, 'load_checkpoint_dir', None)
        if not load_checkpoint_dir:
            return tf.train.Scaffold()
        else:
            print('load checkpoint from:{}'.format(load_checkpoint_dir))
            ckpt = tf.train.get_checkpoint_state(load_checkpoint_dir)
            if ckpt is None:
                print('no checkpoint at:{}'.format(load_checkpoint_dir))
                return tf.train.Scaffold()
            else:
                variables_to_restore = tf.contrib.framework.get_variables_to_restore()
                init_assign_op, init_feed_dict = tf.contrib.framework.assign_from_checkpoint(ckpt.model_checkpoint_path,
                                                                                             variables_to_restore,
                                                                                             ignore_missing_vars=True)

                def init_fn(scaffold, sess):
                    sess.run(init_assign_op, init_feed_dict)
                scaffold = tf.train.Scaffold(saver=tf.train.Saver(max_to_keep=max_to_keep), init_fn=init_fn)
                return scaffold

    def get_hooks(self):
        hooks = []
        loss = getattr(self, 'loss', None)
        if loss is not None:
            nan_hook = tf.train.NanTensorHook(loss)
            hooks.append(nan_hook)
        return hooks

    def get_chief_only_hooks(self):
        return None

    def get_schedule_config(self):
        conf = tf.ConfigProto(allow_soft_placement=True, log_device_placement=False)
        conf.gpu_options.allow_growth = True
        conf.inter_op_parallelism_threads = 64
        return conf

