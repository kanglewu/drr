import os
import sys
import tensorflow as tf

current_dir = os.path.abspath(os.path.dirname(__file__))
root_dir = os.path.dirname(current_dir)

sys.path.append(root_dir)

from schedule.scheduler_factory import SchedulerFactory
from schedule.distributed_scheduler import DistributedScheduler
from schedule.local_scheduler import LocalScheduler
from schedule.mode import ModeKeys
from utils.config import parse_global_conf

flags = tf.app.flags

flags.DEFINE_string('global_conf', None, 'global parameters')

flags.DEFINE_integer('task_index', 0, 'worker task index')
flags.DEFINE_string('job_name', '', 'worker/ps')
flags.DEFINE_string('ps_hosts', '', 'ps hosts')
flags.DEFINE_string('worker_hosts', '', 'worker hosts')

FLAGS = tf.app.flags.FLAGS
parse_global_conf(FLAGS)

def main(_):

    print("checkpointDir:{}".format(FLAGS.checkpointDir))
    tf.logging.set_verbosity(tf.logging.ERROR)

    if not getattr(FLAGS, 'scheduler_name', None):
        if FLAGS.mode == ModeKeys.LOCAL:
            scheduler = LocalScheduler(FLAGS)
        else:
            scheduler = DistributedScheduler(FLAGS)
    else:
        scheduler = SchedulerFactory.get_scheduler(FLAGS.scheduler_name, FLAGS)

    scheduler.run()


if __name__ == '__main__':
    tf.app.run()
