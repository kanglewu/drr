import json
import column_generator


class FeatureColumnBuilder(object):
    def __init__(self, FLAGS, fg_conf, fc_conf, **kwargs):
        self._FLAGS = FLAGS
        self._feature_column_dict = {}

        self._fg_config = fg_conf
        self._fc_config = fc_conf
        self.build_column()

    def build_column(self, **kwargs):
        for column_conf in self._fc_config['feature_columns']:
            assert 'transform_name' in column_conf, 'param transform_name not found'
            getattr(column_generator, column_conf['transform_name'])(column_conf, self._feature_column_dict, **kwargs)

    def get_column(self, name):
        assert name in self._feature_column_dict, 'feature {} does not exist'.format(name)
        return self._feature_column_dict[name]

    def get_column_list(self, name_list):
        column_list = [self._feature_column_dict[name] for name in name_list]
        return column_list
