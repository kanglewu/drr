from base.scheduler import BaseScheduler
from dataset.dataset_factory import DatasetFactory
from model.model_factory import ModelFactory
import tensorflow as tf
import time


class DistributedScheduler(BaseScheduler):

    def __init__(self, FLAGS, *args, **kwargs):
        self.FLAGS = FLAGS
        ps_hosts = FLAGS.ps_hosts.split(',')
        worker_hosts = FLAGS.worker_hosts.split(',')
        self.cluster = tf.train.ClusterSpec({'ps': ps_hosts, 'worker': worker_hosts})
        super(DistributedScheduler, self).__init__(*args, **kwargs)

    def run(self):
        server = tf.train.Server(self.cluster, job_name=self.FLAGS.job_name, task_index=self.FLAGS.task_index)
        if self.FLAGS.job_name == 'ps':
            server.join()
        elif self.FLAGS.job_name == 'worker':
            with tf.device('/job:worker/task:{}/cpu:0'.format(self.FLAGS.task_index)):
                dataset = DatasetFactory.get_dataset(self.FLAGS.dataset_name, self.FLAGS)
                batch_data = dataset.get_batch(self)

            with tf.device(tf.train.replica_device_setter(worker_device='/job:worker/task:{}'.format(self.FLAGS.task_index),
                                                          cluster=self.cluster,
                                                          ps_strategy=tf.contrib.training.GreedyLoadBalancingStrategy(
                                                              len(self.FLAGS.ps_hosts.split(',')),
                                                              tf.contrib.training.byte_size_load_fn))):
                model = ModelFactory.get_model(self.FLAGS.model_name, self.FLAGS)
                model.build(batch_data)

            is_chief = (self.FLAGS.task_index == 0)
            with tf.train.MonitoredTrainingSession(master=server.target,
                                                   is_chief=is_chief,
                                                   checkpoint_dir=self.FLAGS.checkpointDir,
                                                   save_checkpoint_secs=self.FLAGS.save_checkpoint_secs,
                                                   save_summaries_steps=self.FLAGS.save_summaries_steps,
                                                   scaffold=model.get_scaffold(),
                                                   config=model.get_schedule_config(),
                                                   hooks=model.get_hooks(),
                                                   chief_only_hooks=model.get_chief_only_hooks()
                                                   ) as mon_sess:
                try:
                    if not mon_sess.should_stop():
                        model.runner.before_run(mon_sess)
                    while not mon_sess.should_stop():
                        if model.runner.run(mon_sess):
                            break
                except tf.errors.OutOfRangeError:
                    print('Run out of data.')
                finally:
                    if not mon_sess.should_stop():
                        model.runner.after_run(mon_sess)
                print('Finish.')
                time.sleep(15)
