from base.scheduler import BaseScheduler
from dataset.dataset_factory import DatasetFactory
from model.model_factory import ModelFactory
import tensorflow as tf


class LocalScheduler(BaseScheduler):

    def __init__(self, FLAGS, *args, **kwargs):
        self.FLAGS = FLAGS
        super(LocalScheduler, self).__init__(*args, **kwargs)

    def run(self):
        dataset = DatasetFactory.get_dataset(self.FLAGS.dataset_name, self.FLAGS)
        batch_data = dataset.get_batch(self)

        model = ModelFactory.get_model(self.FLAGS.model_name, self.FLAGS)
        model.build(batch_data)

        init_op = [tf.global_variables_initializer(), tf.local_variables_initializer(), tf.tables_initializer()]
        with tf.Session() as sess:
            sess.graph.finalize()
            sess.run(init_op)
            coord = tf.train.Coordinator()
            threads = tf.train.start_queue_runners(coord=coord)

            model.runner.before_run(sess)
            while not coord.should_stop():
                try:
                    model.runner.run(sess)
                except tf.errors.OutOfRangeError:
                    break
            model.runner.after_run(sess)

            coord.request_stop()
            coord.join(threads)

            print('Finish.')

